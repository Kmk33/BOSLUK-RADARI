# V37 — Expanded chart-pattern candidates

- Added heuristic cup-and-handle candidate.
- Added inverse head-and-shoulders candidate using confirmed swing lows.
- Added bull-flag and pennant candidates with impulse/pullback geometry checks.
- Added rising-wedge weakness warning, explicitly marked as risk rather than bullish preparation.
- Combined scoring no longer treats risk-only pattern warnings as bullish setup evidence.
- Coin detail displays risk-marked patterns with a warning marker.
- Added pattern metadata and risk-isolation regression tests.
- 26 local tests pass; syntax checks clean. Heuristic patterns are candidates, not guaranteed formations; no historical precision validation or live device test claimed.
