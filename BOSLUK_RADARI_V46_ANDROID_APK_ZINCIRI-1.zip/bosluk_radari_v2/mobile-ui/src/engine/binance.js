const BASES=['https://data-api.binance.vision','https://api.binance.com'];
const cache=new Map();
const wait=ms=>new Promise(r=>setTimeout(r,ms));
export function validateKlineRows(rows){
 if(!Array.isArray(rows))return {valid:false,reason:'Mum yanıtı dizi değil',rows:[]};
 const clean=rows.filter(c=>c&&Number.isFinite(c.openTime)&&Number.isFinite(c.closeTime)&&
  Number.isFinite(c.open)&&Number.isFinite(c.high)&&Number.isFinite(c.low)&&Number.isFinite(c.close)&&
  Number.isFinite(c.volume)&&c.open>0&&c.low>0&&c.high>=Math.max(c.open,c.close,c.low)&&
  c.low<=Math.min(c.open,c.close)&&c.volume>=0)
  .sort((a,b)=>a.openTime-b.openTime);
 const unique=clean.filter((c,i)=>i===0||c.openTime!==clean[i-1].openTime);
 return {valid:unique.length>=2,reason:unique.length===rows.length?null:`Bozuk/tekrarlı mum temizlendi: ${rows.length-unique.length}`,rows:unique,received:rows.length,accepted:unique.length};
}
async function request(path,params={}) {
  const qs=new URLSearchParams(params).toString(); let last;
  for(const base of BASES){
    for(let attempt=0;attempt<2;attempt++){
      const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);
      try{
        const response=await fetch(`${base}${path}?${qs}`,{signal:controller.signal,headers:{'Accept':'application/json'}});
        if(response.status===418||response.status===429) throw new Error(`Binance hız sınırı (${response.status}); tarama durduruldu.`);
        if(!response.ok) throw new Error(`Binance HTTP ${response.status}`);
        return await response.json();
      }catch(e){last=e;if(String(e.message).includes('hız sınırı'))throw e;await wait(350*(attempt+1));}
      finally{clearTimeout(timer);}
    }
  }
  throw new Error(`Binance verisine ulaşılamadı: ${last?.message||'ağ hatası'}`);
}
export async function getSpotUniverse(limit=30){
  const now=Date.now(),hit=cache.get('universe');if(hit&&now-hit.at<15000)return hit.data;
  const [info,tickers]=await Promise.all([request('/api/v3/exchangeInfo'),request('/api/v3/ticker/24hr')]);
  const valid=new Set(info.symbols.filter(s=>s.status==='TRADING'&&s.isSpotTradingAllowed&&s.quoteAsset==='USDT'&&!/(UP|DOWN|BULL|BEAR|[0-9]+L|[0-9]+S)USDT$/.test(s.symbol)).map(s=>s.symbol));
  const data=tickers.filter(t=>valid.has(t.symbol)&&Number(t.quoteVolume)>=1000000&&Number(t.count)>=500).sort((a,b)=>Number(b.quoteVolume)-Number(a.quoteVolume)).slice(0,limit).map(t=>({symbol:t.symbol,quoteVolume:Number(t.quoteVolume)}));
  cache.set('universe',{at:now,data});return data;
}
export async function getOrderBook(symbol,limit=100){
 const key=`depth:${symbol}:${limit}`,now=Date.now(),hit=cache.get(key);if(hit&&now-hit.at<5000)return hit.data;
 const raw=await request('/api/v3/depth',{symbol,limit});
 const bids=(raw.bids||[]).map(([price,qty])=>({price:Number(price),qty:Number(qty),notional:Number(price)*Number(qty)}));
 const asks=(raw.asks||[]).map(([price,qty])=>({price:Number(price),qty:Number(qty),notional:Number(price)*Number(qty)}));
 const bidNotional=bids.reduce((a,x)=>a+x.notional,0),askNotional=asks.reduce((a,x)=>a+x.notional,0),sum=bidNotional+askNotional;
 const data={lastUpdateId:raw.lastUpdateId,bids:bids.slice(0,20),asks:asks.slice(0,20),bid_notional:bidNotional,ask_notional:askNotional,imbalance:sum>0?(bidNotional-askNotional)/sum:0,spread_pct:bids[0]?.price&&asks[0]?.price?((asks[0].price-bids[0].price)/((asks[0].price+bids[0].price)/2))*100:null};
 cache.set(key,{at:now,data});return data;
}
export async function getKlines(symbol,interval,limit=230){
  const key=`${symbol}:${interval}:${limit}`,now=Date.now(),hit=cache.get(key);
  if(hit&&now-hit.at<20000)return hit.data;
  const rows=await request('/api/v3/klines',{symbol,interval,limit}),stamp=Date.now();
  const mapped=rows.map(k=>({openTime:Number(k[0]),open:Number(k[1]),high:Number(k[2]),low:Number(k[3]),close:Number(k[4]),volume:Number(k[5]),closeTime:Number(k[6]),quoteVolume:Number(k[7]),takerBuyBase:Number(k[9]),closed:Number(k[6])<stamp}));
  const checked=validateKlineRows(mapped);
  if(!checked.valid)throw new Error(`${symbol} ${interval}: ${checked.reason||'geçerli mum verisi yok'}`);
  const data=checked.rows;
  cache.set(key,{at:stamp,data});return data;
}
