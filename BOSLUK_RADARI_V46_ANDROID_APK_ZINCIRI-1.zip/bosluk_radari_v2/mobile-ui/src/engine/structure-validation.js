import {buildResistanceMap} from './structure.js';

/**
 * Historical, prefix-only support/resistance evaluation.
 * Levels at bar t are built from candles[0..t]; outcome starts at t+1.
 * A response is recorded on the first confirmed close-through or touch/rejection.
 */
export function evaluateSupportResistanceHistory(candles,{
 horizon=12,minHistory=40,nearPct=5,touchPct=.6,breakPct=.25,maxEvents=5000
}={}){
 const cs=candles.filter(c=>c.closed),events=[];
 if(!Number.isInteger(horizon)||horizon<1||!Number.isInteger(minHistory)||minHistory<30||cs.length<minHistory+horizon+1)
  return {events:[],summary:{},method:{lookahead:false,reason:'Yetersiz kapanmış mum geçmişi'}};
 for(let i=minHistory;i<cs.length-horizon&&events.length<maxEvents;i++){
  const price=cs[i].close,map=buildResistanceMap(cs.slice(0,i+1),price);
  const candidates=[
   {kind:'SUPPORT',zone:map.first_support,side:'support'},
   {kind:'RESISTANCE',zone:map.first_obstacle,side:'resistance'}
  ];
  for(const item of candidates){
   const z=item.zone;if(!z||!Number.isFinite(z.price))continue;
   const distance=Math.abs(z.price/price-1)*100;
   if(distance>nearPct)continue;
   // Entry event is created only on a fresh approach into the proximity band.
   const prev=cs[i-1]?.close??price,prevDistance=Math.abs(z.price/prev-1)*100;
   if(prevDistance<=nearPct&&i>minHistory)continue;
   let outcome='NO_TOUCH',bars=null,extreme=0;
   for(let j=i+1;j<=i+horizon;j++){
    const c=cs[j],tol=z.price*touchPct/100,buffer=z.price*breakPct/100;
    if(item.side==='support'){
     extreme=Math.min(extreme,(c.low/z.price-1)*100);
     if(c.close<z.price-buffer){outcome='BROKEN';bars=j-i;break;}
     if(c.low<=z.price+tol&&c.close>z.price){outcome='BOUNCE';bars=j-i;break;}
    }else{
     extreme=Math.max(extreme,(c.high/z.price-1)*100);
     if(c.close>z.price+buffer){outcome='BROKEN';bars=j-i;break;}
     if(c.high>=z.price-tol&&c.close<z.price){outcome='REJECTED';bars=j-i;break;}
    }
   }
   events.push({index:i,kind:item.kind,level:z.price,distance_pct:distance,touches:z.touches,strength:z.strength,outcome,bars,extreme_pct:extreme});
   if(events.length>=maxEvents)break;
  }
 }
 const summary={};
 for(const e of events){
  const key=e.kind,x=summary[key]??={events:0,bounce:0,rejected:0,broken:0,no_touch:0,avg_bars_to_response:0,_bars:0};
  x.events++;
  if(e.outcome==='BOUNCE')x.bounce++;
  else if(e.outcome==='REJECTED')x.rejected++;
  else if(e.outcome==='BROKEN')x.broken++;
  else x.no_touch++;
  if(e.bars!==null){x.avg_bars_to_response+=e.bars;x._bars++;}
 }
 for(const x of Object.values(summary)){
  x.avg_bars_to_response=x._bars?x.avg_bars_to_response/x._bars:null;
  delete x._bars;
  x.response_rate_pct=x.events?(x.bounce+x.rejected)/x.events*100:null;
  x.break_rate_pct=x.events?x.broken/x.events*100:null;
 }
 return {events,summary,method:{lookahead:false,horizon,min_history:minHistory,near_pct:nearPct,touch_pct:touchPct,break_pct:breakPct,entry_uses_prefix_only:true,outcomes_start_next_candle:true,overlapping_events_allowed:true}};
}
