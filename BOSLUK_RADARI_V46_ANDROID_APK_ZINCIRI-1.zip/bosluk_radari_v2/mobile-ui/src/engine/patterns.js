const mean=xs=>xs.length?xs.reduce((a,b)=>a+b,0)/xs.length:0;
const slope=xs=>{const n=xs.length,mx=(n-1)/2,my=mean(xs);let a=0,b=0;xs.forEach((v,i)=>{a+=(i-mx)*(v-my);b+=(i-mx)**2;});return b?a/b:0;};

const pivots=(xs,kind)=>{const out=[];for(let i=2;i<xs.length-2;i++){const v=xs[i][kind];if(xs.slice(i-2,i).every(x=>kind==='high'?v>x[kind]:v<x[kind])&&xs.slice(i+1,i+3).every(x=>kind==='high'?v>=x[kind]:v<=x[kind]))out.push({i,v});}return out;};
const pct=(a,b)=>Math.abs(a-b)/Math.max(Math.abs(b),1e-12);

export function detectPatterns(candles){
 const c=candles.filter(x=>x.closed);if(c.length<80)return [];
 const last=c.at(-1),r=c.slice(-30),o=c.slice(-60,-30),rh=Math.max(...r.map(x=>x.high)),rl=Math.min(...r.map(x=>x.low)),oh=Math.max(...o.map(x=>x.high)),ol=Math.min(...o.map(x=>x.low));
 const range=(rh-rl)/Math.max(last.close,1e-12),old=(oh-ol)/Math.max(mean(o.map(x=>x.close)),1e-12),hs=slope(r.map(x=>x.high)),ls=slope(r.map(x=>x.low)),vr=mean(r.slice(-10).map(x=>x.volume))/Math.max(mean(r.slice(0,20).map(x=>x.volume)),1e-12),out=[];
 if(hs<=last.close*.0005&&ls>0&&range<.18)out.push({name:'YÜKSELEN ÜÇGEN',confidence:'ORTA',reason:'Yatay tepe ve yükselen dipler'});
 if(range<old*.72&&range<.12)out.push({name:'SIKIŞMA / COIL',confidence:'ORTA',reason:'Son 30 mumun fiyat aralığı daralıyor'});
 if(hs<0&&ls<0&&Math.abs(hs-ls)<last.close*.001)out.push({name:'DÜŞEN KAMA ADAYI',confidence:'DÜŞÜK',reason:'Daralan aşağı eğimli kanal; teyit gerekli'});
 const ph=Math.max(...c.slice(-25,-5).map(x=>x.high)),pl=Math.min(...c.slice(-25,-5).map(x=>x.low));
 if((ph-pl)/Math.max(pl,1e-12)>.12&&range<.10&&vr<1.25)out.push({name:'BAYRAK ADAYI',confidence:'DÜŞÜK',reason:'Önceki sert hareket sonrası dar konsolidasyon'});

 // Cup-and-handle candidate: broad recovery to rim plus a shallow right-side pullback.
 const cup=c.slice(-90),rim=Math.max(...cup.slice(0,12).map(x=>x.high),...cup.slice(-18,-6).map(x=>x.high));
 const bottomIndex=cup.reduce((best,x,i)=>x.low<cup[best].low?i:best,0),bottom=cup[bottomIndex].low;
 const rightPull=cup.slice(-6),handleLow=Math.min(...rightPull.map(x=>x.low)),handleHigh=Math.max(...rightPull.map(x=>x.high));
 if(bottomIndex>=15&&bottomIndex<=68&&cup.at(-1).close>=rim*.94&&bottom<rim*.88&&handleLow>=rim*.82&&handleHigh<=rim*1.03)
  out.push({name:'FİNCAN-KULP ADAYI',confidence:'DÜŞÜK',reason:'Yuvarlak dip ve sığ sağ kulp yapısı; boyun çizgisi kapanış teyidi gerekli'});
 // Inverse head-and-shoulders from swing lows; neckline breakout is not assumed.
 const lows=pivots(c.slice(-75),'low');
 if(lows.length>=3){const t=lows.slice(-3),[l,h,r]=t;if(h.v<l.v*.985&&h.v<r.v*.985&&pct(l.v,r.v)<.06&&h.i-l.i>=4&&r.i-h.i>=4)
  out.push({name:'TERS OMUZ-BAŞ-OMUZ ADAYI',confidence:'ORTA',reason:'Üç salınım dibi ve daha derin orta dip; boyun çizgisi kırılımı teyit edilmeli'});}
 // Bull flag: impulse pole followed by a short downward, contracting channel.
 const pole=c.slice(-35,-20),flag=c.slice(-20),poleLow=Math.min(...pole.map(x=>x.low)),poleHigh=Math.max(...pole.map(x=>x.high));
 const poleGain=(poleHigh-poleLow)/Math.max(poleLow,1e-12),fh=slope(flag.map(x=>x.high)),fl=slope(flag.map(x=>x.low));
 const flagRange=(Math.max(...flag.map(x=>x.high))-Math.min(...flag.map(x=>x.low)))/Math.max(flag.at(-1).close,1e-12);
 if(poleGain>=.12&&fh<0&&fl<0&&flagRange<poleGain*.65&&flag.at(-1).close>poleLow*1.08)
  out.push({name:'BOĞA BAYRAĞI ADAYI',confidence:'ORTA',reason:'Yukarı impuls sonrası daralan aşağı eğimli dinlenme'});
 // Pennant: impulse followed by converging highs and lows.
 if(poleGain>=.12&&fh<0&&fl>0&&flagRange<poleGain*.6&&flag.at(-1).close>poleLow*1.08)
  out.push({name:'FLAMA ADAYI',confidence:'DÜŞÜK',reason:'Güçlü impuls sonrası yakınsayan fiyat aralığı'});
 // Rising wedge is a caution, not a bullish continuation signal.
 if(hs>0&&ls>hs*1.15&&range<.15)
  out.push({name:'YÜKSELEN KAMA / ZAYIFLAMA',confidence:'ORTA',reason:'Yükselen fakat daralan yapı; boğa devamı varsayılmaz',risk:true});
 return out;
}
