import {detectPatterns} from './patterns.js';

const mean=xs=>xs.length?xs.reduce((a,b)=>a+b,0)/xs.length:0;
const emaLast=(values,period)=>{
 if(values.length<period)return null;
 let v=mean(values.slice(0,period)),alpha=2/(period+1);
 for(let i=period;i<values.length;i++)v=values[i]*alpha+v*(1-alpha);
 return v;
};

/** Classify BTC market using only the BTC candles available at this timestamp. */
export function classifyHistoricalMarketRegime(btcCandles){
 const c=(btcCandles||[]).filter(x=>x.closed);
 if(c.length<200)return 'UNKNOWN';
 const closes=c.map(x=>x.close),price=closes.at(-1),e50=emaLast(closes,50),e200=emaLast(closes,200);
 const prior=closes.at(-21),return20=prior>0?(price/prior-1)*100:0;
 if(price>e200&&e50>e200&&return20>0)return 'BULL';
 if(price<e200&&e50<e200&&return20<0)return 'BEAR';
 return 'SIDEWAYS';
}

/**
 * Chronological prefix-only pattern evaluation.
 * A pattern at t sees only candles[0..t]; outcomes use t+1..t+horizon.
 * BTC regime is matched by candle openTime and uses only BTC candles through t.
 * Same-bar stop/target is conservatively stop-first.
 */
export function evaluatePatternHistory(candles,{
  horizon=30,targetPct=.10,stopPct=.06,minHistory=100,feePct=.001,maxEvents=500,
  marketCandles=[]
}={}){
 const cs=candles.filter(c=>c.closed),btc=(marketCandles||[]).filter(c=>c.closed);
 const btcByTime=new Map(btc.map((c,i)=>[c.openTime??i,i]));
 const events=[];
 if(!Number.isInteger(horizon)||horizon<1||!Number.isInteger(minHistory)||minHistory<40||cs.length<minHistory+horizon+1)
  return {signals:0,events:[],summary:{},by_regime:{},method:{lookahead:false,reason:'Yetersiz kapanmış mum geçmişi'}};
 for(let i=minHistory;i<cs.length-horizon&&events.length<maxEvents;i++){
  const found=detectPatterns(cs.slice(0,i+1));
  const t=cs[i].openTime??i,btcIndex=btcByTime.get(t);
  const regime=btcIndex==null?'UNKNOWN':classifyHistoricalMarketRegime(btc.slice(0,btcIndex+1));
  for(const pattern of found){
   if(pattern.risk)continue;
   const rawEntry=cs[i].close,entry=rawEntry*(1+feePct),target=entry*(1+targetPct),stop=entry*(1-stopPct);
   let outcome='UNRESOLVED',bars=null,exitPrice=null;
   const future=cs.slice(i+1,i+horizon+1);
   let maxHigh=rawEntry,minLow=rawEntry;
   for(let k=0;k<future.length;k++){
    const candle=future[k];maxHigh=Math.max(maxHigh,candle.high);minLow=Math.min(minLow,candle.low);
    const hitStop=candle.low<=stop,hitTarget=candle.high>=target;
    if(hitStop&&hitTarget){outcome='STOP_FIRST_SAME_BAR';bars=k+1;exitPrice=stop;break;}
    if(hitStop){outcome='STOP';bars=k+1;exitPrice=stop;break;}
    if(hitTarget){outcome='TARGET';bars=k+1;exitPrice=target;break;}
   }
   if(exitPrice===null)exitPrice=future.at(-1).close;
   const netReturnPct=(exitPrice/rawEntry-1)*100-feePct*2*100;
   events.push({index:i,open_time:t,pattern:pattern.name,market_regime:regime,entry:rawEntry,target,stop,outcome,bars,
    mfe_pct:(maxHigh/rawEntry-1)*100,mae_pct:(minLow/rawEntry-1)*100,net_return_pct:netReturnPct});
   if(events.length>=maxEvents)break;
  }
 }
 const summarize=rows=>{
  const x={signals:rows.length,target:0,stop:0,unresolved:0,_net:[],_mfe:[],_mae:[]};
  for(const e of rows){if(e.outcome==='TARGET')x.target++;else if(e.outcome==='STOP'||e.outcome==='STOP_FIRST_SAME_BAR')x.stop++;else x.unresolved++;x._net.push(e.net_return_pct);x._mfe.push(e.mfe_pct);x._mae.push(e.mae_pct);}
  x.target_rate_pct=x.signals?x.target/x.signals*100:null;x.stop_rate_pct=x.signals?x.stop/x.signals*100:null;
  x.avg_net_return_pct=mean(x._net);x.avg_mfe_pct=mean(x._mfe);x.avg_mae_pct=mean(x._mae);
  delete x._net;delete x._mfe;delete x._mae;return x;
 };
 const byPattern=new Map(),byRegime={};
 for(const e of events){
  if(!byPattern.has(e.pattern))byPattern.set(e.pattern,[]);
  byPattern.get(e.pattern).push(e);
  (byRegime[e.market_regime]??={})[e.pattern]??=[];
  byRegime[e.market_regime][e.pattern].push(e);
 }
 const summary=Object.fromEntries([...byPattern].map(([name,rows])=>[name,summarize(rows)]));
 for(const regime of Object.keys(byRegime))for(const name of Object.keys(byRegime[regime]))byRegime[regime][name]=summarize(byRegime[regime][name]);
 return {signals:events.length,events,summary,by_regime:byRegime,method:{horizon,target_pct:targetPct*100,stop_pct:stopPct*100,fee_pct:feePct*100,lookahead:false,entry_uses_prefix_only:true,outcomes_start_next_candle:true,btc_regime_uses_same_timestamp_prefix:true,regime_definition:'BULL: BTC close>EMA200, EMA50>EMA200, 20-bar return>0; BEAR inverse; otherwise SIDEWAYS; UNKNOWN if <200 BTC candles',overlap_allowed:true,stop_first_same_bar:true,unresolved_marked_to_market:true}};
}
