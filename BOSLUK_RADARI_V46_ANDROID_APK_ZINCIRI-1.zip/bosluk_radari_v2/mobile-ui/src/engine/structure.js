const avg=xs=>xs.reduce((a,b)=>a+b,0)/Math.max(xs.length,1);
function pivotClusters(c,side,price){
 const pivots=[];
 for(let i=2;i<c.length-2;i++){
  const v=c[i][side],isPivot=side==='high'
   ?v>c[i-1].high&&v>c[i-2].high&&v>=c[i+1].high&&v>=c[i+2].high
   :v<c[i-1].low&&v<c[i-2].low&&v<=c[i+1].low&&v<=c[i+2].low;
  if(isPivot&&(side==='high'?v>price*1.002:v<price*.998))pivots.push({price:v,index:i});
 }
 const clusters=[];
 for(const item of pivots.sort((a,b)=>a.price-b.price)){
  const z=clusters.at(-1);
  if(z&&Math.abs(item.price-z.price)/z.price<.012){z.items.push(item);z.price=avg(z.items.map(x=>x.price));}
  else clusters.push({price:item.price,items:[item]});
 }
 return clusters.map(z=>{
  const last=z.items.reduce((a,b)=>b.index>a.index?b:a,z.items[0]);
  const touches=z.items.length,recency=c.length-1-last.index;
  const strength=touches>=4?'GÜÇLÜ':touches>=2?'ORTA':'ZAYIF';
  return {price:z.price,touches,recency_bars:recency,strength,distance_pct:(z.price/price-1)*100};
 });
}
export function buildResistanceMap(candles,price){
 const c=candles.filter(x=>x.closed).slice(-180);
 if(c.length<30||!(price>0))return {first_obstacle:null,levels:[],first_support:null,support_levels:[],theoretical_gaps:[]};
 const levels=pivotClusters(c,'high',price).sort((a,b)=>a.price-b.price);
 const support_levels=pivotClusters(c,'low',price).sort((a,b)=>b.price-a.price);
 const first=levels[0]||null,firstSupport=support_levels[0]||null;
 return {first_obstacle:first,levels,first_support:firstSupport,support_levels,
  theoretical_gaps:[50,100,200].map(pct=>{const target=price*(1+pct/100),blocker=levels.find(x=>x.price<=target);return {distance_pct:pct,target_price:target,blocked_by:blocker?.price??null,clear:!blocker};})};
}
export function classifyBreakoutAttempt(candles,level,{minRvol=1.5,lookback=8,closePositionMin=.65}={}){
 const c=candles.filter(x=>x.closed);
 if(c.length<25||!(level>0))return {state:'KIRILIM VERİSİ YETERSİZ',confirmed:false,false_breakout:false,invalidated:false};
 const start=Math.max(20,c.length-lookback),events=[];
 for(let i=start;i<c.length;i++){
  const x=c[i],prior=c.slice(Math.max(0,i-20),i),avgVol=avg(prior.map(y=>y.volume));
  const rvol=avgVol>0?x.volume/avgVol:0,range=Math.max(x.high-x.low,1e-12),closePosition=(x.close-x.low)/range;
  const wickAbove=x.high>level*1.002,closeAbove=x.close>level*1.002;
  if(wickAbove&&!closeAbove){
   events.push({index:i,type:'WICK_REJECTION',rvol,close_position:closePosition});
  }else if(closeAbove){
   events.push({index:i,type:rvol>=minRvol&&closePosition>=closePositionMin?'CLOSE_CONFIRMED':'CLOSE_WEAK',rvol,close_position:closePosition});
  }
 }
 const confirmedEvents=events.filter(x=>x.type==='CLOSE_CONFIRMED');
 const e=confirmedEvents.at(-1)||events.at(-1);
 if(!e)return {state:'KIRILIM GİRİŞİ YOK',confirmed:false,false_breakout:false,invalidated:false};
 if(e.type==='WICK_REJECTION')return {state:'FITIL TUZAĞI / DİRENÇ REDDİ',confirmed:false,false_breakout:true,invalidated:false,signal_index:e.index,rvol:e.rvol,close_position:e.close_position,level};
 if(e.type==='CLOSE_WEAK')return {state:'ZAYIF KAPANIŞ / TEYİT YOK',confirmed:false,false_breakout:false,invalidated:false,signal_index:e.index,rvol:e.rvol,close_position:e.close_position,level};
 const later=c.slice(e.index+1);
 const invalidated=later.some(x=>x.close<level*.997);
 if(invalidated)return {state:'KIRILIM GEÇERSİZ / GERİ DÖNÜŞ',confirmed:false,false_breakout:true,invalidated:true,signal_index:e.index,rvol:e.rvol,close_position:e.close_position,level};
 const held=c.at(-1).close>level;
 return {state:held?'KAPANIŞ + HACİM TEYİDİ':'KIRILIM SONRASI TUTUNAMADI',confirmed:held,false_breakout:!held,invalidated:!held,signal_index:e.index,rvol:e.rvol,close_position:e.close_position,level};
}
export function detectBreakoutRetest(candles,level,minRvol=1.5){
 const c=candles.filter(x=>x.closed);if(c.length<25||!(level>0))return {breakout:false,retest:false,state:'YOK'};
 const avgVol=avg(c.slice(-21,-1).map(x=>x.volume)),idx=c.findIndex((x,i)=>i>=c.length-8&&x.close>level*1.002&&x.volume/Math.max(avgVol,1e-12)>=minRvol);
 if(idx<0)return {breakout:false,retest:false,state:'KIRILIM YOK'};
 const retest=c.slice(idx+1).some(x=>x.low<=level*1.01&&x.close>level&&x.close>x.open);
 return {breakout:true,retest,state:retest?'KIRILIM + RETEST':'KIRILIM TEYİDİ BEKLİYOR',level};
}
export function approximateVolumeProfile(candles,bins=24){
 const c=candles.filter(x=>x.closed).slice(-120);if(!c.length)return {poc:null,bins:[]};
 const lo=Math.min(...c.map(x=>x.low)),hi=Math.max(...c.map(x=>x.high));if(!(hi>lo))return {poc:lo,bins:[]};
 const w=(hi-lo)/bins,rows=Array.from({length:bins},(_,i)=>({from:lo+i*w,to:lo+(i+1)*w,volume:0}));
 for(const x of c){const a=Math.max(0,Math.floor((x.low-lo)/w)),b=Math.min(bins-1,Math.floor((x.high-lo)/w)),share=x.volume/Math.max(1,b-a+1);for(let i=a;i<=b;i++)rows[i].volume+=share;}
 const p=rows.reduce((a,b)=>b.volume>a.volume?b:a,rows[0]);return {poc:(p.from+p.to)/2,bins:rows};
}
