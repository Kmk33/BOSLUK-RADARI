/**
 * Historical breakout follow-through evaluator.
 * Each signal is computed from candles up to and including its close.
 * Outcomes are measured only on subsequent closed candles.
 */
const mean = xs => xs.reduce((a,b)=>a+b,0) / Math.max(xs.length, 1);

export function evaluateBreakoutFollowThrough(candles, {
  minHistory = 60,
  resistanceLookback = 30,
  volumeLookback = 20,
  horizon = 12,
  minRvol = 1.5,
  closePositionMin = 0.65,
  breakoutBufferPct = 0.2,
  stopPct = 2,
  targetsPct = [1, 2, 5],
  feePct = 0.1,
  slippagePct = 0.05,
  maxEvents = 500
} = {}) {
  const cs = candles.filter(c => c.closed);
  const empty = { events: [], summary: {}, method: { lookahead: false, reason: 'Yetersiz kapanmış mum geçmişi' } };
  if (!Number.isInteger(horizon) || horizon < 1 ||
      !Number.isInteger(minHistory) || minHistory < 30 ||
      cs.length < minHistory + horizon + 1) return empty;

  const events = [];
  const costPct = feePct * 2 + slippagePct * 2;
  for (let i = Math.max(minHistory, resistanceLookback, volumeLookback); i < cs.length - horizon && events.length < maxEvents; i++) {
    const current = cs[i];
    const prior = cs.slice(Math.max(0, i - resistanceLookback), i);
    const resistance = Math.max(...prior.map(c => c.high));
    const volumeBase = mean(cs.slice(i - volumeLookback, i).map(c => c.volume));
    const rvol = volumeBase > 0 ? current.volume / volumeBase : 0;
    const range = Math.max(current.high - current.low, 1e-12);
    const closePosition = (current.close - current.low) / range;
    const threshold = resistance * (1 + breakoutBufferPct / 100);
    const crossed = current.close > threshold && cs[i - 1].close <= threshold;
    if (!crossed || rvol < minRvol || closePosition < closePositionMin) continue;

    const entry = current.close;
    const future = cs.slice(i + 1, i + horizon + 1);
    let maxHigh = entry, minLow = entry, firstTarget = null, stopHit = false, outcome = 'UNRESOLVED';
    let barsToTarget = null, barsToStop = null;
    const targetHits = Object.fromEntries(targetsPct.map(t => [String(t), false]));
    for (let k = 0; k < future.length; k++) {
      const c = future[k];
      maxHigh = Math.max(maxHigh, c.high);
      minLow = Math.min(minLow, c.low);
      const stop = c.low <= entry * (1 - stopPct / 100);
      const hitTargets = targetsPct.filter(t => c.high >= entry * (1 + t / 100));
      // Conservative same-candle rule: stop is assumed first if stop and target overlap.
      if (stop && !stopHit) { stopHit = true; barsToStop = k + 1; }
      if (hitTargets.length && firstTarget === null && !stop) {
        firstTarget = Math.min(...hitTargets);
        barsToTarget = k + 1;
      }
      for (const t of hitTargets) targetHits[String(t)] = true;
      if (stopHit && (firstTarget !== null || hitTargets.length)) { outcome = 'STOP_FIRST / AYNI MUM BELİRSİZ'; break; }
      if (stopHit) { outcome = 'FAILED'; break; }
      if (firstTarget !== null) { outcome = 'TARGET_REACHED'; break; }
    }
    const mfePct = (maxHigh / entry - 1) * 100;
    const maePct = (minLow / entry - 1) * 100;
    const retracementPct = maxHigh > entry ? (maxHigh - Math.min(maxHigh, future.at(-1)?.close ?? maxHigh)) / (maxHigh - entry) * 100 : 0;
    events.push({
      index: i, entry, resistance, rvol, close_position: closePosition,
      horizon_bars: horizon, observed_bars: future.length, outcome,
      mfe_pct: mfePct, mae_pct: maePct, retracement_pct: retracementPct,
      net_mfe_pct: mfePct - costPct, cost_pct: costPct,
      first_target_pct: firstTarget, bars_to_target: barsToTarget, bars_to_stop: barsToStop,
      targets_hit: targetHits
    });
  }

  const summary = {
    events: events.length,
    failed: events.filter(e => e.outcome === 'FAILED' || e.outcome.startsWith('STOP_FIRST')).length,
    target_reached: events.filter(e => e.outcome === 'TARGET_REACHED').length,
    unresolved: events.filter(e => e.outcome === 'UNRESOLVED').length,
    avg_mfe_pct: events.length ? mean(events.map(e => e.mfe_pct)) : null,
    avg_mae_pct: events.length ? mean(events.map(e => e.mae_pct)) : null,
    avg_retracement_pct: events.length ? mean(events.map(e => e.retracement_pct)) : null,
    target_hit_rate_pct: Object.fromEntries(targetsPct.map(t => [String(t), events.length ? events.filter(e => e.targets_hit[String(t)]).length / events.length * 100 : null]))
  };
  return {
    events, summary,
    method: {
      lookahead: false, entry_on_closed_candle: true, outcomes_start_next_candle: true,
      resistance_uses_prior_candles_only: true, horizon, min_history: minHistory,
      resistance_lookback: resistanceLookback, volume_lookback: volumeLookback,
      min_rvol: minRvol, close_position_min: closePositionMin, stop_pct: stopPct,
      targets_pct: targetsPct, round_trip_fee_pct: feePct * 2,
      round_trip_slippage_pct: slippagePct * 2,
      same_candle_stop_target_rule: 'STOP_FIRST'
    }
  };
}
