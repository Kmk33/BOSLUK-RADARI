import {getSpotUniverse,getKlines} from './binance.js';
import {analyzeCandles} from './indicators.js';
import {detectPatterns} from './patterns.js';
import {buildResistanceMap,detectBreakoutRetest,approximateVolumeProfile,classifyBreakoutAttempt} from './structure.js';
import {evaluateSupportResistanceHistory} from './structure-validation.js';
import {evaluateBreakoutFollowThrough} from './breakout-validation.js';
import {evaluatePatternHistory} from './pattern-validation.js';
export function scanIncludesTimeframe(payload,timeframe){return Array.isArray(payload?.scan_meta?.timeframes)&&payload.scan_meta.timeframes.includes(timeframe);}
export function classifyBtcMarket(frames){
 const list=Object.values(frames||{});if(!list.length)return {state:'VERİ YOK',bearish:false,bullish:false,frames:[]};
 const bearish=list.filter(x=>x&&x.price<x.ema200&&x.ema50<x.ema200&&x.rsi<48).length;
 const bullish=list.filter(x=>x&&x.price>x.ema200&&x.ema50>x.ema200&&x.rsi>50).length;
 return {state:bearish>=2?'BTC RİSKLİ':bullish>=2?'BTC POZİTİF':'BTC NÖTR',bearish:bearish>=2,bullish:bullish>=2,frames:list.length};
}
export const TIMEFRAMES=[{key:'1_saat',interval:'1h'},{key:'4_saat',interval:'4h'},{key:'1_gun',interval:'1d'},{key:'1_hafta',interval:'1w'},{key:'1_ay',interval:'1M'}];
const pause=ms=>new Promise(r=>setTimeout(r,ms));
export function classifyScanError(message=''){
 const m=String(message).toLowerCase();
 if(/429|418|hız sınırı|rate limit/.test(m))return 'RATE_LIMIT';
 if(/timeout|abort|zaman aş/.test(m))return 'TIMEOUT';
 if(/network|fetch|failed to fetch|ağ hatası|ulaşılamadı|dns/.test(m))return 'NETWORK';
 if(/http 4|http 5/.test(m))return 'HTTP';
 if(/geçerli mum|mum yanıtı|bozuk/.test(m))return 'DATA_QUALITY';
 return 'UNKNOWN';
}
export function summarizeScanResults(results,jobs){
 const failures=[];
 for(let i=0;i<results.length;i++){
  const r=results[i];
  if(r?.error)failures.push({symbol:jobs[i]?.coin?.symbol,timeframe:jobs[i]?.tf?.key,category:classifyScanError(r.error),message:String(r.error).slice(0,180)});
  else if(r===null)failures.push({symbol:jobs[i]?.coin?.symbol,timeframe:jobs[i]?.tf?.key,category:'INSUFFICIENT_DATA',message:'Analiz için 220 kapanmış mum bulunamadı'});
 }
 const counts={};for(const f of failures)counts[f.category]=(counts[f.category]||0)+1;
 return {completed:results.filter(x=>x&&!x.error).length,failed:results.filter(x=>x?.error).length,insufficient:results.filter(x=>x===null).length,failures:failures.slice(0,30),failure_counts:counts};
}
export function combineFrameAnalyses(symbol,frames){
 const list=Object.values(frames||{});if(!list.length)return null;
 const risk=list.some(x=>x.downside_risk),falseBreakout=list.some(x=>x.breakout_quality?.false_breakout||x.breakout_quality?.invalidated),breakout=list.some(x=>x.breakout),retest=list.some(x=>x.retest?.retest),prep=list.some(x=>x.squeeze||(x.patterns||[]).some(p=>!p.risk));
 const scores=list.map(x=>x.score).sort((a,b)=>b-a);
 const qualityScore=Math.round((scores.slice(0,3).reduce((a,b)=>a+b,0)/Math.max(1,Math.min(3,scores.length)))*.8+Math.min(20,Math.max(0,list.length-1)*5));
 const resistance=list.map(x=>x.resistance_map?.first_obstacle).filter(Boolean).sort((a,b)=>a.distance_pct-b.distance_pct)[0];
 const support=list.map(x=>x.resistance_map?.first_support).filter(Boolean).sort((a,b)=>Math.abs(a.distance_pct)-Math.abs(b.distance_pct))[0];
 const price=list.find(x=>x.timeframe==='1_saat')?.price??list[0].price;
 const market=list.find(x=>x.market_filter)?.market_filter;
 const marketCaution=!!market?.bearish;
 const signal=risk?'RİSK / ELENDİ':falseBreakout?'SAHTE KIRILIM / RED':breakout?'TEYİTLİ KIRILIM':prep?(marketCaution?'İZLEME':'FORMASYON / HAZIRLIK'):'İZLEME';
 const patternRisk=list.some(x=>(x.patterns||[]).some(p=>p.risk));
 const adjustedScore=Math.max(0,qualityScore-(marketCaution?12:0)-(falseBreakout?10:0));
 return {symbol,rank_score:risk?0:adjustedScore,combined:{signal_state:signal,reference_price:price,target_gap_pct:resistance?.distance_pct??null,first_resistance:resistance?.price??null,first_support:support?.price??null,support_gap_pct:support?.distance_pct??null,retest_confirmed:retest,quality_score:risk?0:adjustedScore,pattern_risk:patternRisk,market_caution:marketCaution,confluence:list.length,false_breakout:falseBreakout,bias:risk?'Aşağı yönlü risk var':falseBreakout?'Direnç üstü hareket reddedildi; teyit yok':marketCaution?'BTC genel görünümü zayıf; teyit bekle':retest?'Kırılım ve retest görüldü':breakout?'Kapanış onaylı kırılım':prep?'Formasyon / sıkışma adayı':'İzleme',timeframes:list.map(x=>x.timeframe)},timeframes:frames,diagnostics:{risk_timeframes:list.filter(x=>x.downside_risk).map(x=>x.timeframe),false_breakout_timeframes:list.filter(x=>x.breakout_quality?.false_breakout||x.breakout_quality?.invalidated).map(x=>x.timeframe)}};
}

async function pool(items,workers,fn,onProgress){let cursor=0,done=0;const out=[];await Promise.all(Array.from({length:workers},async()=>{while(true){const i=cursor++;if(i>=items.length)return;try{out[i]=await fn(items[i],i);}catch(error){out[i]={error:error.message};}done++;onProgress?.(done,items.length,items[i]);await pause(120);}}));return out;}
export async function runSpotScan({timeframe='all',limit=30,onProgress=()=>{}}={}){
  const scanStarted=Date.now();
  const universe=await getSpotUniverse(limit);
  if(!universe.length)throw new Error('Filtrelere uyan Spot USDT paritesi bulunamadı.');
  const tfs=timeframe==='all'?TIMEFRAMES:TIMEFRAMES.filter(t=>t.key===timeframe);
  if(!tfs.length)throw new Error('Zaman dilimi seçimi geçersiz.');

  let btcMarket={state:'BTC VERİSİ YOK',bearish:false,bullish:false,frames:0};
  const btcHistory={};
  const marketTfs=TIMEFRAMES.filter(x=>['1_saat','4_saat','1_gun'].includes(x.key));
  const neededIntervals=[...new Set([...tfs.map(x=>x.interval),...marketTfs.map(x=>x.interval)])];
  const btcFrames={};
  const btcErrors=[];
  // Fetch only the selected BTC history plus the three timeframes needed for the market filter.
  for(const interval of neededIntervals){
   const tf=TIMEFRAMES.find(x=>x.interval===interval);
   try{
    const raw=await getKlines('BTCUSDT',interval,230);
    btcHistory[interval]=raw.filter(x=>x.closed);
    if(tf&&['1_saat','4_saat','1_gun'].includes(tf.key)){
     const a=analyzeCandles('BTCUSDT',tf.key,raw);if(a)btcFrames[tf.key]=a;
    }
   }catch(error){btcErrors.push({interval,message:error.message});}
  }
  btcMarket=classifyBtcMarket(btcFrames);
  if(btcErrors.length)btcMarket={...btcMarket,state:'BTC VERİSİ KISMİ',errors:btcErrors};

  const jobs=universe.flatMap(coin=>tfs.map(tf=>({coin,tf})));
  let completed=0;
  const results=await pool(jobs,2,async({coin,tf})=>{
    const candles=await getKlines(coin.symbol,tf.interval,230);
    const analysis=analyzeCandles(coin.symbol,tf.key,candles);
    if(!analysis)return null;
    const closed=candles.filter(x=>x.closed);
    const patterns=detectPatterns(closed);
    const resistance_map=buildResistanceMap(closed,analysis.price);
    const breakout_quality=analysis.breakout_level?classifyBreakoutAttempt(closed,analysis.breakout_level):{confirmed:false,false_breakout:false,invalidated:false,state:'KIRILIM SEVİYESİ YOK'};
    const retest=analysis.breakout_level&&breakout_quality.confirmed?detectBreakoutRetest(closed,analysis.breakout_level):{breakout:false,retest:false,state:breakout_quality.state};
    const confirmedBreakout=!!breakout_quality.confirmed;
    const volume_profile=approximateVolumeProfile(closed);
    const structure_history=evaluateSupportResistanceHistory(closed,{horizon:12,minHistory:60,nearPct:5,maxEvents:250});
    const breakout_history=evaluateBreakoutFollowThrough(closed,{horizon:12,minHistory:60,maxEvents:250});
    const pattern_history=evaluatePatternHistory(closed,{horizon:20,targetPct:.05,stopPct:.03,minHistory:100,feePct:.001,maxEvents:250,marketCandles:btcHistory[tf.interval]||[]});
    return {...analysis,breakout:confirmedBreakout,breakout_quality,market_filter:btcMarket,chart_closes:closed.slice(-80).map(x=>x.close),patterns,resistance_map,retest,volume_profile,structure_history,breakout_history,pattern_history};
  },(done,total,job)=>{
    completed=done;
    try{onProgress({completed:done,total,symbol:job.coin.symbol,timeframe:job.tf.key});}catch{}
  });
  const bySymbol=new Map();
  for(let i=0;i<jobs.length;i++){
   const result=results[i];if(!result||result.error)continue;
   const sym=jobs[i].coin.symbol;if(!bySymbol.has(sym))bySymbol.set(sym,{});
   bySymbol.get(sym)[result.timeframe]=result;
  }
  const candidates=[];
  for(const [symbol,frames] of bySymbol){const combined=combineFrameAnalyses(symbol,frames);if(combined)candidates.push(combined);}
  candidates.sort((a,b)=>Number(a.combined.signal_state==='RİSK / ELENDİ')-Number(b.combined.signal_state==='RİSK / ELENDİ')||b.rank_score-a.rank_score);
  candidates.forEach((x,i)=>x.rank=i+1);
  const diagnostics=summarizeScanResults(results,jobs);
  const elapsed=Date.now()-scanStarted;
  return {
   universe_count:universe.length,candidates,
   scan_meta:{
    timeframes:tfs.map(x=>x.key),requested:jobs.length,completed:diagnostics.completed,
    failed:diagnostics.failed,insufficient:diagnostics.insufficient,
    failure_counts:diagnostics.failure_counts,failures:diagnostics.failures,
    source:'Binance Spot public REST',market_filter:btcMarket,
    duration_ms:elapsed,
    generated_at:new Date().toISOString()
   }
  };
}
