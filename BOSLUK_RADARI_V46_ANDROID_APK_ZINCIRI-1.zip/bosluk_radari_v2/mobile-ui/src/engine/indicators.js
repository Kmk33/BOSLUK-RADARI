export function ema(values,period){
 if(!Number.isInteger(period)||period<=0)throw new Error('EMA periyodu geçersiz');
 if(values.length<period)return null;
 let v=values.slice(0,period).reduce((a,b)=>a+b,0)/period;const alpha=2/(period+1);
 for(let i=period;i<values.length;i++)v=values[i]*alpha+v*(1-alpha);
 return v;
}
export function sma(values,period){if(values.length<period)return null;return values.slice(-period).reduce((a,b)=>a+b,0)/period;}
export function rsi(values,period=14){
 if(values.length<=period)return 50;let gains=0,losses=0;
 for(let i=values.length-period;i<values.length;i++){const d=values[i]-values[i-1];gains+=Math.max(d,0);losses+=Math.max(-d,0);}
 const ag=gains/period,al=losses/period;if(al===0)return ag>0?100:50;return 100-100/(1+ag/al);
}
export function stochasticRsi(values,period=14){
 if(values.length<period*2+1)return 50;
 const series=[];for(let end=period+1;end<=values.length;end++)series.push(rsi(values.slice(0,end),period));
 const window=series.slice(-period),lo=Math.min(...window),hi=Math.max(...window),last=window.at(-1);
 return hi===lo?50:(last-lo)/(hi-lo)*100;
}
export function macd(values){
 const e12=ema(values,12),e26=ema(values,26);if(e12==null||e26==null)return {line:null,signal:null,histogram:null};
 const diffs=[];for(let end=26;end<=values.length;end++){const a=ema(values.slice(0,end),12),b=ema(values.slice(0,end),26);diffs.push(a-b);}
 const signal=ema(diffs,9),line=e12-e26;return {line,signal,histogram:signal==null?null:line-signal};
}
export function atr(candles,period=14){
 if(candles.length<=period)return null;const tr=[];
 for(let i=1;i<candles.length;i++){const c=candles[i],prev=candles[i-1];tr.push(Math.max(c.high-c.low,Math.abs(c.high-prev.close),Math.abs(c.low-prev.close)));}
 return tr.slice(-period).reduce((a,b)=>a+b,0)/period;
}

export function vwap(candles){
 let pv=0,volume=0;
 for(const c of candles){const typical=(c.high+c.low+c.close)/3;pv+=typical*c.volume;volume+=c.volume;}
 return volume>0?pv/volume:null;
}
export function keltnerChannel(candles,period=20,multiplier=2){
 if(candles.length<period+1)return null;
 const closes=candles.map(c=>c.close),middle=ema(closes,period),range=atr(candles,period);
 if(middle==null||range==null)return null;
 return {middle,upper:middle+multiplier*range,lower:middle-multiplier*range,width_pct:middle>0?(4*multiplier*range/middle)*100:null};
}
export function volumePressure(candles,period=20){
 const rows=candles.slice(-period),total=rows.reduce((a,c)=>a+c.volume,0);
 if(total<=0)return {buy_ratio:0.5,sell_ratio:0.5,delta_ratio:0};
 const buy=rows.reduce((a,c)=>a+(Number.isFinite(c.takerBuyBase)?c.takerBuyBase:c.volume*(c.close>=c.open?0.6:0.4)),0);
 const ratio=buy/total;
 return {buy_ratio:ratio,sell_ratio:1-ratio,delta_ratio:2*ratio-1};
}

export function pivotLevels(candles,left=3,right=3){
 const highs=[],lows=[];
 for(let i=left;i<candles.length-right;i++){const c=candles[i];
 if(Array.from({length:left},(_,k)=>candles[i-left+k].high).every(v=>c.high>v)&&Array.from({length:right},(_,k)=>candles[i+1+k].high).every(v=>c.high>=v))highs.push(c.high);
 if(Array.from({length:left},(_,k)=>candles[i-left+k].low).every(v=>c.low<v)&&Array.from({length:right},(_,k)=>candles[i+1+k].low).every(v=>c.low<=v))lows.push(c.low);}
 return {highs,lows};
}

export function classifyBreakoutProximity(price,level,atrValue,rvol=1){
 if(!(price>0&&level>price&&atrValue>=0))return {state:'YAKIN DİRENÇ YOK',distance_pct:null,atr_distance:null};
 const distance=(level-price)/price*100,atrDistance=atrValue>0?(level-price)/atrValue:null;
 const state=distance<=0.8&&rvol>=1.1?'KIRILIMA ÇOK YAKIN':distance<=2.5?'KIRILIMA YAKLAŞIYOR':'DİRENÇTEN UZAK';
 return {state,distance_pct:distance,atr_distance:atrDistance};
}

export function analyzeCandles(symbol,timeframe,raw){
 const candles=raw.filter(c=>c.closed);if(candles.length<220)return null;
 const closes=candles.map(c=>c.close),vols=candles.map(c=>c.volume),last=candles.at(-1),price=last.close;
 const e7=ema(closes,7),e9=ema(closes,9),e20=ema(closes,20),e21=ema(closes,21),e50=ema(closes,50),e90=ema(closes,90),e100=ema(closes,100),e200=ema(closes,200),s20=sma(closes,20),s50=sma(closes,50),s100=sma(closes,100),s200=sma(closes,200);
 const avgVol=vols.slice(-21,-1).reduce((a,b)=>a+b,0)/20,rvol=avgVol>0?last.volume/avgVol:0;
 const w=closes.slice(-20),mid=sma(closes,20),sd=Math.sqrt(w.reduce((a,b)=>a+(b-mid)**2,0)/20),bbWidth=mid?4*sd/mid*100:0;
 const widths=[];for(let end=Math.max(20,closes.length-100);end<closes.length;end++){const a=closes.slice(end-20,end),m=a.reduce((x,y)=>x+y,0)/20;if(m){const d=Math.sqrt(a.reduce((x,y)=>x+(y-m)**2,0)/20);widths.push(4*d/m*100);}}
 const sorted=[...widths].sort((a,b)=>a-b),squeeze=!!sorted.length&&bbWidth<=sorted[Math.max(0,Math.floor(sorted.length*.2)-1)];
 const piv=pivotLevels(candles.slice(0,-1).slice(-180)),resistance=piv.highs.filter(x=>x>price*1.001).sort((a,b)=>a-b)[0]??null,support=piv.lows.filter(x=>x<price*.999&&x>price*.90).sort((a,b)=>b-a)[0]??null;
 const priorRes=piv.highs.slice(-5).reduce((a,b)=>Math.max(a,b),-Infinity),breakoutLevel=Number.isFinite(priorRes)?priorRes:null,breakout=breakoutLevel!=null&&price>breakoutLevel*1.002&&rvol>=1.5;
 const buyPressure=last.volume>0?last.takerBuyBase/last.volume:.5,volume_pressure=volumePressure(candles),vwapValue=vwap(candles),keltner=keltnerChannel(candles),rsiValue=rsi(closes),stochRsi=stochasticRsi(closes),macdData=macd(closes),atrValue=atr(candles);
 const downside=!!((support&&price<support*.995)||(price<e200&&e50<e200&&rsiValue<35));
 // Independent evidence buckets prevent counting several correlated moving averages as separate signals.
 const trend=price>e20&&e20>e50&&e50>e90&&e90>e200;
 const momentum=macdData.histogram!=null&&macdData.histogram>0&&rsiValue>=50&&rsiValue<=78;
 const trendPoints=trend?25:price>e50&&e50>e90?15:price>e200?8:0;
 const momentumPoints=momentum?15:(rsiValue>=45&&rsiValue<70?8:0);
 const volumePoints=(rvol>=1.5?12:0)+(buyPressure>=.55?8:0);
 const structurePoints=(squeeze?10:0)+(resistance&&((resistance-price)/price*100>=50)?10:0);
 const breakoutPoints=breakout?20:0;
 const quality=downside?0:trendPoints+momentumPoints+volumePoints+structurePoints+breakoutPoints;
 const gap=resistance?((resistance/price)-1)*100:null,breakout_proximity=classifyBreakoutProximity(price,resistance,atrValue,rvol),state=downside?'RİSK / ELENDİ':breakout?'TEYİTLİ KIRILIM':squeeze?'FORMASYON / HAZIRLIK':'İZLEME';
 return {symbol,timeframe,price,resistance,upside_pct:gap,breakout_proximity,support,breakout_level:breakoutLevel,rvol,rsi:rsiValue,stoch_rsi:stochRsi,macd:macdData,atr:atrValue,ema7:e7,ema9:e9,ema20:e20,ema21:e21,ema50:e50,ema90:e90,ema100:e100,ema200:e200,vwap:vwapValue,keltner,volume_pressure,sma20:s20,sma50:s50,sma100:s100,sma200:s200,bb_width_pct:bbWidth,buy_pressure:buyPressure,breakout,squeeze,downside_risk:downside,score:quality,quality_buckets:{trend:trendPoints,momentum:momentumPoints,volume:volumePoints,structure:structurePoints,breakout:breakoutPoints},state,reasons:[...(trend?['EMA trend dizilimi olumlu']:[]),...(momentum?['MACD histogram ve RSI momentumu olumlu']:[]),...(squeeze?['Bollinger sıkışması']:[]),...(rvol>=1.5?[`RVOL ${rvol.toFixed(2)}`]:[]),...(buyPressure>=.55?['Alıcı hacmi baskın']:[]),...(breakout?['Kapanışla hacimli direnç kırılımı']:[])]};
}
