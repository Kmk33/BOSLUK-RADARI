import {loadAlertSettings,saveAlertSettings,loadAlertEvents,saveAlertEvents} from './local-store.js';
export function selectNewBreakoutAlerts(payload,previousSymbols=[]){
 const seen=new Set(previousSymbols);
 return (payload?.candidates||[]).filter(x=>x.combined?.signal_state==='TEYİTLİ KIRILIM'&&!seen.has(x.symbol)&&!x.diagnostics?.risk_timeframes?.length)
  .map(x=>({symbol:x.symbol,score:x.combined?.quality_score??0,price:x.combined?.reference_price??null,gap:x.combined?.target_gap_pct??null,at:new Date().toISOString()}));
}
export async function requestAlertPermission(){
 try{
  const {LocalNotifications}=await import('@capacitor/local-notifications');
  const current=await LocalNotifications.checkPermissions();
  if(current.display==='granted')return true;
  const result=await LocalNotifications.requestPermissions();
  return result.display==='granted';
 }catch{return false;}
}
export async function sendBreakoutAlerts(events){
 if(!events?.length)return 0;
 try{
  const {LocalNotifications}=await import('@capacitor/local-notifications');
  const permission=await LocalNotifications.checkPermissions();
  if(permission.display!=='granted')return 0;
  const notifications=events.slice(0,8).map((x,i)=>({id:Math.floor(Date.now()%2000000000)+i,title:`BOŞLUK RADARI · ${x.symbol}`,body:`Kapanış onaylı Spot kırılımı · Kalite ${x.score}/100 · İlk direnç mesafesi ${x.gap==null?'hesaplanamadı':`%${Number(x.gap).toFixed(1)}`}`,schedule:{at:new Date(Date.now()+1200+i*250)}}));
  await LocalNotifications.schedule({notifications});return notifications.length;
 }catch{return 0;}
}
export {loadAlertSettings,saveAlertSettings,loadAlertEvents,saveAlertEvents};
