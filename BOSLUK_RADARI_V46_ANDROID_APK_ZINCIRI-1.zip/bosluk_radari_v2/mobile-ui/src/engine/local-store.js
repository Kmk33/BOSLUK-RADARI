const KEY='bosluk-radari:v2',HISTORY='bosluk-radari:history:v1';
function storage(){try{return typeof localStorage!=='undefined'?localStorage:null;}catch{return null;}}
export function saveScan(payload){
 const s=storage();if(!s)return false;
 try{
  const previous=loadScanHistory()[0]?.saved_at;let stamp=Date.now();if(previous){const prior=Date.parse(previous);if(Number.isFinite(prior)&&stamp<=prior)stamp=prior+1;}const compact={...payload,candidates:(payload.candidates||[]).slice(0,100),saved_at:new Date(stamp).toISOString()};
  s.setItem(KEY,JSON.stringify(compact));
  const old=loadScanHistory(),entry={saved_at:compact.saved_at,universe_count:compact.universe_count,candidate_count:compact.candidates.filter(x=>x.combined?.signal_state!=='RİSK / ELENDİ').length,breakout_count:compact.candidates.filter(x=>x.combined?.signal_state==='TEYİTLİ KIRILIM').length,top_symbols:compact.candidates.filter(x=>x.combined?.signal_state!=='RİSK / ELENDİ').slice(0,8).map(x=>x.symbol),scan_meta:compact.scan_meta};
  const history=[entry,...old.filter(x=>x.saved_at!==entry.saved_at)].slice(0,30);s.setItem(HISTORY,JSON.stringify(history));return true;
 }catch{return false;}
}
export function loadLastScan(){const s=storage();if(!s)return null;try{const raw=s.getItem(KEY);if(!raw)return null;const data=JSON.parse(raw);return data&&Array.isArray(data.candidates)?data:null;}catch{return null;}}
export function loadScanHistory(){const s=storage();if(!s)return [];try{const x=JSON.parse(s.getItem(HISTORY)||'[]');return Array.isArray(x)?x:[];}catch{return [];}}
export function clearLastScan(){const s=storage();try{s?.removeItem(KEY);s?.removeItem(HISTORY);return true;}catch{return false;}}

const ALERT_SETTINGS='bosluk-radari:alerts:v1',ALERT_EVENTS='bosluk-radari:alert-events:v1';
export function loadAlertSettings(){const s=storage();try{return JSON.parse(s?.getItem(ALERT_SETTINGS)||'null')||{enabled:false};}catch{return {enabled:false};}}
export function saveAlertSettings(value){const s=storage();try{s?.setItem(ALERT_SETTINGS,JSON.stringify(value));return !!s;}catch{return false;}}
export function loadAlertEvents(){const s=storage();try{const x=JSON.parse(s?.getItem(ALERT_EVENTS)||'[]');return Array.isArray(x)?x:[];}catch{return [];}}
export function saveAlertEvents(events){const s=storage();try{const merged=[...events,...loadAlertEvents()].slice(0,50);s?.setItem(ALERT_EVENTS,JSON.stringify(merged));return !!s;}catch{return false;}}
