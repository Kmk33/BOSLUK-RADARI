# BOŞLUK RADARI — Mobil UI V0.11

Mobil öncelikli, siyah/turuncu radar arayüzü. Bu aşamada yalnızca ön yüzdür; canlı veri uydurmaz.

## Çalıştırma
- Node.js 20+ gerekir.
- `npm install`
- `npm run dev`

## API sözleşmesi
Arayüz `GET /api/radar?timeframe=all` çağrısı bekler. Zaman dilimi seçildiğinde `timeframe` parametresi `1_saat`, `4_saat`, `1_gun`, `1_hafta` veya `1_ay` olur.

Yanıt JSON biçimi:
```json
{
  "universe_count": 120,
  "candidates": [
    {
      "symbol": "EXAMPLEUSDT",
      "rank": 1,
      "rank_score": 74.5,
      "timeframes": {"1_saat": {}, "4_saat": {}},
      "combined": {
        "reference_price": 1.25,
        "target_gap_pct": 52.0,
        "confluence": 2,
        "bias": "HAZIRLIK / İZLEME",
        "signal_state": "FORMASYON / HAZIRLIK",
        "timeframes": ["1_saat", "4_saat"]
      }
    }
  ]
}
```
`timeframes` değerleri backend'in seri hale getirilmiş analiz kayıtlarıdır. UI bunların içini doğrudan hesaplamaz; sıralama ve risk elemesi backend sorumluluğundadır.

## Güvenlik / doğruluk
- Spot-only; emir gönderme fonksiyonu yoktur.
- Servis erişilemiyorsa ekran bağlantı hatasını gösterir, sahte coin/fiyat üretmez.
- Direnç boşluğu teorik mesafedir, getiri garantisi değildir.
- Bu klasör tek başına APK değildir. Android/Capacitor kabuğu ve gerçek API bağlantısı sonraki entegrasyon aşamasıdır.
\nBackend servisinin başlatılması için proje kökündeki `API_README.md` dosyasına bak. UI ve API aynı origin üzerinde sunulacaksa `API_BASE` boş bırakılabilir; ayrı origin/port için `mobile-ui/src/main.js` içindeki `API_BASE` yapılandırılmalıdır.\n
## Tarama akışı
UI `POST /api/scan/start` çağrısıyla taramayı başlatır; dönen `job_id` için `GET /api/scan/status/{job_id}` sorgular ve ilerleme çubuğunu günceller. İş `completed` olunca sonuç JSON'u gösterilir.


## Android / Capacitor hazırlığı (V14)
Gereksinimler: Node.js 20+, Android Studio ve Android SDK.

```bash
npm install
npm run build
npm run android:add
npm run android:sync
npm run android:open
```

Android Studio içinden APK oluşturulabilir. Bu kaynak paketi Android SDK olmadan tek başına APK üretmez.

API adresi için `.env.example` dosyasını `.env` olarak kopyala ve `VITE_RADAR_API_BASE` değerini telefonun erişebildiği HTTPS API adresine ayarla. Uygulamayı genel internete açık, kimlik doğrulamasız API'ye bağlama.
\n## Otomatik Android APK derlemesi\nAyrıntılı Türkçe yönerge: proje kökündeki `ANDROID_BUILD_GUIDE_TR.md`. GitHub Actions iş akışı `.github/workflows/android-debug-apk.yml` dosyasındadır. Derleme için `RADAR_API_BASE` adlı HTTPS repository variable gereklidir.\n