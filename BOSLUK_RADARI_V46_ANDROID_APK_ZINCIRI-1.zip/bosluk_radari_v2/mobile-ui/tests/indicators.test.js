import test from 'node:test';
import assert from 'node:assert/strict';
import {ema,rsi,analyzeCandles,sma,stochasticRsi,macd,atr,vwap,keltnerChannel,volumePressure,classifyBreakoutProximity} from '../src/engine/indicators.js';
test('EMA returns null when history is shorter than period',()=>assert.equal(ema([1,2,3],4),null));
test('EMA seeds with first-period simple average',()=>assert.equal(ema([1,2,3,4],3),3));
test('RSI returns 100 for uninterrupted gains',()=>assert.equal(rsi(Array.from({length:20},(_,i)=>i+1)),100));
test('SMA and stochastic RSI have bounded outputs',()=>{const x=Array.from({length:80},(_,i)=>100+Math.sin(i/3)*4+i*.1);assert.ok(sma(x,20)>0);assert.ok(stochasticRsi(x)>=0&&stochasticRsi(x)<=100);});
test('MACD returns numeric histogram with sufficient history',()=>{const x=Array.from({length:100},(_,i)=>100+i*.2+Math.sin(i));assert.equal(typeof macd(x).histogram,'number');});
test('ATR is positive for valid candle history',()=>{const x=Array.from({length:40},(_,i)=>({high:102+i,low:99+i,close:101+i}));assert.ok(atr(x)>0);});
test('analysis ignores unclosed last candle and requires 220 closed candles',()=>{const c=Array.from({length:220},(_,i)=>({openTime:i,open:100+i,high:102+i,low:99+i,close:101+i,volume:100,takerBuyBase:60,closed:true}));assert.ok(analyzeCandles('TESTUSDT','1_saat',c));c.at(-1).closed=false;assert.equal(analyzeCandles('TESTUSDT','1_saat',c),null);});
test('downside-risk condition blocks bullish score',()=>{const c=Array.from({length:230},(_,i)=>{const x=i<210?200-i*.2:158-i*.7;return {openTime:i,open:x,high:x+1,low:x-1,close:x,volume:100,takerBuyBase:40,closed:true};});const x=analyzeCandles('RISKUSDT','1_gun',c);assert.ok(x);if(x.downside_risk)assert.equal(x.score,0);});

test('VWAP is volume weighted and finite',()=>{const x=vwap([{high:11,low:9,close:10,volume:2},{high:22,low:18,close:20,volume:1}]);assert.ok(x>10&&x<20);});
test('Keltner channel encloses its EMA center',()=>{const c=Array.from({length:40},(_,i)=>({open:10+i*.1,high:11+i*.1,low:9+i*.1,close:10+i*.1,volume:100,closed:true}));const k=keltnerChannel(c);assert.ok(k.upper>k.middle&&k.lower<k.middle);});
test('volume pressure uses taker-buy volume and bounded ratios',()=>{const c=Array.from({length:20},()=>({open:1,high:2,low:1,close:2,volume:10,takerBuyBase:7}));const x=volumePressure(c);assert.equal(x.buy_ratio,.7);assert.ok(Math.abs(x.sell_ratio-.3)<1e-12);assert.ok(x.delta_ratio>=-1&&x.delta_ratio<=1);});

test('breakout proximity requires overhead resistance and reports distance',()=>{assert.equal(classifyBreakoutProximity(100,100.5,1,1.2).state,'KIRILIMA ÇOK YAKIN');assert.equal(classifyBreakoutProximity(100,110,1,1).state,'DİRENÇTEN UZAK');assert.equal(classifyBreakoutProximity(100,99,1,1).distance_pct,null);});
