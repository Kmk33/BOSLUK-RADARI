import test from 'node:test';
import assert from 'node:assert/strict';
import {validateKlineRows} from '../src/engine/binance.js';

const row=(t,overrides={})=>({openTime:t,closeTime:t+59999,open:10,high:12,low:9,close:11,volume:100,...overrides});

test('kline validator sorts valid candles and reports clean response',()=>{
 const r=validateKlineRows([row(2),row(1)]);
 assert.equal(r.valid,true);assert.equal(r.rows[0].openTime,1);assert.equal(r.reason,null);
});

test('kline validator removes malformed and duplicate candles',()=>{
 const r=validateKlineRows([row(1),row(1),row(2,{high:8})]);
 assert.equal(r.valid,false);assert.equal(r.accepted,1);assert.ok(r.reason.includes('Bozuk/tekrarlı'));
});

test('kline validator rejects non-array response',()=>{
 const r=validateKlineRows({error:'bad'});
 assert.equal(r.valid,false);assert.equal(r.reason,'Mum yanıtı dizi değil');
});
