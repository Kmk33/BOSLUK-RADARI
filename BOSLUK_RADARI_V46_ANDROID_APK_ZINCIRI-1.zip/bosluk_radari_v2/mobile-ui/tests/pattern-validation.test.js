import test from 'node:test';
import assert from 'node:assert/strict';
import {evaluatePatternHistory, classifyHistoricalMarketRegime} from '../src/engine/pattern-validation.js';

function makeCandles(n=230){
  return Array.from({length:n},(_,i)=>{
    const base=100+Math.sin(i/7)*2+Math.sin(i/19)*1.5;
    return {open:base-.2,high:base+1,low:base-1,close:base,volume:100+(i%9)*5,closed:true};
  });
}

test('pattern history returns explicit no-lookahead methodology',()=>{
  const r=evaluatePatternHistory(makeCandles(80),{minHistory:100,horizon:20});
  assert.equal(r.signals,0);
  assert.equal(r.method.lookahead,false);
});

test('pattern history summary contains net return and excursion fields when patterns occur',()=>{
  // Create a strong impulse and a narrow pullback to seed a bull-flag-like structure.
  const c=makeCandles();
  for(let i=170;i<185;i++){const b=100+(i-170)*1.3;c[i]={open:b,high:b+1,low:b-.5,close:b+.8,volume:220,closed:true};}
  for(let i=185;i<230;i++){const b=119-(i-185)*.08;c[i]={open:b+.2,high:b+.45,low:b-.5,close:b-.1,volume:90,closed:true};}
  const r=evaluatePatternHistory(c,{minHistory:100,horizon:20,targetPct:.05,stopPct:.03,maxEvents:250});
  assert.equal(r.method.lookahead,false);
  assert.equal(r.method.outcomes_start_next_candle,true);
  for(const row of Object.values(r.summary)){
    assert.ok(Number.isFinite(row.avg_net_return_pct));
    assert.ok(Number.isFinite(row.avg_mfe_pct));
    assert.ok(Number.isFinite(row.avg_mae_pct));
  }
});

test('pattern evaluation counts overlapping signals but caps total events',()=>{
  const c=makeCandles();
  const r=evaluatePatternHistory(c,{minHistory:100,horizon:20,maxEvents:3});
  assert.ok(r.events.length<=3);
});

test('BTC regime classifier needs 200 closed candles and separates bull/bear/sideways',()=>{
  const make=(fn)=>Array.from({length:230},(_,i)=>{const close=fn(i);return {openTime:i,open:close,high:close+1,low:close-1,close,volume:100,closed:true};});
  assert.equal(classifyHistoricalMarketRegime(make(i=>100+i*.5)),'BULL');
  assert.equal(classifyHistoricalMarketRegime(make(i=>300-i*.5)),'BEAR');
  assert.equal(classifyHistoricalMarketRegime(make(i=>100+Math.sin(i/3)*.1)),'SIDEWAYS');
  assert.equal(classifyHistoricalMarketRegime(make(i=>100+i*.5).slice(0,199)),'UNKNOWN');
});

test('pattern events are bucketed by BTC regime using same-time prefix only',()=>{
  const asset=makeCandles();
  for(let i=0;i<asset.length;i++) asset[i].openTime=i;
  const btc=Array.from({length:asset.length},(_,i)=>{const close=100+i*.3;return {openTime:i,open:close,high:close+1,low:close-1,close,volume:100,closed:true};});
  const r=evaluatePatternHistory(asset,{minHistory:100,horizon:20,marketCandles:btc});
  assert.equal(r.method.btc_regime_uses_same_timestamp_prefix,true);
  for(const e of r.events) assert.ok(['BULL','BEAR','SIDEWAYS','UNKNOWN'].includes(e.market_regime));
  for(const regime of Object.keys(r.by_regime)) assert.ok(['BULL','BEAR','SIDEWAYS','UNKNOWN'].includes(regime));
});
