import test from 'node:test';
import assert from 'node:assert/strict';
import {evaluateBreakoutFollowThrough} from '../src/engine/breakout-validation.js';

function candlesWithBreakout({future = [], breakoutIndex = 65} = {}) {
  const rows = [];
  for (let i=0;i<breakoutIndex;i++) {
    const close = 100 + (i % 4) * 0.05;
    rows.push({open:close-0.1,high:101,low:99,close,volume:100,closed:true});
  }
  rows.push({open:100.8,high:102.5,low:100.5,close:102,volume:250,closed:true});
  for (const c of future) rows.push({open:c.open??102,high:c.high,low:c.low,close:c.close,volume:150,closed:true});
  while(rows.length < breakoutIndex + 14) rows.push({open:102,high:102.5,low:101.5,close:102,volume:100,closed:true});
  return rows;
}

test('confirmed breakout follow-through measures only later candles', () => {
  const data = candlesWithBreakout({future:[
    {high:104,low:101.8,close:103.5},
    {high:106,low:103,close:105},
    {high:105,low:102,close:103}
  ]});
  const r = evaluateBreakoutFollowThrough(data,{minHistory:60,resistanceLookback:30,horizon:12});
  assert.equal(r.method.lookahead,false);
  assert.ok(r.events.length >= 1);
  assert.ok(r.events[0].mfe_pct > 0);
  assert.ok(r.events[0].observed_bars <= 12);
});

test('same-candle stop and target is treated conservatively', () => {
  const data = candlesWithBreakout({future:[{high:106,low:99,close:104}]});
  const r = evaluateBreakoutFollowThrough(data,{minHistory:60,resistanceLookback:30,horizon:12});
  assert.ok(r.events.length >= 1);
  assert.equal(r.events[0].outcome,'STOP_FIRST / AYNI MUM BELİRSİZ');
});

test('insufficient history returns empty diagnostic', () => {
  const r = evaluateBreakoutFollowThrough(candlesWithBreakout().slice(0,70),{minHistory:60,horizon:12});
  assert.equal(r.events.length,0);
  assert.equal(r.method.lookahead,false);
});

test('historical report records costs and target hit rates', () => {
  const data = candlesWithBreakout({future:[{high:108,low:101,close:107}]});
  const r = evaluateBreakoutFollowThrough(data,{minHistory:60,resistanceLookback:30,horizon:12,feePct:.1,slippagePct:.05});
  assert.ok(r.events.length >= 1);
  assert.ok(Math.abs(r.events[0].cost_pct-.3)<1e-9);
  assert.ok('5' in r.summary.target_hit_rate_pct);
});
