import {evaluateSupportResistanceHistory} from '../src/engine/structure-validation.js';
import {evaluatePatternHistory} from '../src/engine/pattern-validation.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import {buildResistanceMap,detectBreakoutRetest,approximateVolumeProfile,classifyBreakoutAttempt} from '../src/engine/structure.js';
import {detectPatterns} from '../src/engine/patterns.js';
const candles=Array.from({length:100},(_,i)=>({open:i<95?100:101,high:i%10===0?110:102,low:98,close:100,volume:100,closed:true}));
test('resistance map reports nearest overhead pivot and theoretical levels',()=>{const x=buildResistanceMap(candles,100);assert.ok(Array.isArray(x.levels));assert.equal(x.theoretical_gaps.length,3);});
test('volume profile conserves approximate total candle volume',()=>{const x=approximateVolumeProfile(candles,20);assert.ok(x.poc>0);assert.ok(Math.abs(x.bins.reduce((a,b)=>a+b.volume,0)-10000)<1e-6);});
test('pattern detector safely returns an array for sufficient candles',()=>assert.ok(Array.isArray(detectPatterns(candles))));
test('retest does not fabricate a breakout when price stays below level',()=>{const x=detectBreakoutRetest(candles,120);assert.equal(x.breakout,false);});
test('confirmed breakout level can be retested after breakout candle',()=>{const xs=Array.from({length:30},(_,i)=>({open:99,high:100,low:98,close:99,volume:100,closed:true}));xs[27]={open:100,high:104,low:100,close:103,volume:250,closed:true};xs[28]={open:102,high:103,low:100.5,close:102.5,volume:120,closed:true};const x=detectBreakoutRetest(xs,100);assert.equal(x.breakout,true);assert.equal(x.retest,true);});

test('pattern detector returns named candidate objects with confidence and reason',()=>{const result=detectPatterns(candles);for(const x of result){assert.equal(typeof x.name,'string');assert.ok(['DÜŞÜK','ORTA','YÜKSEK'].includes(x.confidence));assert.equal(typeof x.reason,'string');}});

test('pattern history validator refuses insufficient history',()=>{const x=evaluatePatternHistory(candles,{minHistory:100,horizon:30});assert.equal(x.signals,0);});
test('pattern history validator reports chronological methodology',()=>{const xs=Array.from({length:180},(_,i)=>({open:100+i*.1,high:101+i*.1,low:99+i*.1,close:100+i*.1,volume:100,closed:true}));const x=evaluatePatternHistory(xs,{minHistory:100,horizon:20});assert.equal(x.method.lookahead,false);assert.equal(x.method.stop_first_same_bar,true);});

test('support and resistance maps include nearest support and strength metadata',()=>{const xs=Array.from({length:70},(_,i)=>{const wave=[0,2,4,2,0,-2,-4,-2][i%8];const mid=100+wave;return {open:mid,high:mid+1,low:mid-1,close:mid,volume:100,closed:true};});const x=buildResistanceMap(xs,100);assert.ok(Array.isArray(x.support_levels));assert.ok(x.first_support);assert.ok(['ZAYIF','ORTA','GÜÇLÜ'].includes(x.first_support.strength));assert.ok(x.first_obstacle);});

test('support/resistance history validator is prefix-only and waits for future candles',()=>{const xs=Array.from({length:100},(_,i)=>({open:100,high:102+(i%7===0?2:0),low:98-(i%9===0?2:0),close:100,volume:100,closed:true}));const x=evaluateSupportResistanceHistory(xs,{minHistory:40,horizon:10});assert.equal(x.method.lookahead,false);assert.equal(x.method.outcomes_start_next_candle,true);assert.ok(x.events.every(e=>e.index+10<xs.length));});
test('support/resistance history validator rejects insufficient candle history',()=>{const x=evaluateSupportResistanceHistory(candles,{minHistory:90,horizon:20});assert.equal(x.events.length,0);assert.equal(x.method.lookahead,false);});
test('support/resistance history summary keeps support and resistance outcomes separate',()=>{const xs=Array.from({length:120},(_,i)=>{const base=100+Math.sin(i/3)*3;return {open:base,high:base+1,low:base-1,close:base,volume:100,closed:true};});const x=evaluateSupportResistanceHistory(xs,{minHistory:40,horizon:8,nearPct:8});for(const key of Object.keys(x.summary)){assert.ok(['SUPPORT','RESISTANCE'].includes(key));assert.ok(x.summary[key].events>0);}});

test('wick-only move above resistance is classified as a false breakout',()=>{const xs=Array.from({length:30},()=>({open:99,high:100,low:98,close:99,volume:100,closed:true}));xs[29]={open:99.5,high:103,low:99,close:99.8,volume:220,closed:true};const x=classifyBreakoutAttempt(xs,100);assert.equal(x.false_breakout,true);assert.equal(x.confirmed,false);assert.match(x.state,/FITIL TUZAĞI/);});
test('strong close above resistance with volume confirms breakout',()=>{const xs=Array.from({length:30},()=>({open:99,high:100,low:98,close:99,volume:100,closed:true}));xs[29]={open:100,high:104,low:99,close:103.5,volume:220,closed:true};const x=classifyBreakoutAttempt(xs,100);assert.equal(x.confirmed,true);assert.equal(x.false_breakout,false);});
test('confirmed breakout is invalidated by a later close back below level',()=>{const xs=Array.from({length:30},()=>({open:99,high:100,low:98,close:99,volume:100,closed:true}));xs[27]={open:100,high:104,low:99.5,close:103.5,volume:220,closed:true};xs[28]={open:100,high:101,low:98,close:99.5,volume:120,closed:true};xs[29]={open:99.5,high:100,low:98,close:99,volume:100,closed:true};const x=classifyBreakoutAttempt(xs,100);assert.equal(x.invalidated,true);assert.equal(x.confirmed,false);});
