import test from 'node:test';
import assert from 'node:assert/strict';
import {scanIncludesTimeframe,classifyBtcMarket,combineFrameAnalyses,classifyScanError,summarizeScanResults} from '../src/engine/scanner.js';
test('cached scan is reused only when requested timeframe was included',()=>{const p={scan_meta:{timeframes:['1_saat','4_saat','1_gun']}};assert.equal(scanIncludesTimeframe(p,'4_saat'),true);assert.equal(scanIncludesTimeframe(p,'1_ay'),false);assert.equal(scanIncludesTimeframe({},'1_saat'),false);});

test('BTC market filter requires two confirming timeframes',()=>{const bearish={price:80,ema50:90,ema200:100,rsi:40};assert.equal(classifyBtcMarket({a:bearish,b:bearish,c:{price:110,ema50:105,ema200:100,rsi:60}}).bearish,true);assert.equal(classifyBtcMarket({a:bearish}).bearish,false);});

test('rising-wedge risk warning alone does not create bullish preparation',()=>{const x=combineFrameAnalyses('TESTUSDT',{'1_saat':{score:50,downside_risk:false,breakout:false,squeeze:false,patterns:[{name:'YÜKSELEN KAMA / ZAYIFLAMA',risk:true}],timeframe:'1_saat',price:10}});assert.equal(x.combined.signal_state,'İZLEME');assert.equal(x.combined.pattern_risk,true);});

test('combined radar exposes nearest support and applies BTC caution',()=>{const frame={score:70,downside_risk:false,breakout:false,squeeze:true,patterns:[],timeframe:'1_saat',price:100,market_filter:{bearish:true},resistance_map:{first_obstacle:{price:110,distance_pct:10},first_support:{price:95,distance_pct:-5}}};const x=combineFrameAnalyses('TESTUSDT',{'1_saat':frame});assert.equal(x.combined.first_support,95);assert.equal(x.combined.support_gap_pct,-5);assert.equal(x.combined.market_caution,true);assert.equal(x.combined.signal_state,'İZLEME');});

test('false breakout is not promoted as a bullish signal in combined radar',()=>{const f={score:75,downside_risk:false,breakout:false,breakout_quality:{false_breakout:true,invalidated:false},squeeze:true,patterns:[],timeframe:'1_saat',price:10};const x=combineFrameAnalyses('TESTUSDT',{'1_saat':f});assert.equal(x.combined.signal_state,'SAHTE KIRILIM / RED');assert.equal(x.combined.false_breakout,true);});

test('scan errors are classified for actionable diagnostics',()=>{
 assert.equal(classifyScanError('Binance hız sınırı (429)'),'RATE_LIMIT');
 assert.equal(classifyScanError('Failed to fetch'),'NETWORK');
 assert.equal(classifyScanError('HTTP 503'),'HTTP');
 assert.equal(classifyScanError('TESTUSDT: geçerli mum verisi yok'),'DATA_QUALITY');
});

test('scan summary separates failed jobs from insufficient history',()=>{
 const jobs=[{coin:{symbol:'AAAUSDT'},tf:{key:'1_saat'}},{coin:{symbol:'BBBUSDT'},tf:{key:'4_saat'}},{coin:{symbol:'CCCUSDT'},tf:{key:'1_gun'}}];
 const r=summarizeScanResults([{error:'Failed to fetch'},null,{price:10}],jobs);
 assert.equal(r.completed,1);assert.equal(r.failed,1);assert.equal(r.insufficient,1);
 assert.equal(r.failure_counts.NETWORK,1);assert.equal(r.failure_counts.INSUFFICIENT_DATA,1);
});
