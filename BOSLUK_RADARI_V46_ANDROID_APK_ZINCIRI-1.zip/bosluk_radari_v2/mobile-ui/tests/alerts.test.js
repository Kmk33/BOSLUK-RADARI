import test from 'node:test';
import assert from 'node:assert/strict';
import {selectNewBreakoutAlerts} from '../src/engine/alerts.js';
test('only newly confirmed breakout candidates are selected',()=>{const payload={candidates:[{symbol:'AAAUSDT',combined:{signal_state:'TEYİTLİ KIRILIM',quality_score:80}},{symbol:'BBBUSDT',combined:{signal_state:'FORMASYON / HAZIRLIK'}},{symbol:'CCCUSDT',combined:{signal_state:'TEYİTLİ KIRILIM'},diagnostics:{risk_timeframes:['1_gun']}}]};const x=selectNewBreakoutAlerts(payload,['OLDUSDT']);assert.deepEqual(x.map(v=>v.symbol),['AAAUSDT']);});
test('previously alerted confirmed breakout is not repeated',()=>{const x=selectNewBreakoutAlerts({candidates:[{symbol:'AAAUSDT',combined:{signal_state:'TEYİTLİ KIRILIM'}}]},['AAAUSDT']);assert.equal(x.length,0);});
