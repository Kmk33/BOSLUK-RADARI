
## 0.20.0 — Android build pipeline hardening
- GitHub Actions now builds automatically on pushes to `main`/`master`, in addition to manual dispatch and version tags.
- Added npm/Gradle caching, Android project checks, executable Gradle wrapper handling, and explicit APK output verification.
- Added a phone-first Turkish guide for obtaining the debug APK from GitHub Actions artifacts.
- No runtime scanner logic or signal thresholds changed in this release.
