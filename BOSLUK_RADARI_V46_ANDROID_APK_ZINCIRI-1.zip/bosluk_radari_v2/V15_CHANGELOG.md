# V15 changelog

- Added Dockerfile for the read-only Python API.
- Added Docker Compose service with restart policy, init process, localhost-only default host binding, and health check.
- Added `.dockerignore` to avoid copying tests, local environments, mobile assets, secrets, and bytecode into the image.
- Added `.env.production.example` with safe localhost binding and token placeholder.
- Added deployment instructions, mobile API URL guidance, and explicit warning that an APK-embedded shared token is extractable.
- No trading/order endpoints added; scope remains Binance Spot USDT market analysis only.
- Docker image build, real Binance scan, and Android APK build are not claimed as tested in this environment.
