# V27 changelog

- Added fail-closed production configuration validation for API startup.
- Production mode requires a 32+ character API token and explicit HTTPS CORS origins; wildcard and HTTP origins are rejected.
- Added deployment configuration regression tests and `.env.example`.
- Added Turkish VPS/Docker/HTTPS/mobile release checklist.
- 83/83 deterministic tests pass. No VPS deployment, live Binance scan or APK is claimed.
