# V5 — Gerçek veri test çalıştırıcısı ve destek seviyesi düzeltmesi

- Binance Spot tarihsel veri indirme + walk-forward raporunu tek komutta çalıştıran `tools/spot_walkforward.py` eklendi.
- Rapor sembol bazında mum sayısını, fold sonuçlarını, toplam OOS sinyallerini ve hedef/stop sonuçlarını JSON olarak saklar.
- Destek seviyesi filtresindeki mantık düzeltildi: destek artık güncel fiyatın altında seçilir.
- Destek seviyesi için regresyon testi eklendi.
- Gerçek ağ testi bu geliştirme ortamında yapılmadı; script public Binance API üzerinden çalışacak şekilde hazırlandı.
