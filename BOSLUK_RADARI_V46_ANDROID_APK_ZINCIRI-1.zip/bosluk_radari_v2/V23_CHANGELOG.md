# V23 changelog

- Added out-of-sample setup-quality band reporting to walk-forward evaluation.
- `quality_score_fn` receives only the candle prefix available at each signal close; future candles are never passed to the scoring callback.
- Bands: 80-100, 55-79, 30-54, 0-29; missing scores are grouped as UNSCORED.
- Per-fold band summaries use the same conservative target/stop and fee assumptions as the overall report.
- Added regression test for causal callback inputs and band-count reconciliation.
- 76/76 deterministic unit tests pass. No real Binance performance claim or APK build is made.
