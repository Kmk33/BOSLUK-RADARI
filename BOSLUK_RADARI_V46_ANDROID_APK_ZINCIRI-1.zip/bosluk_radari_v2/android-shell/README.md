# Android Shell

V14 itibarıyla Android kabuğu Capacitor 7 üzerinden `mobile-ui/` içinde yapılandırılmıştır.

Gereksinimler:
- Node.js 20+
- Android Studio
- Android SDK / Platform Tools
- Gradle (Android Studio tarafından yönetilebilir)

Komutlar `mobile-ui/README.md` içindedir. Bu geliştirme ortamında Android SDK/Gradle bulunmadığı için APK üretimi doğrulanmamıştır.
