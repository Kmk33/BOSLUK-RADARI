# V20 changelog

- Added supply-aware resistance map combining overhead pivot clusters and approximate OHLCV supply zones.
- Reports nearest known obstacle, distance to first obstacle, obstacle sources, and theoretical +50/+100/+200% milestones.
- A milestone is marked as having known obstacles when any mapped resistance/supply area lies before it.
- The map is informational only and does not change ranking, signal state, or risk gates.
- Added deterministic tests for first obstacle, merged supply zones, empty maps, below-price levels, and invalid price.
- OHLCV supply remains an approximation, not tick-level volume-at-price; theoretical gaps are not forecasts.
