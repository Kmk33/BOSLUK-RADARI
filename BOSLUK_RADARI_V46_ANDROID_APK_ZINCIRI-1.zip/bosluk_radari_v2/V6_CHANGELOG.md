# V6 — Çoklu zaman dilimi tarama ve rapor iyileştirmesi

- Tarama ekranı için anlaşılır zaman dilimi anahtarları eklendi: `1_saat`, `4_saat`, `1_gun`, `1_hafta`, `1_ay`.
- Önceki sürümlerde kullanılan Türkçe kısa adlar geriye dönük uyumluluk için korundu.
- `scan_symbol_timeframes()` ile tek sembolün tüm seçili periyotları taranıp çoklu zaman dilimi uyumu ve direnç merdiveni birleştiriliyor.
- Çoklu zaman dilimi birleştirme, yeni kanonik anahtarlarla çalışacak şekilde düzeltildi.
- Walk-forward raporuna sinyal sayısıyla ağırlıklandırılmış genel özet eklendi.
- 6 yeni test sınıfı/işleviyle birlikte toplam test sayısı 26'ya çıkarıldı.
