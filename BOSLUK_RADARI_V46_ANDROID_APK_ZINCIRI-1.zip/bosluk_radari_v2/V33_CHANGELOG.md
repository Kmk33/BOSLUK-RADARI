# V33 — Opt-in Android breakout notifications

- Added Capacitor Local Notifications dependency and native local-notification adapter.
- Added explicit ALARMLAR opt-in; permission requested only after user action.
- Notify only newly observed confirmed Spot breakouts after a successful foreground scan.
- First successful scan establishes baseline; historical candidates are not mass-notified.
- Deduplicate against previous confirmed candidates and local alert event history.
- Risk-vetoed entries are excluded; alert settings and last 50 events persist locally.
- 21 deterministic JavaScript tests pass.
- Notifications after foreground scans only; no always-on background scanning claim.
- APK and live-device notification testing not yet performed.
