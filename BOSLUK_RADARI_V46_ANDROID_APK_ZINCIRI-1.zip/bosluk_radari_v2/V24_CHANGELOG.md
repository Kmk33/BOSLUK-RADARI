# V24 changelog

- Added `historical_prefix_quality`: rebuilds setup-quality evidence from closed candles available at a specific signal close.
- Historical quality uses the existing analysis, pattern and close-confirmed retest modules; insufficient history is explicitly unscored.
- Added `--quality-bands` to `tools/spot_walkforward.py` to report out-of-sample results by causal historical quality band.
- The score is single-timeframe in this backtest path; it does not claim multi-timeframe confluence or probability calibration.
- 78/78 deterministic tests pass; Python compile checks and mobile JavaScript syntax check pass.
- No live Binance run and no APK build are claimed.
