# V14 — Android/Capacitor hazırlığı ve API güvenliği

- Vite mobil ön yüzüne Capacitor 7 bağımlılıkları, Android app id ve build/sync/open komutları eklendi.
- API adresi `VITE_RADAR_API_BASE` ile derleme zamanında yapılandırılabilir hale getirildi.
- İsteğe bağlı `VITE_RADAR_API_TOKEN` başlığı eklendi.
- API CORS wildcard yerine izinli origin listesi kullanıyor.
- `RADAR_API_TOKEN` ayarlandığında radar ve tarama uç noktaları token kontrolü yapıyor; `/health` açık kalıyor.
- HTTP entegrasyon testleri: yetkisiz isteğin reddi, sağlık kontrolünün açık kalması, CORS allowlist doğrulaması.
- Toplam deterministik test: 50.

Sınırlama: npm bağımlılıkları bu oturumda kurulamadı (kurulum zaman aşımına uğradı). Android SDK ve Gradle da mevcut değil. Dolayısıyla Vite production build, Capacitor sync ve APK bu aşamada üretilip doğrulanmadı.
