# V19 changelog

- Added conservative close-based breakout/retest detector.
- Requires a prior resistance pivot, a close above the level with RVOL threshold, then a later closed candle that retests the level and closes bullish above it.
- Wick-only breakouts and unclosed retest candles do not confirm.
- Added separate `breakout_retests` evidence per timeframe; does not change score/ranking or replace downside-risk gates.
- Added deterministic synthetic tests for confirmed retest, no retest, wick-only breakout, unclosed retest, and parameter validation.
- This is a heuristic confirmation feature, not a guarantee of continuation or trade advice.
