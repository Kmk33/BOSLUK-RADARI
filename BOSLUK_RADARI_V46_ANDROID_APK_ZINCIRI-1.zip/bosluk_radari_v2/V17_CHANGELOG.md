# V17 changelog

- Scanner now reports universe-fetch, scan, and total elapsed seconds.
- Reports average seconds per symbol, successful/failed counts, requested timeframes, and estimated Kline request count.
- Progress updates include per-symbol duration, elapsed time, average throughput, and estimated remaining time.
- Scan failures now include a bounded error message and exception type.
- Diagnostics do not alter ranking or signal scoring.
- Added deterministic tests for progress diagnostics, failed symbols, and empty universes.
- Live Binance connectivity and Android APK remain unverified/not built.
