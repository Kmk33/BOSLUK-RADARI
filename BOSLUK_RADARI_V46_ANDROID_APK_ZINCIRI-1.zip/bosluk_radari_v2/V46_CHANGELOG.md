# V46 — Android APK build pipeline hardening

- V45 scanner diagnostics and analysis logic preserved without changes.
- GitHub Actions now starts on pushes to `main`/`master`, manual dispatch, and `bosluk-radari-v*` tags.
- Added Node and Gradle dependency caching, Android project validation, Gradle wrapper permission setup, and APK artifact verification.
- Added a phone-first Turkish guide for uploading the source and retrieving the debug APK artifact.
- Mobile package version: 0.20.0.
- V45 baseline test suite: 51/51 passed before packaging.
- This environment still has no Android SDK/Gradle wrapper or usable Vite installation; no APK was built here.
- No live Binance/Android device validation was performed.
