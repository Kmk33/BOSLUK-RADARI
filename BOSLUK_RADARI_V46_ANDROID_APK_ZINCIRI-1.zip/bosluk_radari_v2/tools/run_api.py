"""Start the read-only BOŞLUK RADARI HTTP API."""
from engine.api import serve

if __name__ == "__main__":
    serve()
