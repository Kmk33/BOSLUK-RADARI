"""Download Binance Spot history and produce a walk-forward breakout report."""
import argparse, json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from engine.binance import BinanceSpot
from engine.analysis import Candle
from engine.walkforward import walk_forward_breakouts, aggregate_walk_forward
from engine.setup_quality import historical_prefix_quality

def main():
    ap=argparse.ArgumentParser(description="Binance Spot historical walk-forward test")
    ap.add_argument("--symbols",default="BTCUSDT,ETHUSDT,SOLUSDT")
    ap.add_argument("--interval",default="1h")
    ap.add_argument("--start-ms",type=int,required=True)
    ap.add_argument("--end-ms",type=int,required=True)
    ap.add_argument("--out",default="reports/spot_walkforward.json")
    ap.add_argument("--target",type=float,default=.50)
    ap.add_argument("--stop",type=float,default=.08)
    ap.add_argument("--fee",type=float,default=.001)
    ap.add_argument("--quality-bands",action="store_true",
                    help="Rebuild historical setup quality from each signal-time candle prefix")
    args=ap.parse_args()
    if args.end_ms<=args.start_ms: ap.error("--end-ms must be after --start-ms")
    client=BinanceSpot()
    report={"market":"BINANCE_SPOT","interval":args.interval,"start_ms":args.start_ms,
            "end_ms":args.end_ms,"target_fraction":args.target,"stop_fraction":args.stop,
            "fee_fraction":args.fee,"symbols":{}}
    for symbol in [x.strip().upper() for x in args.symbols.split(",") if x.strip()]:
        try:
            rows=client.historical_klines(symbol,args.interval,args.start_ms,args.end_ms)
            candles=[Candle(r["open_time"],r["open"],r["high"],r["low"],r["close"],
                r["volume"],r["quote_volume"],r["taker_buy_base"],r["closed"]) for r in rows]
            quality_fn=(lambda prefix: historical_prefix_quality(prefix,symbol=symbol,
                          timeframe=args.interval)["score"]) if args.quality_bands else None
            folds=walk_forward_breakouts(candles,target_pct=args.target,stop_pct=args.stop,
                fee_pct=args.fee,quality_score_fn=quality_fn)
            report["symbols"][symbol]={"bars":len(candles),"folds":folds,
                "total_signals":sum(x["signals"] for x in folds),
                "quality_bands_enabled":bool(args.quality_bands)}
            print(f"{symbol}: {len(candles)} mum | {report['symbols'][symbol]['total_signals']} OOS sinyal")
        except Exception as exc:
            report["symbols"][symbol]={"error":str(exc)}
            print(f"{symbol}: HATA - {exc}")
    out=Path(args.out); out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    print(f"Rapor: {out}")
if __name__=="__main__": main()
