"""Bounded, read-only Binance Spot connectivity and small-scan diagnostic."""
from __future__ import annotations
import argparse
import json
import time
from datetime import datetime, timezone

from engine.binance import BinanceSpot
from engine.scanner import liquid_spot_universe, scan_liquid_market


def run_check(client, scan_top_n=3, min_quote_volume=1_000_000, min_trades=500):
    report = {
        "service": "BOŞLUK RADARI",
        "scope": "BINANCE_SPOT_USDT",
        "read_only": True,
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "checks": {},
    }
    started = time.perf_counter()

    def check(name, fn):
        t0 = time.perf_counter()
        try:
            value = fn()
            report["checks"][name] = {
                "ok": True,
                "duration_seconds": round(time.perf_counter() - t0, 3),
                "details": value,
            }
            return value
        except Exception as exc:
            report["checks"][name] = {
                "ok": False,
                "duration_seconds": round(time.perf_counter() - t0, 3),
                "error_type": type(exc).__name__,
                "error": str(exc)[:240],
                "failure_class": (
                    "DNS_OR_NETWORK_BLOCK" if any(token in str(exc).lower()
                        for token in ("name resolution", "failed to resolve", "connectionerror", "timed out"))
                    else "API_OR_VALIDATION_ERROR"
                ),
                "note": "Bağlantı hatası Binance'in genel olarak kapalı olduğunu kanıtlamaz."
                        if any(token in str(exc).lower()
                            for token in ("name resolution", "failed to resolve", "connectionerror", "timed out"))
                        else None,
            }
            return None

    check("exchange_info", lambda: {
        "spot_symbols": len(client.exchange_info().get("symbols", []))
    })
    tickers = check("ticker_24h", lambda: {
        "ticker_rows": len(client.ticker_24h())
    })
    universe = check("liquid_universe", lambda: {
        "symbols": liquid_spot_universe(
            client, min_quote_volume=min_quote_volume,
            min_trades=min_trades, top_n=scan_top_n
        )
    })
    symbols = (universe or {}).get("symbols", [])
    if symbols:
        # Small 1h-only scan bounds request volume; this is a smoke test, not a full radar run.
        result = check("sample_1h_scan", lambda: scan_liquid_market(
            client, min_quote_volume=min_quote_volume,
            min_trades=min_trades, top_n=scan_top_n,
            timeframes=["1_saat"]
        ))
        if result is not None:
            report["sample_scan"] = {
                "universe_count": result.get("universe_count", 0),
                "scanned_count": result.get("scanned_count", 0),
                "error_count": len(result.get("errors", [])),
                "candidate_count": len(result.get("candidates", [])),
                "diagnostics": result.get("diagnostics", {}),
            }
    else:
        report["checks"]["sample_1h_scan"] = {
            "ok": False,
            "skipped": True,
            "reason": "No eligible Spot USDT symbols returned by the liquidity filter."
        }

    report["duration_seconds"] = round(time.perf_counter() - started, 3)
    report["ok"] = all(
        item.get("ok", False)
        for name, item in report["checks"].items()
        if name != "sample_1h_scan" or not item.get("skipped")
    ) and report["checks"].get("sample_1h_scan", {}).get("ok", False)
    failures=[item for item in report["checks"].values() if not item.get("ok")]
    report["environment_diagnosis"] = (
        "NETWORK_UNAVAILABLE_OR_DNS_BLOCKED" if any(
            item.get("failure_class")=="DNS_OR_NETWORK_BLOCK" for item in failures)
        else "API_CHECK_FAILED" if failures else "SPOT_PUBLIC_DATA_REACHABLE"
    )
    report["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--top-n", type=int, default=3,
                        help="Maximum symbols in the smoke test (1-10; default 3)")
    parser.add_argument("--min-quote-volume", type=float, default=1_000_000)
    parser.add_argument("--min-trades", type=int, default=500)
    args = parser.parse_args()
    if not 1 <= args.top_n <= 10:
        parser.error("--top-n must be between 1 and 10")
    if args.min_quote_volume < 0 or args.min_trades < 0:
        parser.error("Liquidity thresholds cannot be negative")
    # Keep a diagnostic run bounded; production scanning retains normal retries.
    report = run_check(BinanceSpot(timeout=6, retries=0), args.top_n,
                       args.min_quote_volume, args.min_trades)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(0 if report["ok"] else 2)


if __name__ == "__main__":
    main()
