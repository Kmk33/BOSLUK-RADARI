# V29 — On-device pattern and structure layer

- Added conservative pattern candidate detection.
- Added pivot-cluster resistance map and theoretical gap ladder.
- Added close-based breakout/retest helper.
- Added approximate OHLCV volume profile.
- Integrated these modules into the local Spot scanner and surfaced pattern/retest data in UI.
- Added 4 deterministic JS tests; full JS suite passes 9/9.
- No live exchange or Android device validation is claimed.
