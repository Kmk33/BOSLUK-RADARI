# BOŞLUK RADARI — Sunucuya dağıtım kontrol listesi

## 1. Sunucu
- Docker Engine ve Docker Compose kurulmuş bir Linux VPS kullan.
- Alan adı için DNS A kaydını sunucuya yönlendir.
- 80/443 dışında API'nin 8765 portunu internete açma.
- `.env.example` dosyasını `.env` olarak kopyala; rastgele, en az 32 karakterlik API token'ı gir.
- `RADAR_ALLOWED_ORIGINS` değerini uygulamanın gerçek HTTPS origin'i ile değiştir. Wildcard ve HTTP origin üretim modunda reddedilir.

Token üretme örneği:
```bash
python -c "import secrets; print(secrets.token_urlsafe(48))"
```

## 2. API'yi başlat
```bash
docker compose up -d --build
docker compose ps
docker compose logs -f radar-api
curl http://127.0.0.1:8765/health
```

## 3. HTTPS
Caddy/Nginx gibi bir reverse proxy ile HTTPS sertifikası kur; dışarıdan yalnızca 443 erişilebilir olsun. API portu host üzerinde 127.0.0.1'e bağlıdır. Reverse proxy aynı makineden `127.0.0.1:8765` hedefine yönlendirmelidir.

## 4. Mobil uygulama
GitHub Actions `RADAR_API_BASE` değişkenine gerçek HTTPS API origin'ini vererek Android debug APK derlemesini başlat. Uygulama token'ı APK içine gömülürse çıkarılabilir; ortak token'ı güvenli kimlik doğrulama yerine sayma. Kişi/cihaz bazlı kimlik doğrulama ve token yenileme olmadan geniş dağıtım yapma.

## 5. Kabul testleri
- `/health` 200 döndürmeli.
- Token olmadan `/api/scan/start` 401 dönmeli.
- Doğru token ile tarama kuyruğa alınmalı.
- Binance DNS/bağlantı hatasında iş `failed` olmalı; boş/sahte aday listesi dönmemeli.
- Tarama sonucu Spot USDT kapsamını ve `orders_enabled=false` bilgisini korumalı.

## Mevcut sınır
Bu dosya dağıtım adımlarını tarif eder; gerçek VPS, alan adı, HTTPS sertifikası veya Binance canlı bağlantısı oluşturmaz. Bunlar hesap/sunucu erişimi ve kullanıcıya ait yapılandırma gerektirir.
