# V30 — Multi-timeframe quality and local history

- Expanded the local analysis layer with SMA 20/50/100/200, Stoch RSI, MACD histogram and ATR.
- Reworked the quality score into independent evidence buckets: trend, momentum, volume, structure and confirmed breakout. Related moving averages are not counted as separate points.
- Downside-risk veto still forces the bullish score to zero.
- Added weighted multi-timeframe score aggregation using the strongest three frames plus a capped confluence bonus.
- Added localStorage persistence for the last scan; cached results display immediately while the app refreshes market data.
- Added 5 tests. Full JS test suite: 14/14 passed; engine syntax checks clean.
- No live Binance or Android device validation claimed.
