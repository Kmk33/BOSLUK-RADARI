# BOŞLUK RADARI — çalışma durumu

## Tamamlanan mühendislik parçaları
- Binance public Spot REST istemcisi: exchangeInfo, klines, depth, 24h ticker.
- Tarihsel mum indirme: start/end aralığı, sayfalama, tekrar kayıt temizliği, zaman damgası sıralaması ve interval doğrulaması.
- Kapalı mum verisi filtresi.
- EMA 20/50/90/200, RSI, Bollinger genişliği/sıkışma, RVOL, taker-buy baskısı.
- Pivot tabanlı destek/direnç ve hacim onaylı kırılım.
- Heuristik formasyon adayları: yükselen üçgen, düşen kama, boğa bayrağı, fincan-kulp; aşağı eğimli yapı uyarısı.
- Çoklu zaman dilimi confluence ve direnç hedef merdiveni.
- Leakage-aware breakout backtest: sinyal anından sonraki mumlar yalnızca sonuç ölçümünde kullanılır; aynı mumda hedef ve stop temasında stop önce sayılır.
- Walk-forward yardımcıları: kronolojik eğitim/test dilimleri ve test diliminde sinyal raporu.
- Binance Spot verisini indirip walk-forward raporu üreten CLI aracı (`tools/spot_walkforward.py`).
- Destek seviyesinin fiyatın altında seçilmesi için mantık düzeltmesi ve regresyon testi.
- Deterministik testler: V4'te 18 test; V5'te destek seviyesi regresyon testi eklendi.

## Henüz tamamlanmayanlar
- Canlı Binance bağlantısının bu çalışma oturumunda gerçek ağ üzerinden doğrulanması.
- Gerçek Binance Spot tarihsel verisiyle geniş evren backtesti ve sonuç raporu.
- Formasyonların istatistiksel kalibrasyonu; şu an heuristik aday seviyesinde.
- React/Capacitor Android UI, Android SDK ile APK derleme ve gerçek cihaz testi.
- Uzun süreli çalışma, bildirim ve pil tüketimi testi.

## Ölçüm disiplini
- Sinyal kapanmış mumda oluşur; sonraki mumlar yalnızca ileri sonuç ölçümünde kullanılır.
- Aynı mumda stop ve hedef birlikte görülürse stop önce kabul edilir (muhafazakâr varsayım).
- Walk-forward dilimleri kronolojik ayrılır; test dilimi sinyalleri raporlanır.
- Backtest sonuçları komisyon ve kayma varsayımlarına duyarlıdır.
- Formasyon isimleri tek başına al/sat önerisi değildir.

- Çoklu zaman dilimi taraması: 1 saat, 4 saat, 1 gün, 1 hafta, 1 ay için kanonik adlar ve tek sembolde birleştirilmiş analiz.
- Walk-forward raporunda fold sonuçlarının sinyal sayısına göre ağırlıklı özeti.
- V6 toplam deterministik test: 26/26.

- V7: 24 saatlik USDT kotasyon hacmi/işlem sayısı likidite ön elemesi ve risk öncelikli aday sıralaması.
- Tarama hataları raporda ayrı tutulur; hatalı semboller aday olarak gösterilmez.

- V8: Spot emir defteri spread/derinlik/imbalance ölçümü ve aggTrades taker akışı proxy'si.
- Mikro yapı verisi ayrı tutulur; tek başına sinyal üretmez ve tarihsel CVD diye sunulmaz.

- V9: OHLCV mumlarından yaklaşık hacim profili, POC, %70 değer alanı ve üst arz bölgeleri.
- Hacim profili yaklaşık dağıtım yöntemiyle hesaplanır; tick-level volume-at-price değildir.

- V10: çoklu zaman dilimi çıktısına hacim profili/üst arz detayları eklendi; referans fiyat önceliği düzeltildi; risk öncelikli açık sinyal durumları eklendi.
\n- V11 UI: mobil öncelikli siyah/turuncu radar arayüzü oluşturuldu; zaman dilimi ve sinyal filtreleri, bağlantı durumu, aday kartları ve boş/hata durumları eklendi. API henüz bağlanmadığından canlı veri göstermez.\n\n- V12 API: read-only HTTP servis eklendi (`/health`, `/api/radar`); zaman dilimi ve likidite parametreleri doğrulanır, JSON NaN/Infinity temizlenir, 30 sn önbellek ve hata durumunda 503 davranışı eklendi. API otomatik olarak canlı veri uydurmaz. Gerçek Binance bağlantısı ve mobil dağıtım henüz doğrulanmadı.\n\n- V13: uzun taramalar için arka plan iş kuyruğu, job_id/status polling, sembol bazlı ilerleme, iki aktif iş sınırı ve iş geçmişi TTL eklendi. Mobil UI senkron uzun istek yerine bu akışı kullanıyor. Binance canlı ağ testi hâlâ yapılmadı.\n\n- V14: Capacitor Android yapılandırması ve build/sync komutları eklendi; API adresi/token build env ile ayarlanabilir; CORS allowlist ve isteğe bağlı API token doğrulaması eklendi. 50/50 test geçti. npm install bu oturumda zaman aşımına uğradı; Android SDK/Gradle yok, APK üretilmedi.\n\n\n## V15 deployment layer\nDockerfile, Docker Compose, container healthcheck, production environment example, and deployment/security notes added. Docker image build and live Binance connectivity still require an environment with Docker/network access. No APK has been produced.\n\n## V16 market-data resilience\nPer-client exchangeInfo cache (1 hour), 24h ticker cache (15 seconds), bounded retries for transient transport/5xx errors, immediate surfacing of Binance 418/429 rate limits, and cache copy isolation. 54/54 unit tests pass; Python compile and mobile JavaScript syntax checks pass. Live Binance connectivity remains unverified.\n\n## V17 scan observability\nScanner returns universe/scan/total durations, throughput, requested timeframe set, estimated Kline request count, and successful/failed symbol counts. Progress callbacks expose elapsed time, average symbol duration, per-symbol duration, and estimated remaining time. 56/56 unit tests pass; Python compile and JS syntax checks pass. No live Binance scan or APK build has been performed.\n\n## V18 bounded live Spot diagnostic\nAdded `python -m tools.live_spot_check --top-n 3`: checks exchange metadata, 24h ticker, eligible liquid Spot USDT universe, and a bounded 1h sample scan (1–10 symbols). Emits JSON with per-check timings and explicit errors; no trading endpoints. Mocked tests pass. The command's help was tested, but the actual live Binance check was not run.\n\n## V19 breakout/retest evidence\nAdded conservative per-timeframe breakout-retest detection: prior pivot resistance, close above resistance with RVOL threshold, then a later bullish close after retesting the level. Wick-only breaks and unclosed candles do not qualify. Evidence is separate and does not alter ranking/score or override downside risk. 64/64 unit tests pass; live Binance and APK remain unverified.\n\n## V20 resistance map\nAdded overhead pivot-cluster and OHLCV supply-aware resistance map with nearest obstacle distance and theoretical +50/+100/+200% milestones. This is informational only and does not alter ranking or risk gates. 69/69 unit tests pass; Python compile and JS syntax checks pass. Live market and APK remain unverified.\n\n## V21 setup quality\nAdded `combined.setup_quality` with independent evidence buckets (trend, volume, breakout, bullish structure, retest). Correlated EMA signals and volume indicators are capped per bucket; any downside-risk timeframe vetoes bullish qualification. This does not alter the existing rank score. 74/74 unit tests pass; Python and JS checks pass. Live Binance and APK remain unverified.\n\n## V22 backtest integrity\nCorrected fold-boundary leakage: an OOS signal is retained only if its complete forward horizon ends within that same test fold. Reports expose evaluable and excluded boundary counts. 75/75 tests pass. Live data and APK are still not verified.\n\n## V23 quality-band evaluation\nWalk-forward reports can optionally break down OOS outcomes by caller-supplied causal quality scores (80-100, 55-79, 30-54, 0-29). Callback receives only data through the signal close. 76/76 tests pass. No live Binance validation/APK build yet.\n\n## V24 historical quality reconstruction\nAdded causal single-timeframe quality reconstruction and CLI `--quality-bands`; score is rebuilt from the signal-time prefix. Insufficient history is marked unscored. 78/78 deterministic tests pass. Live Binance and Android APK remain outstanding.\n\n## V25 connectivity diagnostic\nAdded DNS/network vs API failure classification and bounded diagnostic timeout. Current environment's live check failed at hostname resolution; live Binance scan remains unverified. Android SDK/Gradle unavailable here, so APK remains outstanding. 79/79 tests pass.\n\n## V26 Android build pipeline\nAdded GitHub Actions workflow to build and upload a debug APK using Node 20/JDK 21/Capacitor. Requires repository variable RADAR_API_BASE with a real HTTPS backend. Added Turkish build guide. APK still not generated in this environment because Android SDK/Gradle are absent.\n\n## V27 production deployment safety\nProduction API startup now requires a 32+ character token and explicit HTTPS CORS origins; wildcard/HTTP origins are rejected. Added env template and VPS deployment checklist. No VPS credentials/domain are available, so deployment and APK are still pending.\n