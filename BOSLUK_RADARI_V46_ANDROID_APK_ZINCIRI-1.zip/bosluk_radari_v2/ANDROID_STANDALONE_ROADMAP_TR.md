# BOŞLUK RADARI — Android tek APK geçişi (V38)

## V38: Formasyon geçmiş doğrulama altyapısı
- Yeni pattern-validation modülü, her mumda yalnızca o ana kadar kapanmış geçmişi kullanarak formasyon adaylarını tarar.
- Sinyalden sonraki mumlarda hedef/stop sonucu ölçülür; aynı mumda ikisi de görülürse muhafazakâr biçimde stop önce kabul edilir.
- Formasyon başına sinyal, hedef, stop ve sonuçsuz sayıları üretir.
- Risk etiketli formasyonlar boğa performans sayımına alınmaz.
- Bu sürümde gerçek piyasa verisiyle performans raporu üretilmedi; yalnızca değerlendirme altyapısı ve testleri eklendi.

## Android derleme zinciri
- GitHub Actions iş akışı test, Vite derlemesi, bağımsız bundle kontrolü, Capacitor Android ekleme/senkronizasyonu, debug APK derlemesi ve APK dosya doğrulamasını içerir.
- İş akışı henüz çalıştırılmadı. Bu çalışma ortamında Android SDK/Gradle yoktur; APK hazır değildir.
- GitHub Actions yalnızca derleme makinesi olarak kullanılabilir; uygulama çalışma sırasında VPS/API sunucusuna bağlı değildir.

## Test durumu
- Yerel JS testleri 28/28 başarılı.
- JavaScript sözdizimi kontrolleri temiz.
- Canlı Binance, tarihsel başarı oranı ve gerçek Android cihaz doğrulaması yapılmadı.

## Mimari
Tek APK; Binance Spot public data; analiz ve kayıtlar telefonda. Harici API/VPS, API anahtarı, emir gönderme ve vadeli işlem yok.

## V39 — Destek/direnç ve BTC filtresi
- Pivot tabanlı destek ve direnç kümeleri birlikte gösterilir; yakın seviye, temas sayısı ve temasın güncelliği raporlanır.
- BTC 1s/4s/1g filtresi tarama başlangıcında hesaplanır; BTC zayıfsa hazırlık sinyali izlemeye düşürülür.
- 30/30 yerel test geçti. Canlı Binance/cihaz doğrulaması ve APK derlemesi henüz yapılmadı.

## V40 — Destek/direnç tarihsel doğrulama
- Her mumda yalnızca o ana kadarki geçmişten destek/direnç hesaplanır; sonuçlar sonraki mumlarda ölçülür.
- Destek tepki/kırılma ve direnç ret/kırılma oranları ayrı gösterilir. Coin detay ekranında örneklem sayısı ve oranlar görünür.
- 33/33 yerel test geçti. Canlı veri/cihaz/production build ve APK doğrulaması henüz yapılmadı.

## V41 — Sahte kırılım filtresi
- Fitil ile direnç üstüne çıkıp altında kapanan mumlar sahte kırılım/direnç reddi olarak etiketlenir.
- Teyitli kırılım için kapanış, RVOL ve mum kapanış konumu birlikte aranır; sonraki kapanış direnç altına dönerse kırılım geçersizleşir.
- 37/37 yerel test geçti. Canlı veri/Android doğrulaması ve APK henüz yok.
