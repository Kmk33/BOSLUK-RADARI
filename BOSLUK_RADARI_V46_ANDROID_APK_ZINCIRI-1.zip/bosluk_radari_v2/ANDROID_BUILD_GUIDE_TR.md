# Android APK üretim rehberi

## Otomatik derleme (önerilen)
Depoyu GitHub'a gönder. GitHub deposunda **Settings → Secrets and variables → Actions → Variables** bölümünde `RADAR_API_BASE` adlı repository variable oluştur ve uygulamanın erişeceği HTTPS API adresini gir (ör. `https://radar-api.ornekalanadi.com`). Bu adres gerçek sunucu adresin olmalı; örnek adresi kullanma.

Ardından **Actions → Build BOŞLUK RADARI Android APK → Run workflow** seç. Başarılı derlemede `bosluk-radari-debug-apk` adlı artifact içinden `app-debug.apk` dosyasını indir.

## Yerel derleme
- Node.js 20+
- JDK 21
- Android Studio ve Android SDK (Android Studio'nun önerdiği SDK platform/build-tools)
- Telefonun erişebildiği HTTPS API adresi

```bash
cd mobile-ui
cp .env.example .env
# .env içindeki VITE_RADAR_API_BASE değerini gerçek HTTPS API adresiyle değiştir
npm install
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

APK yolu: `mobile-ui/android/app/build/outputs/apk/debug/app-debug.apk`

## Güvenlik
- APK içine gömülen herhangi bir ortak API token'ı gizli kabul edilemez.
- İnternete açık serviste HTTPS, erişim kontrolü, hız sınırı ve loglama kullan.
- Debug APK dağıtım içindir/test içindir; mağaza veya son kullanıcı dağıtımı için imzalı release süreci ayrıca yapılmalıdır.
- Bu proje otomatik emir göndermez; yalnızca Spot piyasa analizi yapar.

## Bu paketteki durum
Bu geliştirme ortamında JDK var; Android SDK ve Gradle yok. GitHub Actions iş akışı ve derleme rehberi eklendi, ancak APK'nın üretildiği anlamına gelmez. Gerçek HTTPS API adresi ve GitHub deposu yapılandırılmadan otomatik derleme tamamlanamaz.
