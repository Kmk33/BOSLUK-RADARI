# V4 — Tarihsel veri altyapısı ve walk-forward

- `historical_klines()` eklendi: Binance Spot tarihsel mumlarını start/end aralığında sayfalayarak indirir.
- Sayfalama ilerleme kontrolü, tekrar mumları tekilleştirme ve sıralı çıktı eklendi.
- Binance interval ve limit doğrulaması eklendi.
- `walkforward.py` eklendi: kronolojik eğitim/test dilimleri ve test döneminde oluşan sinyallerin raporlanması.
- Dört yeni test eklendi. Bu testler API yanıtını taklit eder; gerçek Binance ağına erişim testi değildir.
