# BOŞLUK RADARI V15 — Backend deployment

This package runs the read-only Binance Spot API in a Docker container.

## What this does / does not do
- Runs the Python API on port 8765 inside the container.
- Includes a container health check and restart policy.
- Keeps the host port bound to 127.0.0.1 by default.
- Does not include a reverse proxy, TLS certificate, user account system, or APK.
- `/health` is intentionally public; radar and scan endpoints require `RADAR_API_TOKEN` when configured.
- Do not expose the API directly to the public internet. Put it behind HTTPS and an authenticated reverse proxy/firewall.

## Start
1. Install Docker Engine and the Docker Compose plugin on a Linux server.
2. Copy `.env.production.example` to `.env`.
3. Replace `RADAR_API_TOKEN` with a long random secret. Never commit `.env`.
4. Run `docker compose up -d --build`.
5. Check `docker compose ps` and `docker compose logs -f radar-api`.
6. Check locally: `curl http://127.0.0.1:8765/health`.

## Mobile app connection
Build the mobile UI with `VITE_RADAR_API_BASE` set to the HTTPS URL of the deployed API. The mobile client can send `VITE_RADAR_API_TOKEN`, but a token embedded in an APK can be extracted; it is not a user authentication system. For a real public deployment, add per-user/device authentication at the reverse proxy or replace the shared token flow before distribution.

## Stop / update
- Stop: `docker compose down`
- Rebuild after code updates: `docker compose up -d --build`
- Logs: `docker compose logs --tail=200 radar-api`

## Operational limits
The scanner still makes public Binance Spot market-data requests. Binance availability, rate limits, network conditions, and the configured symbol/timeframe scope affect scan duration. A healthy `/health` endpoint only confirms that the API process is responding; it does not prove Binance market data is reachable. Run an actual scan and inspect its result before relying on it.
