# V36 — BTC regime filter, breakout proximity and order book snapshot

- Added BTCUSDT 1h/4h/1d market regime context; bearish/bullish state requires confirmation on at least two available timeframes.
- In bearish BTC regime, setup/formation candidates are downgraded to WATCH and quality score is reduced by 12; confirmed breakout state is retained but carries BTC caution.
- Added resistance-distance classification: very near (<=0.8% with RVOL>=1.1), approaching (<=2.5%), distant, or no overhead resistance.
- Added Binance Spot depth snapshot for up to 12 highest-ranked non-risk candidates (top 100 levels); exposes bid/ask notional imbalance and spread.
- Detail panel displays BTC filter and order-book snapshot. Explicitly warns this is not spoofing detection or proof of intent.
- 24 local tests pass; syntax checks clean. No live exchange/device validation claimed.
