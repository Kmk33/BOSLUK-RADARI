# V10 — Çoklu zaman dilimi radar çıktısı

- Tarama çıktısı artık her zaman diliminin yaklaşık hacim profilini ve üst arz bölgelerini kaybetmeden taşır.
- Referans fiyatı önceliği güncel saatlik, ardından 4 saatlik/günlük/haftalık/aylık kapanış şeklinde düzeltildi. Aylık kapanışın güncel fiyatmış gibi kullanılmasının önüne geçildi.
- Her sembol için açık durum etiketi eklendi: FORMASYON / HAZIRLIK, TEYİTLİ KIRILIM, RİSK / GEÇERSİZ veya İZLEME.
- Risk durumu, olumlu formasyon etiketinin önüne geçer.
- Yeni regresyon testleri: referans fiyat önceliği, profil verilerinin korunması ve risk önceliği.

Bu sürümde canlı Binance ağına erişim veya APK derlemesi doğrulanmış değildir.
