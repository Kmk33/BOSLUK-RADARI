# V35 — Indicator expansion

- Added EMA 7, 9, 21 and 100 while retaining existing EMA/SMA periods.
- Added volume-weighted typical-price VWAP over the analyzed closed-candle window.
- Added Keltner channel (EMA center ± 2 ATR).
- Added multi-candle taker-buy/sell volume pressure and normalized delta proxy.
- Expanded coin detail panel to show new EMA periods, VWAP, Keltner bands, taker pressure and delta proxy.
- UI explicitly labels delta as a proxy, not trade-level CVD or order-book data.
- Added tests for VWAP, Keltner and volume pressure.
- Local JS tests and syntax checks are required before packaging. No live market/device validation claimed.
