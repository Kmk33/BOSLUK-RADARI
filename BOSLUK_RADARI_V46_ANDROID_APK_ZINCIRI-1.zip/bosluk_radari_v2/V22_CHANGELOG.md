# V22 changelog

- Fixed walk-forward outcome leakage across out-of-sample fold boundaries.
- A signal is now counted only when its entire forward evaluation horizon fits inside the same test fold.
- Added `oos_evaluable_signals` and `excluded_boundary_signals` diagnostics per fold.
- Preserved chronological training warm-up and existing entry/target/stop assumptions.
- Added regression coverage for fold-boundary isolation.
- 75/75 unit tests pass. No live Binance run or APK build is claimed.
