# BOŞLUK RADARI — Telefonda APK alma rehberi

## Bu paket ne sağlar?
Bu kaynak paketi Android debug APK üretmek için GitHub Actions iş akışı içerir. Derleme GitHub'ın geçici Ubuntu/Android derleme ortamında yapılır; uygulamanın çalışma zamanı ise telefondadır. Uygulama Binance Spot herkese açık verilerini doğrudan telefondan çeker ve analizleri cihazda yapar. VPS veya kullanıcı tarafından kurulacak ayrı bir API sunucusu gerekmez.

## Telefonda APK üretme
1. ZIP'i telefona indirip aç.
2. GitHub'da yeni, boş bir depo oluştur.
3. ZIP içindeki `bosluk_radari_v2` klasörünün **içeriğini** deponun ana dizinine yükle. Özellikle `.github/workflows/android-debug-apk.yml` dosyasının depoda bu tam yolda bulunduğunu kontrol et.
4. `mobile-ui/package.json` ve `mobile-ui/src` klasörlerinin deponun ana dizinine bağlı doğru konumda olduğunu kontrol et.
5. Dosyaları `main` dalına gönder. `main` veya `master` dalına gönderim otomatik derlemeyi başlatır.
6. GitHub deposunda **Actions** sekmesine gir. “Build BOŞLUK RADARI Android APK” çalışmasının tamamlanmasını bekle.
7. Başarılı çalışmanın sayfasında **Artifacts** bölümünden `bosluk-radari-debug-apk` dosyasını indir.
8. ZIP içindeki `app-debug.apk` dosyasını Android telefonda açıp kurulumu onayla. Android, bilinmeyen uygulama kaynağı izni isteyebilir.

## Önemli sınırlar
- Bu sürüm bir **debug APK** üretmeyi hedefler; Play Store imzalı release paketi değildir.
- İş akışı henüz gerçek GitHub hesabında çalıştırılıp doğrulanmış değildir. İlk GitHub derlemesi hata verirse Actions günlükleri hatanın kaynağını gösterir.
- Bu çalışma ortamında Android SDK/Gradle derleme zinciri bulunmadığı için burada APK üretildiği iddia edilmemektedir.
- Binance canlı bağlantısı, Android WebView ağ erişimi ve gerçek telefona kurulum henüz doğrulanmış değildir.
- APK derlense bile canlı tarama için telefonun internet bağlantısı gerekir.
