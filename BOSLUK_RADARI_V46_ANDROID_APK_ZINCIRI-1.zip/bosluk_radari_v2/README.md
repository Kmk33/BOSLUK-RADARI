# BOŞLUK RADARI — bağımsız Binance Spot analiz motoru

Bu depo, Android uygulamasının analiz çekirdeği ve mobil arayüz başlangıç projesidir.
İlk sürüm yalnızca Binance Spot USDT piyasasını okur; emir göndermez.

## Tasarım ilkeleri
- Sinyal yalnızca kapanmış mumlarla hesaplanır.
- Hedef boşluğu = (üstteki doğrulanmış direnç / son fiyat - 1) * 100.
- Direnç tek bir nokta değil, toleranslı fiyat bölgesidir.
- Bir formasyon adı tek başına sinyal değildir.
- Geçmiş testte geleceğe bakış (look-ahead) yasaktır.
- "Hedef potansiyeli" gerçekleşme garantisi değildir.

## Çekirdek
`engine/analysis.py`: göstergeler, pivot seviyeleri, sıkışma, kırılım ve hedef alanı.
`engine/binance.py`: Binance public Spot API istemcisi ve tarihsel mum sayfalayıcısı.\n`engine/walkforward.py`: kronolojik walk-forward değerlendirme yardımcıları.
`engine/scanner.py`: sembol tarama ve sıralama.
`tests/`: deterministik birim testleri.

## Kaynaklar
- Binance Spot API: https://github.com/binance/binance-spot-api-docs
- Binance market-data-only: https://github.com/binance/binance-spot-api-docs/blob/master/faqs/market_data_only.md
- TA-Lib gösterge kataloğu: https://ta-lib.org/
- TA-Lib Python: https://github.com/TA-Lib/ta-lib-python

## Durum
Bu, test edilebilir ilk mühendislik tabanıdır; henüz tamamlanmış APK değildir.
Android SDK/Gradle ile gerçek cihaz derlemesi ayrıca doğrulanmalıdır.

## Zaman dilimi anahtarları
- `1_saat` → Binance `1h`
- `4_saat` → Binance `4h`
- `1_gun` → Binance `1d`
- `1_hafta` → Binance `1w`
- `1_ay` → Binance `1M`

Yeni kodda bu açık anahtarları kullan; eski `1h` kısa adı geçmiş prototip uyumluluğu için haftalık periyot anlamında korunmuştur.

## Likidite ön filtresi
Tarama evreni önce Binance Spot USDT sembollerinden oluşturulur; 24 saatlik USDT kotasyon hacmi ve işlem sayısı eşikleri uygulanır. Varsayılan değerler 1 milyon USDT ve 500 işlemdir; en likit 150 sembol analiz edilir. Bu eşikler emir defteri derinliğinin veya düşük kaymanın garantisi değildir.

## Mikro yapı ölçümleri
`engine/microstructure.py` emir defteri spread ve notional dengesini, ayrıca aggTrades içindeki buyer-is-maker bayrağından taker alış/satış akışını hesaplar. Bunlar anlık ve değişken ölçümlerdir; tek başına alım sinyali değildir. AggTrade akışı tam tarihsel CVD değildir.

## Hacim profili
`engine/volume_profile.py` kapanmış OHLCV mumlarının hacmini fiyat aralığına yaklaşık dağıtarak POC, %70 değer alanı ve üst arz bölgeleri hesaplar. Bu yöntem gerçek işlem bazlı volume-at-price verisinin yerine geçmez; raporda açıkça yaklaşık olarak etiketlenir.

## Sinyal durumları ve hedef referansı
Tarama çıktısı her zaman diliminin hacim profili ve üst arz bölgelerini taşır. Referans fiyatında en güncel mevcut zaman dilimi önceliklidir (saatlikten aylığa). Sinyal durumu hazırlık, teyitli kırılım, risk/geçersiz veya izleme olarak ayrılır; herhangi bir zaman dilimindeki aşağı yönlü risk diğer olumlu etiketleri bastırır.
\n## Mobil arayüz başlangıcı (V11)\n`mobile-ui/` klasöründe mobil öncelikli Vite arayüzü bulunur. `/api/radar` sözleşmesini bekler; backend bağlantısı olmadan sahte aday göstermez. Kurulum ve API sözleşmesi için `mobile-ui/README.md` dosyasına bak.\n\n## API servisi (V12)\n`python tools/run_api.py` ile read-only API başlatılır. Uç noktalar ve ağ/güvenlik sınırlamaları için `API_README.md` dosyasına bak.\n\n## Arka plan tarama akışı (V13)\nMobil ekran `POST /api/scan/start` ve `GET /api/scan/status/{job_id}` ile uzun taramaları takip eder. Ayrıntılar `API_README.md` içinde.\n\n## Android kabuğu (V14)\nMobil UI artık Capacitor 7 Android proje ekleme/senkronizasyon komutları içerir. `mobile-ui/README.md` ve `API_README.md` kurulum, API adresi ve güvenlik ayarlarını açıklar. Bu kaynak kodu henüz derlenmiş APK değildir.\n\n\n## V15 backend deployment\nSee `DEPLOYMENT_V15.md` for Docker Compose deployment of the read-only API. Keep it behind HTTPS and an authenticated reverse proxy; a token bundled in an APK is extractable.\n\n## V16 market-data resilience\nThe Spot client now caches exchange metadata (1h) and 24h tickers (15s), and applies bounded retries to transient failures. Binance 418/429 rate limits are surfaced immediately rather than retried. See `V16_CHANGELOG.md`.\n\n## V17 scan diagnostics\nScan results now include timing, throughput, estimated remaining time during progress, failed-symbol counts, and an approximate Kline request count. These diagnostics do not influence signal scores.\n\n## V18 live Spot smoke test\nRun `python -m tools.live_spot_check --top-n 3` in a network-enabled environment to perform a bounded, read-only Binance Spot check and one-hourly-timeframe sample scan. It prints JSON and exits nonzero if the checks fail. The command was not run against live Binance while preparing this package.\n\n## V19 breakout retest evidence\nEach scanned timeframe now includes separate close-based breakout/retest evidence. A retest is labeled confirmed only after a volume-confirmed close above a prior pivot resistance and a later bullish close after testing that level. This evidence does not change ranking or override risk gates.\n\n## V20 resistance map\nCombined scan output now contains `combined.resistance_map`: nearest overhead obstacle, gap to first obstacle, pivot/supply sources, and theoretical +50/+100/+200% milestones. It is informational only; it does not change ranking or risk gates.\n\n## V21 setup-quality evidence\n`combined.setup_quality` reports de-duplicated evidence buckets. Correlated EMA and volume signals do not stack, and any downside-risk timeframe blocks bullish qualification. It is informational and does not alter the established rank score.\n\n## V22 walk-forward boundary safety\nWalk-forward outcomes must now finish within the same out-of-sample fold that generated the signal. Boundary-crossing events are excluded and counted in `excluded_boundary_signals`; see `oos_evaluable_signals`.\n\n## V23 quality-band research\n`walk_forward_breakouts(..., quality_score_fn=callback)` optionally groups OOS results by score bands. The callback receives only the candle prefix ending at the signal candle, preventing future data from entering the score. Scores are supplied by the caller; this package does not claim that arbitrary scores are calibrated probabilities.\n\n## V24 causal historical quality\nRun `python tools/spot_walkforward.py --symbols BTCUSDT,ETHUSDT --interval 1h --start-ms <UTC_MS> --end-ms <UTC_MS> --quality-bands`. This rebuilds setup quality at each OOS signal close using only that candle prefix. The current historical score is single-timeframe and is not a calibrated probability.\n\n## V25 live diagnostic classification\n`python -m tools.live_spot_check --top-n 3` now reports `environment_diagnosis` and classifies DNS/network failures separately. The bounded diagnostic timeout is intentionally shorter than production client retry settings. A DNS failure in one environment is not evidence that Binance is globally unavailable.\n\n## V27 production safety and deployment\nProduction startup (`RADAR_ENV=production`) requires a 32+ character `RADAR_API_TOKEN` and explicit HTTPS `RADAR_ALLOWED_ORIGINS`; wildcard and HTTP origins fail closed. Copy `.env.example` to `.env` and follow `DEPLOYMENT_CHECKLIST_TR.md` before VPS deployment.\n