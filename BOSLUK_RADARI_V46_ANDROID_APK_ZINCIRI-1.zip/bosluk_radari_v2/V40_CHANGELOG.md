# V40 — Destek/direnç tarihsel doğrulama

- Yeni `structure-validation.js`: destek ve direnç bölgelerinin tarihsel tepkisini ölçen kronolojik evaluator.
- Her mumdaki seviyeler yalnızca o mum ve öncesindeki kapanmış mumlardan türetilir; sonuç ölçümü bir sonraki mumda başlar.
- Destek için tepki/kırılma; direnç için ret/kırılma ve sonuçsuz olaylar ayrı sayılır.
- Olay başına seviye, yakınlık, temas sayısı, güç etiketi, sonuca kadar mum sayısı ve aşırı hareket raporlanır.
- Her zaman dilimi taramasında son indirilen kapanmış mumlar üzerinden sınırlı tarihsel özet hesaplanır ve coin detayında örneklem sayısı ile oranlar gösterilir.
- Oranlar küçük örneklemde güvenilir değildir; geleceğe dönük garanti değildir.
- 33/33 Node testi başarılı; JavaScript sözdizimi kontrolleri temiz.
- Vite production build, canlı Binance ve Android cihaz testi bu ortamda yapılmadı. APK üretilmedi.
