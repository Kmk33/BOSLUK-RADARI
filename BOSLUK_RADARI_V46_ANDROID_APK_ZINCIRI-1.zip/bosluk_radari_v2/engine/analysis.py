"""Deterministic technical analysis using closed OHLCV candles only."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import List, Dict, Optional
import math

@dataclass
class Candle:
    open_time: int
    open: float
    high: float
    low: float
    close: float
    volume: float
    quote_volume: float = 0.0
    taker_buy_base: float = 0.0
    closed: bool = True

@dataclass
class Analysis:
    symbol: str
    timeframe: str
    price: float
    resistance: Optional[float]
    upside_pct: Optional[float]
    support: Optional[float]
    rvol: float
    rsi: float
    ema20: float
    ema50: float
    ema90: float
    ema200: float
    bb_width_pct: float
    buy_pressure: float
    breakout: bool
    squeeze: bool
    downside_risk: bool
    score: float
    state: str
    reasons: List[str]

def ema(values: List[float], period: int) -> List[float]:
    if period <= 0: raise ValueError("period must be positive")
    if len(values) < period: return [float("nan")] * len(values)
    out=[float("nan")]*len(values)
    seed=sum(values[:period])/period
    out[period-1]=seed
    alpha=2/(period+1)
    for i in range(period,len(values)):
        out[i]=values[i]*alpha+out[i-1]*(1-alpha)
    return out

def rsi(values: List[float], period: int=14) -> float:
    if len(values) <= period: return 50.0
    gains=[]; losses=[]
    for a,b in zip(values[-period-1:-1], values[-period:]):
        d=b-a; gains.append(max(d,0)); losses.append(max(-d,0))
    ag=sum(gains)/period; al=sum(losses)/period
    if al == 0: return 100.0 if ag > 0 else 50.0
    return 100 - 100/(1+ag/al)

def _pivot_levels(candles: List[Candle], left=3, right=3):
    highs=[]; lows=[]
    # Strictly historical pivots: right bars must already be closed.
    for i in range(left, len(candles)-right):
        c=candles[i]
        if all(c.high > candles[j].high for j in range(i-left,i)) and all(c.high >= candles[j].high for j in range(i+1,i+right+1)):
            highs.append(c.high)
        if all(c.low < candles[j].low for j in range(i-left,i)) and all(c.low <= candles[j].low for j in range(i+1,i+right+1)):
            lows.append(c.low)
    return highs,lows

def analyze(symbol: str, timeframe: str, candles: List[Candle]) -> Optional[Analysis]:
    # The final candle is excluded unless explicitly closed.
    cs=[c for c in candles if c.closed]
    if len(cs)<220: return None
    closes=[c.close for c in cs]; highs=[c.high for c in cs]; lows=[c.low for c in cs]; vols=[c.volume for c in cs]
    e20=ema(closes,20)[-1]; e50=ema(closes,50)[-1]; e90=ema(closes,90)[-1]; e200=ema(closes,200)[-1]
    last=cs[-1]; price=last.close
    avgvol=sum(vols[-21:-1])/20
    rvol=last.volume/avgvol if avgvol>0 else 0
    # Bollinger width, 20 periods, population standard deviation
    window=closes[-20:]; mid=sum(window)/20
    variance=sum((x-mid)**2 for x in window)/20
    sd=math.sqrt(variance)
    bb_width=(4*sd/mid*100) if mid else 0
    # Compare width with preceding 100 completed bars.
    widths=[]
    for end in range(max(20,len(closes)-100),len(closes)):
        w=closes[end-20:end]; m=sum(w)/20
        if m:
            s=math.sqrt(sum((x-m)**2 for x in w)/20)
            widths.append(4*s/m*100)
    squeeze=bool(widths and bb_width <= sorted(widths)[max(0,int(len(widths)*0.2)-1)])
    # Support/resistance are derived only from candles preceding the latest close.
    prev=cs[:-1]
    prev_ph,prev_pl=_pivot_levels(prev[-180:])
    resistance=min((x for x in prev_ph if x > price*1.001), default=None)
    support=max((x for x in prev_pl if x < price*0.999 and x > price*0.90), default=None)
    # Breakout: close above resistance derived from preceding bars only.
    prior_res=max(prev_ph[-5:], default=None)
    breakout=bool(prior_res and price > prior_res*1.002 and rvol>=1.5)
    buy_pressure=(last.taker_buy_base/last.volume) if last.volume>0 else 0.5
    downside=bool((support and price < support*0.995) or (price<e200 and e50<e200 and rsi(closes)<35))
    reasons=[]
    if price>e20>e50: reasons.append("EMA20 > EMA50 ve fiyat üstte")
    if e50>e90>e200: reasons.append("EMA50/90/200 yükseliş dizilimi")
    if squeeze: reasons.append("Bollinger sıkışması")
    if rvol>=1.5: reasons.append(f"RVOL {rvol:.2f}")
    if buy_pressure>=0.55: reasons.append("Alıcı hacmi baskın")
    if breakout: reasons.append("Hacimli kapanış kırılımı")
    upside=((resistance/price)-1)*100 if resistance else None
    score=0
    score+=15 if price>e20 else 0
    score+=10 if e20>e50 else 0
    score+=10 if e50>e90 else 0
    score+=10 if e90>e200 else 0
    score+=15 if squeeze else 0
    score+=15 if rvol>=1.5 else 0
    score+=10 if buy_pressure>=0.55 else 0
    score+=15 if breakout else 0
    if downside: score=0
    if downside: state="ELENDİ"
    elif breakout and upside is not None and upside>=50: state="KIRILIM + GENİŞ BOŞLUK"
    elif breakout: state="KIRILIM ONAYLI"
    elif squeeze: state="HAZIRLIK"
    else: state="İZLEME"
    return Analysis(symbol,timeframe,price,resistance,upside,support,rvol,rsi(closes),e20,e50,e90,e200,bb_width,buy_pressure,breakout,squeeze,downside,float(score),state,reasons)
