"""Leakage-aware event backtest for closed-candle breakout candidates."""
from dataclasses import dataclass, asdict
from typing import List, Optional
from .analysis import Candle, _pivot_levels

@dataclass
class TradeResult:
    signal_index: int
    entry: float
    target: float
    stop: float
    target_pct: float
    stop_pct: float
    outcome: str
    bars_to_outcome: Optional[int]
    max_favorable_pct: float
    max_adverse_pct: float

def evaluate_breakouts(candles: List[Candle], lookback=40, horizon=30,
                       target_pct=0.50, stop_pct=0.08, fee_pct=0.001):
    """
    Evaluate a close above the maximum high of the preceding `lookback` bars.
    Signal uses only bars through t; outcome begins at t+1. If target and stop
    are both touched in one bar, conservatively count stop first.
    target_pct and stop_pct are fractions (0.50 = +50%, 0.08 = -8%).
    """
    cs=[c for c in candles if c.closed]
    results=[]
    if len(cs) < lookback + horizon + 2: return results
    for i in range(lookback, len(cs)-horizon):
        prior_high=max(c.high for c in cs[i-lookback:i])
        c=cs[i]
        if c.close <= prior_high*1.002: continue
        # volume confirmation using only completed candles up to signal bar
        hist=[x.volume for x in cs[i-20:i]]
        avg=sum(hist)/len(hist) if hist else 0
        rvol=c.volume/avg if avg else 0
        if rvol < 1.5: continue
        entry=c.close*(1+fee_pct)
        target=entry*(1+target_pct)
        stop=entry*(1-stop_pct)
        outcome="UNRESOLVED"; bars=None
        max_fav=0.0; max_adv=0.0
        for j in range(i+1,i+horizon+1):
            future=cs[j]
            max_fav=max(max_fav,(future.high/entry-1)*100)
            max_adv=min(max_adv,(future.low/entry-1)*100)
            hit_stop=future.low<=stop
            hit_target=future.high>=target
            if hit_stop and hit_target:
                outcome="STOP_FIRST_SAME_BAR"; bars=j-i; break
            if hit_stop:
                outcome="STOP"; bars=j-i; break
            if hit_target:
                outcome="TARGET"; bars=j-i; break
        results.append(TradeResult(i,entry,target,stop,target_pct*100,stop_pct*100,outcome,bars,max_fav,max_adv))
    return results

def summarize(results):
    n=len(results)
    if not n: return {"signals":0,"target_rate_pct":None,"stop_rate_pct":None,"unresolved":0,"avg_max_favorable_pct":None,"avg_max_adverse_pct":None}
    wins=sum(r.outcome=="TARGET" for r in results)
    stops=sum(r.outcome in ("STOP","STOP_FIRST_SAME_BAR") for r in results)
    return {"signals":n,"target_rate_pct":wins/n*100,"stop_rate_pct":stops/n*100,
            "unresolved":sum(r.outcome=="UNRESOLVED" for r in results),
            "avg_max_favorable_pct":sum(r.max_favorable_pct for r in results)/n,
            "avg_max_adverse_pct":sum(r.max_adverse_pct for r in results)/n}
