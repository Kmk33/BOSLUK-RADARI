"""Binance Spot USDT universe and timeframe scanning helpers."""
from .binance import BinanceSpot
from .analysis import Candle, analyze
from .patterns import detect_patterns
from .multitimeframe import combine_timeframes, target_ladder
from .microstructure import analyze_order_book, analyze_aggressor_flow
from .volume_profile import build_volume_profile, overhead_supply_zones
from .retest import detect_breakout_retest
from .resistance_map import build_resistance_map
from .setup_quality import score_setup_quality
import time

# Canonical UI names avoid the Turkish "1h" ambiguity (hour vs hafta).
TIMEFRAMES={
    "1_saat":"1h",
    "4_saat":"4h",
    "1_gun":"1d",
    "1_hafta":"1w",
    "1_ay":"1M",
}
# Backward-compatible aliases from early prototypes.
LEGACY_TIMEFRAMES={"1s":"1h","4s":"4h","1g":"1d","1h":"1w","1a":"1M"}

def resolve_interval(tf):
    if tf in TIMEFRAMES: return TIMEFRAMES[tf]
    if tf in LEGACY_TIMEFRAMES: return LEGACY_TIMEFRAMES[tf]
    if tf in ("1m","3m","5m","15m","30m","2h","6h","8h","12h","3d"): return tf
    raise ValueError(f"Unsupported timeframe: {tf}")

def spot_usdt_symbols(client):
    info=client.exchange_info()
    excluded_suffixes=("UPUSDT","DOWNUSDT","BULLUSDT","BEARUSDT")
    return [s["symbol"] for s in info["symbols"]
            if s.get("status")=="TRADING" and s.get("quoteAsset")=="USDT"
            and s.get("isSpotTradingAllowed",True)
            and not s["symbol"].endswith(excluded_suffixes)]

def scan_one(client,symbol,tf):
    interval=resolve_interval(tf)
    rows=client.klines(symbol,interval,limit=500)
    candles=[Candle(r["open_time"],r["open"],r["high"],r["low"],r["close"],r["volume"],r["quote_volume"],r["taker_buy_base"],r["closed"]) for r in rows]
    analysis=analyze(symbol,tf,candles)
    profile=build_volume_profile(candles)
    supply=overhead_supply_zones(candles,analysis.price) if analysis else {"valid":False,"zones":[]}
    return {"analysis":analysis,"patterns":detect_patterns(candles),
            "breakout_retest":detect_breakout_retest(candles),
            "volume_profile":profile,"overhead_supply":supply}

def scan_symbol_timeframes(client,symbol,timeframes=None):
    """Analyze one symbol across requested timeframes and combine confluence."""
    requested=timeframes or list(TIMEFRAMES)
    analyses={}
    pattern_rows={}
    profiles={}
    supply_rows={}
    retest_rows={}
    for tf in requested:
        result=scan_one(client,symbol,tf)
        analyses[tf]=result["analysis"]
        pattern_rows[tf]=result["patterns"]
        profiles[tf]=result["volume_profile"]
        supply_rows[tf]=result["overhead_supply"]
        retest_rows[tf]=result.get("breakout_retest",{"confirmed":False,"status":"NOT_AVAILABLE"})
    combined=combine_timeframes(analyses)
    resistances=[a.resistance for a in analyses.values() if a and a.resistance]
    # Use the freshest available timeframe price; never let a stale monthly
    # close overwrite the current hourly/4h reference price.
    price_order=("1_saat","1s","4_saat","4s","1_gun","1g","1_hafta","1h","1_ay","1a")
    price=next((analyses[k].price for k in price_order
                if k in analyses and analyses[k] is not None),None)
    if price is None:
        price=next((a.price for a in analyses.values() if a is not None),None)
    combined["reference_price"]=price
    combined["targets"]=target_ladder(price,resistances) if price else []
    # Supply-aware theoretical map: highlight the nearest obstacle before distant milestones.
    combined["resistance_map"]=build_resistance_map(
        price,resistances,
        supply={"valid":any(x.get("valid") for x in supply_rows.values()),
                "zones":[z for item in supply_rows.values() if item.get("valid")
                         for z in item.get("zones",[])]}
    ) if price else None
    # Explicit states keep early setups separate from confirmed close-based breaks.
    if any(a and a.downside_risk for a in analyses.values()):
        state="RİSK / GEÇERSİZ"
    elif any(a and a.breakout for a in analyses.values()):
        state="TEYİTLİ KIRILIM"
    elif any(ptn.get("bias")=="bullish" for group in pattern_rows.values() for ptn in group):
        state="FORMASYON / HAZIRLIK"
    else:
        state="İZLEME"
    combined["signal_state"]=state
    combined["setup_quality"]=score_setup_quality(
        analyses,pattern_rows,retest_rows,combined.get("resistance_map"))
    return {"symbol":symbol,"timeframes":analyses,"patterns":pattern_rows,
            "volume_profiles":profiles,"overhead_supply":supply_rows,
            "breakout_retests":retest_rows,"combined":combined}


def liquid_spot_universe(client,min_quote_volume=1_000_000,min_trades=500,top_n=150):
    """Return eligible USDT Spot symbols ranked by 24h quote turnover.

    quoteVolume is denominated in USDT for USDT-quoted symbols. This is a
    liquidity prefilter, not a guarantee of executable depth or low slippage.
    """
    if min_quote_volume < 0 or min_trades < 0 or top_n < 1:
        raise ValueError("Invalid liquidity filter settings")
    allowed=set(spot_usdt_symbols(client))
    tickers=client.ticker_24h()
    rows=[]
    for t in tickers:
        symbol=t.get("symbol")
        if symbol not in allowed: continue
        try:
            quote_volume=float(t.get("quoteVolume",0))
            trades=int(t.get("count",0))
            last_price=float(t.get("lastPrice",0))
        except (TypeError,ValueError):
            continue
        if quote_volume < min_quote_volume or trades < min_trades or last_price <= 0:
            continue
        rows.append({"symbol":symbol,"quote_volume_24h":quote_volume,
                     "trades_24h":trades,"last_price":last_price})
    rows.sort(key=lambda x:(x["quote_volume_24h"],x["trades_24h"]),reverse=True)
    return rows[:top_n]

def rank_scan_results(results):
    """Risk-first ranking: any downside-risk timeframe excludes the candidate."""
    ranked=[]
    for item in results:
        analyses=item.get("timeframes",{})
        valid=[a for a in analyses.values() if a is not None]
        if not valid or any(a.downside_risk for a in valid):
            continue
        combined=item.get("combined",{})
        patterns=item.get("patterns",{})
        bullish_patterns=sum(1 for group in patterns.values()
                             for ptn in group if ptn.get("bias")=="bullish")
        breakout_count=sum(1 for a in valid if a.breakout)
        score=float(combined.get("score",0))
        gap=combined.get("target_gap_pct")
        # A wide resistance gap is a sorting input only, capped to avoid
        # letting an extreme/poorly sampled level dominate the score.
        gap_component=min(max(float(gap or 0),0),100)/10
        rank_score=score + min(breakout_count*4,20) + min(bullish_patterns*2,10) + gap_component
        ranked.append({**item,"rank_score":round(rank_score,2),
                       "breakout_timeframes":breakout_count,
                       "bullish_pattern_count":bullish_patterns})
    ranked.sort(key=lambda x:(x["rank_score"],x["breakout_timeframes"]),reverse=True)
    for index,item in enumerate(ranked,1): item["rank"]=index
    return ranked

def scan_liquid_market(client,min_quote_volume=1_000_000,min_trades=500,
                       top_n=150,timeframes=None,progress_callback=None):
    """Liquidity prefilter and risk-first scan with operational timing diagnostics."""
    started=time.perf_counter()
    universe_started=time.perf_counter()
    universe=liquid_spot_universe(client,min_quote_volume,min_trades,top_n)
    universe_seconds=time.perf_counter()-universe_started
    results=[]
    scan_started=time.perf_counter()
    successful=0
    errors=0
    requested=list(timeframes or TIMEFRAMES.keys())
    for index,market in enumerate(universe,1):
        symbol_started=time.perf_counter()
        try:
            item=scan_symbol_timeframes(client,market["symbol"],requested)
            item["market_24h"]=market
            results.append(item)
            successful+=1
        except Exception as exc:
            results.append({"symbol":market["symbol"],"error":str(exc)[:240],
                            "error_type":type(exc).__name__,"market_24h":market})
            errors+=1
        finally:
            elapsed=time.perf_counter()-scan_started
            avg=elapsed/index
            remaining=max(0,len(universe)-index)
            if progress_callback:
                progress_callback({
                    "completed":index,"total":len(universe),
                    "symbol":market["symbol"],"successful":successful,"errors":errors,
                    "symbol_seconds":round(time.perf_counter()-symbol_started,3),
                    "elapsed_seconds":round(elapsed,2),
                    "average_seconds_per_symbol":round(avg,3),
                    "estimated_remaining_seconds":round(avg*remaining,1)
                })
    total_seconds=time.perf_counter()-started
    scan_seconds=time.perf_counter()-scan_started
    return {"universe_count":len(universe),
            "scanned_count":successful,
            "errors":[x for x in results if "error" in x],
            "candidates":rank_scan_results([x for x in results if "timeframes" in x]),
            "diagnostics":{
                "universe_seconds":round(universe_seconds,3),
                "scan_seconds":round(scan_seconds,3),
                "total_seconds":round(total_seconds,3),
                "average_seconds_per_symbol":round(scan_seconds/len(universe),3) if universe else 0,
                "successful_symbols":successful,
                "failed_symbols":errors,
                "requested_timeframes":requested,
                "estimated_klines_requests":len(universe)*len(requested)
            }}

def scan_microstructure(client,symbol,depth_limit=100,trade_limit=500):
    """Fetch a current Spot book snapshot and recent aggTrade flow."""
    book=client.depth(symbol,limit=depth_limit)
    trades=client.agg_trades(symbol,limit=trade_limit)
    return {"order_book":analyze_order_book(book),
            "aggressor_flow":analyze_aggressor_flow(trades),
            "snapshot_warning":"Order book and aggTrades are separate snapshots and may not be synchronized."}

def attach_microstructure(client,scan_result):
    """Attach microstructure evidence without allowing it to override downside risk."""
    symbol=scan_result["symbol"]
    try:
        micro=scan_microstructure(client,symbol)
        scan_result["microstructure"]=micro
        book=micro["order_book"]
        flow=micro["aggressor_flow"]
        # Add a transparent warning flag, not an automatic bullish score.
        scan_result["microstructure_warning"]=(
            not book.get("valid") or
            (book.get("spread_pct") is not None and book["spread_pct"]>0.50) or
            not flow.get("valid")
        )
    except Exception as exc:
        scan_result["microstructure"]={"error":str(exc)}
        scan_result["microstructure_warning"]=True
    return scan_result
