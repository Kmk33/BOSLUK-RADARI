"""Multi-timeframe confluence and target-gap ranking."""
from typing import Dict, List

ORDER=("1_saat","4_saat","1_gun","1_hafta","1_ay","1s","4s","1g","1h","1a")

def target_ladder(price: float, resistances: List[float]):
    levels=sorted({float(x) for x in resistances if x and x>price})
    return [{"resistance":x,"upside_pct":(x/price-1)*100} for x in levels]

def combine_timeframes(results: Dict[str, object]):
    usable={k:v for k,v in results.items() if v is not None}
    if not usable: return {"score":0,"confluence":0,"bias":"VERİ YETERSİZ","target_gap_pct":None,"timeframes":[]}
    ordered=[k for k in ORDER if k in usable]
    if not ordered: ordered=list(usable)
    # Reward independent timeframe agreement, cap at 100; do not sum duplicate indicators.
    breakout=sum(bool(usable[k].breakout) for k in ordered)
    bullish=sum(1 for k in ordered if usable[k].ema20>usable[k].ema50 and usable[k].price>usable[k].ema20)
    risk=sum(bool(usable[k].downside_risk) for k in ordered)
    scores=[usable[k].score for k in ordered]
    score=min(100,round(sum(scores)/len(scores)*0.65 + (breakout/len(ordered))*25 + (bullish/len(ordered))*10))
    if risk:
        bias="RİSKLİ"
    elif breakout>=2 and bullish>=3:
        bias="ÇOKLU ZAMAN DİLİMİ KIRILIMI"
    elif breakout:
        bias="KIRILIM VAR"
    else:
        bias="HAZIRLIK / İZLEME"
    gaps=[usable[k].upside_pct for k in ordered if usable[k].upside_pct is not None]
    gap=min(gaps) if gaps else None
    return {"score":score,"confluence":breakout,"bias":bias,"target_gap_pct":gap,"timeframes":ordered,
            "breakouts":breakout,"bullish_trend_count":bullish,"risk_timeframes":risk}
