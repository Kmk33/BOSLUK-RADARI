"""Public-only Binance Spot market data client; no credentials or order methods."""
import time
import copy
import threading
import requests

BASES=("https://data-api.binance.vision","https://api.binance.com")
VALID_INTERVALS={"1m","3m","5m","15m","30m","1h","2h","4h","6h","8h","12h","1d","3d","1w","1M"}

class BinanceSpot:
    def __init__(self, timeout=12, session=None, sleep=time.sleep,
                 retries=2, retry_delay=0.35, cache_ttl=60):
        self.s=session or requests.Session()
        self.timeout=timeout
        self.sleep=sleep
        self.retries=max(0,int(retries))
        self.retry_delay=max(0.0,float(retry_delay))
        self.cache_ttl=max(0.0,float(cache_ttl))
        self._cache={}
        self._cache_lock=threading.Lock()
    def _get(self,path,params=None):
        last=None
        retryable_status=(500,502,503,504)
        for base in BASES:
            for attempt in range(self.retries+1):
                try:
                    r=self.s.get(base+path,params=params,timeout=self.timeout)
                    if r.status_code in (418,429):
                        wait=int(r.headers.get("Retry-After","5"))
                        raise RuntimeError(f"Binance rate limited ({r.status_code}); retry after {wait}s")
                    if r.status_code in retryable_status and attempt < self.retries:
                        self.sleep(self.retry_delay*(2**attempt))
                        continue
                    r.raise_for_status()
                    return r.json()
                except Exception as e:
                    last=e
                    if "rate limited" in str(e): raise
                    # Retry transient transport errors; do not retry validation/4xx failures.
                    response=getattr(e,"response",None)
                    status=getattr(response,"status_code",None)
                    transient=(response is None or status in retryable_status)
                    if transient and attempt < self.retries:
                        self.sleep(self.retry_delay*(2**attempt))
                        continue
                    break
        raise RuntimeError(f"Binance public API unavailable: {last}")
    def _cached_get(self,key,path,ttl=None):
        lifetime=self.cache_ttl if ttl is None else max(0.0,float(ttl))
        now=time.monotonic()
        with self._cache_lock:
            item=self._cache.get(key)
            if item and now-item[0] < lifetime:
                return copy.deepcopy(item[1])
        value=self._get(path)
        with self._cache_lock:
            self._cache[key]=(time.monotonic(),value)
        return copy.deepcopy(value)
    def exchange_info(self):
        return self._cached_get("exchange_info","/api/v3/exchangeInfo",ttl=3600)
    def depth(self,symbol,limit=100):
        return self._get("/api/v3/depth",{"symbol":symbol,"limit":limit})
    def ticker_24h(self):
        return self._cached_get("ticker_24h","/api/v3/ticker/24hr",ttl=15)
    def agg_trades(self,symbol,limit=1000,start_time=None,end_time=None):
        if not 1 <= int(limit) <= 1000: raise ValueError("limit must be between 1 and 1000")
        if start_time is not None and end_time is not None and end_time < start_time:
            raise ValueError("end_time must be >= start_time")
        params={"symbol":symbol.upper(),"limit":int(limit)}
        if start_time is not None: params["startTime"]=int(start_time)
        if end_time is not None: params["endTime"]=int(end_time)
        return self._get("/api/v3/aggTrades",params)
    @staticmethod
    def _parse_klines(raw, now_ms=None):
        now=int(time.time()*1000) if now_ms is None else int(now_ms)
        return [{
            "open_time":int(x[0]),"open":float(x[1]),"high":float(x[2]),
            "low":float(x[3]),"close":float(x[4]),"volume":float(x[5]),
            "close_time":int(x[6]),"quote_volume":float(x[7]),
            "taker_buy_base":float(x[9]),"closed":int(x[6])<now
        } for x in raw]
    def klines(self,symbol,interval,limit=500):
        if interval not in VALID_INTERVALS: raise ValueError(f"Unsupported Binance interval: {interval}")
        if not 1 <= int(limit) <= 1000: raise ValueError("limit must be between 1 and 1000")
        raw=self._get("/api/v3/klines",{"symbol":symbol.upper(),"interval":interval,"limit":int(limit)})
        return self._parse_klines(raw)
    def historical_klines(self,symbol,interval,start_time,end_time=None,limit=1000,pause=0.15):
        """Download a bounded history with forward pagination and duplicate protection.

        start_time/end_time are Unix milliseconds. The end is inclusive at API level.
        """
        if interval not in VALID_INTERVALS: raise ValueError(f"Unsupported Binance interval: {interval}")
        if not 1 <= int(limit) <= 1000: raise ValueError("limit must be between 1 and 1000")
        start=int(start_time); end=int(end_time) if end_time is not None else None
        if start < 0 or (end is not None and end < start): raise ValueError("Invalid time range")
        cursor=start; rows={}
        while end is None or cursor <= end:
            params={"symbol":symbol.upper(),"interval":interval,"startTime":cursor,"limit":int(limit)}
            if end is not None: params["endTime"]=end
            batch=self._get("/api/v3/klines",params)
            if not batch: break
            for row in self._parse_klines(batch):
                if row["open_time"] >= start and (end is None or row["open_time"] <= end):
                    rows[row["open_time"]]=row
            last_open=int(batch[-1][0])
            next_cursor=last_open+1
            if next_cursor <= cursor or len(batch)<limit: break
            cursor=next_cursor
            if pause: self.sleep(pause)
        return [rows[k] for k in sorted(rows)]
