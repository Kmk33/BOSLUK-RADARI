"""Conservative evidence-bucket scoring with correlated indicators de-duplicated."""
from __future__ import annotations


def score_setup_quality(analyses, patterns=None, retests=None, resistance_map=None):
    """Score independent evidence buckets; indicators in one bucket never stack.

    This is a transparent research score, not a probability or expected return.
    Any timeframe downside-risk flag blocks bullish qualification.
    """
    analyses=analyses or {}
    patterns=patterns or {}
    retests=retests or {}
    valid=[a for a in analyses.values() if a is not None]
    if not valid:
        return {"score":0,"grade":"VERİ YETERSİZ","qualified":False,
                "risk_blocked":False,"evidence_buckets":{},"blockers":["Yeterli mum verisi yok"]}
    risk=[tf for tf,a in analyses.items() if a is not None and getattr(a,"downside_risk",False)]
    # One maximum per evidence family avoids adding correlated EMA signals together.
    trend_values=[]
    for a in valid:
        trend_values.append(1.0 if a.price>a.ema20>a.ema50>a.ema90>a.ema200 else
                            0.5 if a.price>a.ema20 and a.ema20>a.ema50 else 0.0)
    trend=max(trend_values,default=0)
    volume=max([1.0 if getattr(a,"rvol",0)>=1.5 and getattr(a,"buy_pressure",0.5)>=0.55 else
                0.5 if getattr(a,"rvol",0)>=1.5 or getattr(a,"buy_pressure",0.5)>=0.55 else 0.0
                for a in valid],default=0)
    breakout=max([1.0 if getattr(a,"breakout",False) else 0.0 for a in valid],default=0)
    bullish_patterns=[p for rows in patterns.values() for p in rows
                      if p.get("bias")=="bullish"]
    structure=1.0 if bullish_patterns else 0.0
    retest=1.0 if any(x.get("confirmed") for x in retests.values()) else 0.0
    # Resistance map is contextual only; no positive points for a distant theoretical target.
    obstacle=None
    if resistance_map:
        obstacle=resistance_map.get("first_obstacle")
    buckets={
        "trend_alignment":round(trend*25,1),
        "volume_confirmation":round(volume*20,1),
        "close_confirmed_breakout":round(breakout*20,1),
        "bullish_structure":round(structure*15,1),
        "confirmed_retest":round(retest*20,1)
    }
    score=round(sum(buckets.values()),1)
    blockers=[]
    if risk:
        blockers.append("Aşağı yönlü risk bulunan zaman dilimi: "+", ".join(risk))
    if not retest:
        blockers.append("Kırılım sonrası retest teyidi yok")
    if not breakout:
        blockers.append("Hacimli kapanış kırılımı yok")
    if not volume:
        blockers.append("Hacim/alıcı baskısı teyidi yok")
    if risk:
        grade="RİSK NEDENİYLE ELENDİ"
    elif score>=80 and retest and breakout:
        grade="GÜÇLÜ TEKNİK UYUM"
    elif score>=55 and (breakout or structure):
        grade="GELİŞEN KURULUM"
    else:
        grade="İZLEME"
    return {"score":score,"grade":grade,
            "qualified":bool(not risk and score>=55 and (breakout or structure)),
            "risk_blocked":bool(risk),"risk_timeframes":risk,
            "evidence_buckets":buckets,"blockers":blockers,
            "first_obstacle":obstacle,
            "warning":"Araştırma amaçlı puandır; olasılık, getiri tahmini veya alım sinyali değildir."}


def historical_prefix_quality(candles, symbol="HISTORICAL", timeframe="1h"):
    """Rebuild a single-timeframe quality score from data available at that close.

    This intentionally does not fabricate multi-timeframe confluence. It uses
    the current closed-candle analysis, heuristic patterns and confirmed retest
    evidence available within the supplied prefix only.
    """
    from .analysis import analyze
    from .patterns import detect_patterns
    from .retest import detect_breakout_retest

    prefix=[c for c in candles if c.closed]
    analysis=analyze(symbol,timeframe,prefix)
    if analysis is None:
        return {"score":0.0,"grade":"VERİ YETERSİZ","qualified":False,
                "risk_blocked":False,"warning":"En az 220 kapanmış mum gerekir."}
    patterns=detect_patterns(prefix)
    retest=detect_breakout_retest(prefix)
    return score_setup_quality(
        {timeframe:analysis},
        {timeframe:patterns},
        {timeframe:retest}
    )
