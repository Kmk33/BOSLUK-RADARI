"""Conservative close-based breakout/retest evidence; never a trade instruction."""
from __future__ import annotations
from typing import List, Optional, Dict
from .analysis import Candle
from .patterns import _pivots


def detect_breakout_retest(candles: List[Candle], lookback: int = 24,
                           tolerance_pct: float = 1.0,
                           min_breakout_rvol: float = 1.5) -> Dict:
    """Find a prior close-confirmed pivot breakout followed by a successful retest.

    The breakout candle must close above a resistance pivot known at that time
    and meet RVOL. A later closed candle must trade near the level and close
    above it. Intrabar-only breaks do not qualify.
    """
    if lookback < 3 or tolerance_pct <= 0 or min_breakout_rvol <= 0:
        raise ValueError("Invalid retest parameters")
    cs=[c for c in candles if c.closed]
    if len(cs)<60:
        return {"confirmed":False,"status":"INSUFFICIENT_HISTORY","level":None,
                "breakout_index":None,"retest_index":None,"evidence":None}
    start=max(0,len(cs)-lookback-1)
    # Need at least 30 bars of context before a possible breakout.
    for i in range(len(cs)-2, start, -1):
        prior=cs[:i]
        highs,_=_pivots(prior[-160:],left=2,right=2)
        if not highs:
            continue
        level=max(v for _,v in highs[-5:])
        bar=cs[i]
        avg=sum(c.volume for c in cs[max(0,i-20):i])/max(1,len(cs[max(0,i-20):i]))
        rvol=bar.volume/avg if avg>0 else 0
        if bar.close <= level*1.002 or rvol < min_breakout_rvol:
            continue
        # Search after breakout for a close-confirmed retest.
        for j in range(i+1,len(cs)):
            test=cs[j]
            near=abs(test.low-level)/level*100 <= tolerance_pct or (
                test.low <= level*(1+tolerance_pct/100) and test.low >= level*(1-2*tolerance_pct/100))
            if near and test.close>level and test.close>=test.open:
                return {"confirmed":True,"status":"RETEST_ONAYLI",
                        "level":level,"breakout_index":i,"retest_index":j,
                        "breakout_rvol":round(rvol,2),
                        "retest_distance_pct":round(abs(test.low-level)/level*100,3),
                        "evidence":"Önce hacimli kapanışla direnç üstü; ardından seviyeye temas ve seviyenin üzerinde güçlü kapanış"}
    return {"confirmed":False,"status":"NO_CONFIRMED_RETEST","level":None,
            "breakout_index":None,"retest_index":None,"evidence":None}
