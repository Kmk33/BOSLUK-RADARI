"""Overhead resistance map with supply-zone-aware theoretical gaps."""
from __future__ import annotations
from typing import List, Dict, Optional


def build_resistance_map(current_price: float, pivot_levels: List[float],
                         supply: Optional[Dict] = None,
                         milestones=(50.0,100.0,200.0),
                         merge_pct: float = 0.75) -> Dict:
    if current_price <= 0 or merge_pct < 0:
        raise ValueError("Invalid price or merge threshold")
    levels=sorted(float(x) for x in pivot_levels
                  if x is not None and float(x)>current_price)
    clusters=[]
    for level in levels:
        if clusters and (level/clusters[-1]["high"]-1)*100 <= merge_pct:
            clusters[-1]["high"]=level
            clusters[-1]["count"]+=1
        else:
            clusters.append({"low":level,"high":level,"count":1})
    zones=[]
    if supply and supply.get("valid"):
        for z in supply.get("zones",[]):
            lo=float(z.get("low",0)); hi=float(z.get("high",0))
            if hi>current_price and hi>=lo:
                zones.append({"low":max(lo,current_price),"high":hi,
                              "volume_share_pct":float(z.get("volume_share_pct",0)),
                              "source":"OHLCV_APPROX_SUPPLY"})
    obstacles=[]
    for c in clusters:
        obstacles.append({"low":c["low"],"high":c["high"],
                          "source":"PIVOT_CLUSTER","level_count":c["count"]})
    obstacles.extend(zones)
    obstacles.sort(key=lambda z:z["low"])
    # Merge overlapping obstacles; retain source labels and strongest measured volume share.
    merged=[]
    for z in obstacles:
        if merged and z["low"] <= merged[-1]["high"]:
            m=merged[-1]
            m["high"]=max(m["high"],z["high"])
            m["sources"]=sorted(set(m.get("sources",[m.get("source","")]))|{z.get("source","")})
            m["volume_share_pct"]=max(m.get("volume_share_pct",0),z.get("volume_share_pct",0))
        else:
            merged.append({"low":z["low"],"high":z["high"],
                           "sources":[z.get("source","")],
                           "volume_share_pct":z.get("volume_share_pct",0)})
    first=merged[0] if merged else None
    milestones_out=[]
    for pct in milestones:
        target=current_price*(1+float(pct)/100)
        blockers=[z for z in merged if z["low"]<=target and z["high"]>current_price]
        milestones_out.append({
            "target_pct":float(pct),"target_price":target,
            "reachable_without_known_obstacle":not blockers,
            "obstacle_count":len(blockers),
            "first_obstacle_low":blockers[0]["low"] if blockers else None
        })
    return {
        "current_price":current_price,
        "first_obstacle":first,
        "obstacles":merged,
        "theoretical_milestones":milestones_out,
        "gap_to_first_obstacle_pct":((first["low"]/current_price)-1)*100 if first else None,
        "warning":"Mesafeler teknik seviyelere göre teoriktir; hedef veya getiri garantisi değildir. OHLCV arz bölgeleri yaklaşık hesaplanır."
    }
