"""Order-book and recent trade-flow measurements; descriptive, not predictive."""
from math import isfinite

def analyze_order_book(book, depth_levels=20, band_bps=50):
    bids=book.get("bids",[])[:depth_levels]
    asks=book.get("asks",[])[:depth_levels]
    if not bids or not asks:
        return {"valid":False,"reason":"EMPTY_BOOK"}
    try:
        bid_prices=[float(x[0]) for x in bids]; bid_qty=[float(x[1]) for x in bids]
        ask_prices=[float(x[0]) for x in asks]; ask_qty=[float(x[1]) for x in asks]
    except (TypeError,ValueError,IndexError):
        return {"valid":False,"reason":"MALFORMED_BOOK"}
    if min(bid_prices+ask_prices)<=0 or min(bid_qty+ask_qty)<0:
        return {"valid":False,"reason":"INVALID_LEVEL"}
    best_bid=max(bid_prices); best_ask=min(ask_prices)
    if best_ask<=best_bid:
        return {"valid":False,"reason":"CROSSED_OR_LOCKED_BOOK"}
    mid=(best_bid+best_ask)/2
    spread_pct=(best_ask-best_bid)/mid*100
    bid_notional=sum(p*q for p,q in zip(bid_prices,bid_qty))
    ask_notional=sum(p*q for p,q in zip(ask_prices,ask_qty))
    total=bid_notional+ask_notional
    imbalance=(bid_notional-ask_notional)/total if total else 0.0
    band=band_bps/10000
    bid_band=sum(p*q for p,q in zip(bid_prices,bid_qty) if p>=mid*(1-band))
    ask_band=sum(p*q for p,q in zip(ask_prices,ask_qty) if p<=mid*(1+band))
    band_total=bid_band+ask_band
    band_imbalance=(bid_band-ask_band)/band_total if band_total else 0.0
    return {"valid":True,"best_bid":best_bid,"best_ask":best_ask,"mid_price":mid,
            "spread_pct":spread_pct,"bid_notional":bid_notional,"ask_notional":ask_notional,
            "book_imbalance":imbalance,"band_bps":band_bps,
            "band_bid_notional":bid_band,"band_ask_notional":ask_band,
            "band_imbalance":band_imbalance,
            "warning":"Anlık emir defteri değişebilir; spoofing/iptal emirleri nedeniyle tek başına sinyal değildir."}

def analyze_aggressor_flow(trades):
    """AggTrade buyer-is-maker flag: m=False means buyer was taker/aggressor."""
    buy_qty=0.0; sell_qty=0.0; buy_quote=0.0; sell_quote=0.0
    count=0
    for t in trades:
        try:
            qty=float(t["q"]); price=float(t["p"]); buyer_is_maker=bool(t["m"])
            if qty<0 or price<=0 or not isfinite(qty*price): continue
        except (KeyError,TypeError,ValueError):
            continue
        quote=qty*price
        if buyer_is_maker:
            sell_qty+=qty; sell_quote+=quote
        else:
            buy_qty+=qty; buy_quote+=quote
        count+=1
    total=buy_quote+sell_quote
    return {"valid":count>0,"trade_count":count,"taker_buy_base":buy_qty,
            "taker_sell_base":sell_qty,"taker_buy_quote":buy_quote,
            "taker_sell_quote":sell_quote,
            "taker_buy_share":buy_quote/total if total else None,
            "net_taker_quote":buy_quote-sell_quote,
            "label":"AggTrade taker-flow proxy; historical cumulative CVD değildir."}
