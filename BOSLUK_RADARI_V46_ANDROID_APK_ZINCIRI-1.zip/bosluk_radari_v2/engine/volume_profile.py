"""Approximate OHLCV volume profile and overhead supply-zone mapping.

This is candle-distributed volume, not exchange tick-level volume-at-price.
Each candle's volume is spread across the price bins intersecting its range.
"""
from collections import defaultdict
from math import isfinite

def build_volume_profile(candles, bins=80, lookback=240):
    cs=[c for c in candles if getattr(c,"closed",True)][-lookback:]
    if not cs or bins<5:
        return {"valid":False,"reason":"INSUFFICIENT_DATA_OR_BINS"}
    lo=min(float(c.low) for c in cs); hi=max(float(c.high) for c in cs)
    if not all(isfinite(x) for x in (lo,hi)) or hi<=lo:
        return {"valid":False,"reason":"INVALID_PRICE_RANGE"}
    width=(hi-lo)/bins
    volumes=[0.0]*bins
    for c in cs:
        low=float(c.low); high=float(c.high); vol=max(0.0,float(c.volume))
        if high<low or not isfinite(low+high+vol): continue
        first=max(0,min(bins-1,int((low-lo)/width)))
        last=max(0,min(bins-1,int((high-lo)/width)))
        if last<first: continue
        # Uniform range allocation is explicitly an approximation.
        share=vol/(last-first+1)
        for idx in range(first,last+1): volumes[idx]+=share
    total=sum(volumes)
    if total<=0: return {"valid":False,"reason":"ZERO_VOLUME"}
    poc_idx=max(range(bins),key=lambda i:volumes[i])
    ranked=sorted(range(bins),key=lambda i:volumes[i],reverse=True)
    value_indices=set(); cumulative=0.0
    for idx in ranked:
        value_indices.add(idx); cumulative+=volumes[idx]
        if cumulative>=total*0.70: break
    def bounds(i): return (lo+i*width,lo+(i+1)*width)
    return {"valid":True,"method":"OHLCV_UNIFORM_RANGE_APPROXIMATION",
            "bins":bins,"bin_width":width,"lookback_bars":len(cs),"total_volume":total,
            "poc":{"low":bounds(poc_idx)[0],"high":bounds(poc_idx)[1],
                   "mid":sum(bounds(poc_idx))/2,"volume":volumes[poc_idx]},
            "value_area":{"low":min(bounds(i)[0] for i in value_indices),
                          "high":max(bounds(i)[1] for i in value_indices)},
            "levels":[{"low":bounds(i)[0],"high":bounds(i)[1],
                       "mid":sum(bounds(i))/2,"volume":volumes[i],
                       "volume_share_pct":volumes[i]/total*100}
                      for i in sorted(range(bins),key=lambda j:volumes[j],reverse=True)[:min(12,bins)]]}

def overhead_supply_zones(candles, current_price, bins=80, lookback=240,
                          min_volume_share_pct=1.0, merge_gap_bins=1):
    """Create contiguous high-volume price zones above current price."""
    profile=build_volume_profile(candles,bins=bins,lookback=lookback)
    if not profile.get("valid"): return {"valid":False,"profile":profile,"zones":[]}
    levels=[x for x in profile["levels"]
            if x["high"]>current_price and x["volume_share_pct"]>=min_volume_share_pct]
    levels.sort(key=lambda x:x["low"])
    zones=[]
    for level in levels:
        if level["high"]<=current_price: continue
        if zones and level["low"] <= zones[-1]["high"] + profile["bin_width"]*merge_gap_bins:
            z=zones[-1]
            old=z["volume"]
            z["high"]=max(z["high"],level["high"])
            z["volume"]+=level["volume"]
            z["volume_share_pct"]+=level["volume_share_pct"]
            z["weighted_mid"]=(z["weighted_mid"]*old+level["mid"]*level["volume"])/z["volume"]
        else:
            zones.append({"low":max(level["low"],current_price),"high":level["high"],
                          "volume":level["volume"],"volume_share_pct":level["volume_share_pct"],
                          "weighted_mid":level["mid"]})
    zones.sort(key=lambda z:z["low"])
    for z in zones:
        z["distance_pct"]=(z["low"]/current_price-1)*100
        z["upper_distance_pct"]=(z["high"]/current_price-1)*100
    return {"valid":True,"profile":profile,"zones":zones,
            "warning":"OHLCV mum hacmi fiyat aralığına eşit dağıtılmış yaklaşık profildir; gerçek tick-level volume profile değildir."}
