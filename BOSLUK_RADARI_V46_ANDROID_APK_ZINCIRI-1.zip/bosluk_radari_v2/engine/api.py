"""Small read-only HTTP API for the BOŞLUK RADARI mobile UI."""
from __future__ import annotations
from dataclasses import asdict, is_dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
import json
import os
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor

from .binance import BinanceSpot
from .scanner import scan_liquid_market, TIMEFRAMES

ALLOWED_TIMEFRAMES=("1_saat","4_saat","1_gun","1_hafta","1_ay")
CACHE_TTL_SECONDS=30
_cache={}
_cache_lock=threading.Lock()
_jobs={}
_jobs_lock=threading.Lock()
_executor=ThreadPoolExecutor(max_workers=2,thread_name_prefix="radar-scan")
MAX_ACTIVE_JOBS=2
MAX_JOB_HISTORY=30
JOB_TTL_SECONDS=900


def json_safe(value):
    """Convert dataclasses and nested values to strict JSON-compatible data."""
    if is_dataclass(value):
        return json_safe(asdict(value))
    if isinstance(value, dict):
        return {str(k):json_safe(v) for k,v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    if isinstance(value, float):
        # NaN/Infinity are not valid JSON and must never leak to clients.
        if value != value or value in (float("inf"),float("-inf")):
            return None
    return value


def build_radar_payload(client, timeframe="all", top_n=30,
                        min_quote_volume=1_000_000, min_trades=500,
                        progress_callback=None):
    if timeframe != "all" and timeframe not in ALLOWED_TIMEFRAMES:
        raise ValueError("Unsupported timeframe")
    if not 1 <= int(top_n) <= 150:
        raise ValueError("top_n must be between 1 and 150")
    if float(min_quote_volume) < 0 or int(min_trades) < 0:
        raise ValueError("Liquidity thresholds cannot be negative")
    selected=list(TIMEFRAMES) if timeframe=="all" else [timeframe]
    result=scan_liquid_market(client,
        min_quote_volume=float(min_quote_volume),
        min_trades=int(min_trades),
        top_n=int(top_n),
        timeframes=selected,
        progress_callback=progress_callback)
    payload=json_safe(result)
    payload["timeframe_filter"]=timeframe
    payload["generated_at_utc"]=time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())
    payload["market_scope"]="BINANCE_SPOT_USDT"
    payload["orders_enabled"]=False
    return payload


def cached_radar(client, timeframe, top_n, min_quote_volume, min_trades, ttl=CACHE_TTL_SECONDS):
    key=(timeframe,int(top_n),float(min_quote_volume),int(min_trades))
    now=time.monotonic()
    with _cache_lock:
        item=_cache.get(key)
        if item and now-item[0] < ttl:
            cached=dict(item[1])
            cached["cache_hit"]=True
            return cached
    payload=build_radar_payload(client,timeframe,top_n,min_quote_volume,min_trades)
    payload["cache_hit"]=False
    with _cache_lock:
        _cache[key]=(time.monotonic(),payload)
    return payload


def _job_progress(job_id, update):
    with _jobs_lock:
        job=_jobs.get(job_id)
        if job and job["status"]=="running":
            job["progress"]={**update}


def _run_job(job_id, client, params):
    with _jobs_lock:
        job=_jobs.get(job_id)
        if not job:
            return
        job["status"]="running"
        job["started_at"]=time.time()
    try:
        payload=build_radar_payload(
            client, params["timeframe"], params["top_n"],
            params["min_quote_volume"], params["min_trades"],
            progress_callback=lambda update:_job_progress(job_id,update))
        with _jobs_lock:
            if job_id in _jobs:
                _jobs[job_id].update({"status":"completed","progress":{
                    "completed":payload.get("scanned_count",0),
                    "total":payload.get("universe_count",0)},
                    "result":payload,"finished_at":time.time()})
    except Exception as exc:
        with _jobs_lock:
            if job_id in _jobs:
                _jobs[job_id].update({"status":"failed","error":str(exc)[:240],
                                      "finished_at":time.time()})


def start_scan_job(client, timeframe="all", top_n=30,
                   min_quote_volume=1_000_000, min_trades=500):
    # Validate all inputs before creating a background job.
    if timeframe!="all" and timeframe not in ALLOWED_TIMEFRAMES:
        raise ValueError("Unsupported timeframe")
    if not 1 <= int(top_n) <= 150:
        raise ValueError("top_n must be between 1 and 150")
    if float(min_quote_volume)<0 or int(min_trades)<0:
        raise ValueError("Liquidity thresholds cannot be negative")
    params={"timeframe":timeframe,"top_n":int(top_n),
            "min_quote_volume":float(min_quote_volume),"min_trades":int(min_trades)}
    now=time.time()
    with _jobs_lock:
        expired=[k for k,v in _jobs.items()
                 if v.get("finished_at") and now-v["finished_at"]>JOB_TTL_SECONDS]
        for key in expired:
            _jobs.pop(key,None)
        active=sum(1 for v in _jobs.values() if v["status"] in ("queued","running"))
        if active>=MAX_ACTIVE_JOBS:
            raise RuntimeError("Too many active scans; try again shortly")
        job_id=uuid.uuid4().hex[:12]
        _jobs[job_id]={"job_id":job_id,"status":"queued","params":params,
                       "progress":{"completed":0,"total":0},"created_at":now}
    _executor.submit(_run_job,job_id,client,params)
    return {"job_id":job_id,"status":"queued","poll":f"/api/scan/status/{job_id}"}


def get_scan_job(job_id):
    with _jobs_lock:
        job=_jobs.get(job_id)
        if not job:
            return None
        # Avoid exposing internal scheduling timestamps or mutable job dict.
        return {k:v for k,v in job.items() if k not in ("created_at","started_at","finished_at")}


class RadarHandler(BaseHTTPRequestHandler):
    server_version="BoslukRadariAPI/0.27"
    def _allowed_origins(self):
        configured=os.getenv("RADAR_ALLOWED_ORIGINS","https://localhost,http://localhost:5173")
        return {x.strip() for x in configured.split(",") if x.strip()}
    def _cors_headers(self):
        origin=self.headers.get("Origin")
        if origin and origin in self._allowed_origins():
            self.send_header("Access-Control-Allow-Origin",origin)
            self.send_header("Vary","Origin")
    def _authorized(self):
        token=os.getenv("RADAR_API_TOKEN","").strip()
        if not token:
            return True
        supplied=self.headers.get("X-API-Token","")
        return supplied==token
    def _send(self,status,payload):
        raw=json.dumps(json_safe(payload),ensure_ascii=False,allow_nan=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Content-Length",str(len(raw)))
        self.send_header("Cache-Control","no-store")
        self._cors_headers()
        self.end_headers()
        self.wfile.write(raw)
    def do_OPTIONS(self):
        self.send_response(204)
        self._cors_headers()
        self.send_header("Access-Control-Allow-Methods","GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers","Content-Type, X-API-Token")
        self.send_header("Access-Control-Max-Age","600")
        self.end_headers()
    def do_POST(self):
        parsed=urlparse(self.path)
        if parsed.path!="/api/scan/start":
            return self._send(404,{"error":"not_found"})
        if not self._authorized():
            return self._send(401,{"error":"unauthorized"})
        try:
            length=int(self.headers.get("Content-Length","0"))
            if length>4096:
                return self._send(413,{"error":"request_too_large"})
            body=self.rfile.read(length) if length else b"{}"
            data=json.loads(body.decode("utf-8"))
            if not isinstance(data,dict):
                raise ValueError("JSON body must be an object")
            result=start_scan_job(
                self.server.binance_client,
                data.get("timeframe","all"),data.get("top_n",int(os.getenv("RADAR_TOP_N","30"))),
                data.get("min_quote_volume",float(os.getenv("RADAR_MIN_QUOTE_VOLUME","1000000"))),
                data.get("min_trades",int(os.getenv("RADAR_MIN_TRADES","500"))))
            return self._send(202,result)
        except (ValueError,TypeError,json.JSONDecodeError) as exc:
            return self._send(400,{"error":"invalid_request","message":str(exc)})
        except RuntimeError as exc:
            return self._send(429,{"error":"scan_capacity","message":str(exc)})
    def do_GET(self):
        parsed=urlparse(self.path)
        if parsed.path.startswith("/api/scan/status/"):
            if not self._authorized():
                return self._send(401,{"error":"unauthorized"})
            job_id=parsed.path.rsplit("/",1)[-1]
            job=get_scan_job(job_id)
            return self._send(200,job) if job else self._send(404,{"error":"job_not_found"})
        if parsed.path=="/health":
            return self._send(200,{"ok":True,"service":"bosluk-radari","scope":"BINANCE_SPOT_USDT"})
        if parsed.path!="/api/radar":
            return self._send(404,{"error":"not_found"})
        if not self._authorized():
            return self._send(401,{"error":"unauthorized"})
        q=parse_qs(parsed.query)
        try:
            timeframe=q.get("timeframe",["all"])[0]
            top_n=int(q.get("top_n",[os.getenv("RADAR_TOP_N","30")])[0])
            min_volume=float(q.get("min_quote_volume",[os.getenv("RADAR_MIN_QUOTE_VOLUME","1000000")])[0])
            min_trades=int(q.get("min_trades",[os.getenv("RADAR_MIN_TRADES","500")])[0])
            payload=cached_radar(self.server.binance_client,timeframe,top_n,min_volume,min_trades)
            return self._send(200,payload)
        except ValueError as exc:
            return self._send(400,{"error":"invalid_request","message":str(exc)})
        except Exception as exc:
            # Return a concise operational error, not a fabricated empty radar.
            return self._send(503,{"error":"market_data_unavailable","message":str(exc)[:240]})
    def log_message(self,fmt,*args):
        if os.getenv("RADAR_HTTP_LOG","0")=="1":
            super().log_message(fmt,*args)


def validate_deployment_config(env=None):
    """Fail closed on unsafe production configuration."""
    env=os.environ if env is None else env
    if env.get("RADAR_ENV","").lower()!="production":
        return {"production":False,"warnings":[]}
    warnings=[]
    token=env.get("RADAR_API_TOKEN","").strip()
    if len(token)<32:
        raise ValueError("Production requires RADAR_API_TOKEN with at least 32 characters")
    origins={x.strip() for x in env.get("RADAR_ALLOWED_ORIGINS","").split(",") if x.strip()}
    if not origins or "*" in origins:
        raise ValueError("Production requires explicit RADAR_ALLOWED_ORIGINS; wildcard is forbidden")
    if any(not x.startswith("https://") for x in origins):
        raise ValueError("Production allowed origins must all use HTTPS")
    host=env.get("RADAR_HOST","127.0.0.1")
    if host in ("0.0.0.0","::"):
        warnings.append("API binds to all interfaces; restrict ingress to a trusted HTTPS reverse proxy/firewall")
    return {"production":True,"warnings":warnings}


def serve(host=None,port=None):
    validate_deployment_config()
    host=host or os.getenv("RADAR_HOST","127.0.0.1")
    port=int(port or os.getenv("RADAR_PORT","8765"))
    server=ThreadingHTTPServer((host,port),RadarHandler)
    server.daemon_threads=True
    server.binance_client=BinanceSpot(timeout=float(os.getenv("BINANCE_TIMEOUT","12")))
    print(f"BOŞLUK RADARI API listening on http://{host}:{port}")
    print("Read-only Binance Spot market data; no order endpoints.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__=="__main__":
    serve()
