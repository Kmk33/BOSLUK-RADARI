"""Heuristic chart-structure detection. Outputs candidates, never standalone trade signals."""
from __future__ import annotations
from typing import List, Dict
from .analysis import Candle

def _slope(values):
    n=len(values)
    if n<3: return 0.0
    xbar=(n-1)/2
    ybar=sum(values)/n
    den=sum((i-xbar)**2 for i in range(n))
    return sum((i-xbar)*(y-ybar) for i,y in enumerate(values))/den if den else 0.0

def _pivots(cs, left=2, right=2):
    hi=[]; lo=[]
    for i in range(left,len(cs)-right):
        c=cs[i]
        if all(c.high>cs[j].high for j in range(i-left,i)) and all(c.high>=cs[j].high for j in range(i+1,i+right+1)):
            hi.append((i,c.high))
        if all(c.low<cs[j].low for j in range(i-left,i)) and all(c.low<=cs[j].low for j in range(i+1,i+right+1)):
            lo.append((i,c.low))
    return hi,lo

def detect_patterns(candles: List[Candle]) -> List[Dict]:
    cs=[c for c in candles if c.closed]
    if len(cs)<50: return []
    hi,lo=_pivots(cs[-160:])
    out=[]
    # Ascending triangle: relatively flat highs, rising lows.
    if len(hi)>=3 and len(lo)>=3:
        hs=[v for _,v in hi[-4:]]; ls=[v for _,v in lo[-4:]]
        hmean=sum(hs)/len(hs); lmean=sum(ls)/len(ls)
        hspread=(max(hs)-min(hs))/hmean if hmean else 1
        rising=_slope(ls)>0 and ls[-1]>ls[0]*1.005
        if hspread<=0.018 and rising and cs[-1].close<hmean*1.025:
            out.append({"name":"Yükselen üçgen","bias":"bullish","confidence":"candidate","level":hmean,
                        "evidence":"Yatay tepe bölgesi ve yükselen dipler"})
    # Falling wedge: both boundaries descend, upper boundary descends faster.
    if len(hi)>=3 and len(lo)>=3:
        htail=hi[-4:]; ltail=lo[-4:]
        hs=[v for _,v in htail]; ls=[v for _,v in ltail]
        if _slope(hs)<0 and _slope(ls)<0 and abs(_slope(hs))>abs(_slope(ls)) and cs[-1].close>ls[-1]:
            out.append({"name":"Düşen kama","bias":"bullish","confidence":"candidate","level":max(hs),
                        "evidence":"Aşağı eğimli ve daralan tepe-dip aralığı"})
    # Bull flag: sharp prior impulse followed by a shallow, lower-volatility pullback.
    closes=[c.close for c in cs]
    if len(cs)>=35:
        impulse=(max(closes[-35:-10])/min(closes[-35:-10])-1)
        flag=closes[-10:]
        flag_slope=_slope(flag)
        if impulse>=0.12 and flag_slope<=0 and (max(flag)-min(flag))/max(flag)<=0.09:
            out.append({"name":"Boğa bayrağı","bias":"bullish","confidence":"candidate","level":max(c.high for c in cs[-10:]),
                        "evidence":"Öncesinde güçlü yükseliş, ardından dar geri çekilme"})
    # Cup/handle is intentionally conservative and labelled candidate only.
    if len(cs)>=100:
        w=cs[-100:]
        left=max(c.high for c in w[:30]); right=max(c.high for c in w[-25:])
        bottom=min(c.low for c in w[30:75])
        rim=(left+right)/2
        symmetry=abs(left-right)/rim if rim else 1
        depth=(rim-bottom)/rim if rim else 0
        handle=(max(c.high for c in w[-12:])-min(c.low for c in w[-12:]))/rim if rim else 1
        if symmetry<0.04 and 0.08<=depth<=0.45 and handle<0.10 and w[-1].close<rim*1.02:
            out.append({"name":"Fincan-kulp","bias":"bullish","confidence":"candidate","level":rim,
                        "evidence":"Yakın yükseklikte iki kenar, yuvarlak taban ve dar kulp bölgesi"})
    # Bearish warning patterns are risk flags, not short recommendations.
    if len(cs)>=20:
        recent=cs[-20:]
        if _slope([c.close for c in recent])<0 and _slope([c.high for c in recent])<0:
            out.append({"name":"Aşağı eğimli yapı","bias":"bearish","confidence":"warning","level":min(c.low for c in recent),
                        "evidence":"Kısa vadeli tepe ve kapanışlar geriliyor"})
    return out
