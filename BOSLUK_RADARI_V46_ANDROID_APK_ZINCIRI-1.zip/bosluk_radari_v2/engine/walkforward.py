"""Chronological walk-forward evaluation helpers."""
from .backtest import evaluate_breakouts, summarize

def chronological_splits(candles, train_fraction=0.60, test_fraction=0.20, step_fraction=0.20):
    """Yield (train, test) slices in time order; no future candle enters training."""
    n=len(candles)
    if not 0 < train_fraction < 1 or not 0 < test_fraction < 1 or not 0 < step_fraction <= 1:
        raise ValueError("fractions must be in (0,1], train/test strictly below 1")
    train_n=max(1,int(n*train_fraction))
    test_n=max(1,int(n*test_fraction))
    step=max(1,int(n*step_fraction))
    start=train_n
    while start < n:
        end=min(n,start+test_n)
        if end-start < 2: break
        yield candles[:start], candles[start:end]
        start += step

def walk_forward_breakouts(candles, lookback=40, horizon=30, target_pct=0.50,
                            stop_pct=0.08, fee_pct=0.001,
                            train_fraction=0.60, test_fraction=0.20, step_fraction=0.20,
                            quality_score_fn=None):
    """Evaluate only each out-of-sample test slice, with warm-up history prepended.

    Training slice supplies indicator/lookback history only; results are retained
    only for signal indices inside the test period.
    """
    reports=[]
    for fold,(train,test) in enumerate(chronological_splits(
            candles,train_fraction,test_fraction,step_fraction),1):
        combined=list(train)+list(test)
        raw=evaluate_breakouts(combined,lookback=lookback,horizon=horizon,
                               target_pct=target_pct,stop_pct=stop_pct,fee_pct=fee_pct)
        offset=len(train)
        # Keep only signals generated inside this fold's test segment.
        # Require the complete forward outcome window to remain inside this
        # fold's OOS test segment. Otherwise later-fold candles leak into outcomes.
        test_end=offset+len(test)
        last_valid_signal=test_end-horizon-1
        selected=[r for r in raw if offset <= r.signal_index <= last_valid_signal]
        quality_groups={}
        if quality_score_fn is not None:
            # The callback receives only candles available at the signal close.
            for trade in selected:
                prefix=combined[:trade.signal_index+1]
                score=quality_score_fn(prefix)
                if score is None:
                    band="UNSCORED"
                else:
                    score=max(0.0,min(100.0,float(score)))
                    band=("80-100" if score>=80 else "55-79" if score>=55
                          else "30-54" if score>=30 else "0-29")
                quality_groups.setdefault(band,[]).append(trade)
        reports.append({"fold":fold,"train_bars":len(train),"test_bars":len(test),
                        "oos_evaluable_signals":len(selected),
                        "excluded_boundary_signals":sum(
                            offset <= r.signal_index < test_end and r.signal_index > last_valid_signal
                            for r in raw),
                        "quality_bands":{band:summarize(rows) for band,rows in quality_groups.items()},
                        **summarize(selected)})
    return reports


def aggregate_walk_forward(reports):
    """Aggregate fold counts without averaging fold percentages equally."""
    signals=sum(int(r.get("signals",0)) for r in reports)
    targets=sum(round((r.get("target_rate_pct") or 0)*r.get("signals",0)/100) for r in reports)
    stops=sum(round((r.get("stop_rate_pct") or 0)*r.get("signals",0)/100) for r in reports)
    unresolved=sum(int(r.get("unresolved",0)) for r in reports)
    return {
        "folds":len(reports),"signals":signals,
        "target_rate_pct":(targets/signals*100) if signals else None,
        "stop_rate_pct":(stops/signals*100) if signals else None,
        "unresolved":unresolved,
        "warning":"Fold percentages are aggregated by signal count; not a profitability guarantee."
    }
