# V39 — Destek/direnç haritası ve tarama güvenilirliği

## Destek ve direnç
- Önceki yalnızca direnç gösteren pivot haritası, üst direnç ve alt destek kümelerini birlikte üretir.
- En yakın destek ve direnç ayrı alanlarda raporlanır.
- Bölgelerde pivot temas sayısı, son temasın kaç mum önce olduğu ve ZAYIF/ORTA/GÜÇLÜ sınıfı bulunur.
- Güç sınıfı yalnızca pivot temas sayısına dayanır; kesin dönüş veya garanti seviyesi değildir.
- Teorik +50/+100/+200 boşluk hesabı ve aradaki direnç engelleri korunmuştur.
- Coin detay ekranı destek/direnç bölgelerini, mesafeyi, temas sayısını ve gücü gösterir; kartlarda ilk destek de görünür.

## BTC piyasa filtresi
- Tarama başında BTCUSDT 1s/4s/1g verisi alınarak piyasa filtresi hesaplanır.
- Veri alınamazsa tarama devam eder ve BTC filtresinin alınamadığı açıkça raporlanır.
- BTC zayıfsa hazırlık sinyali İZLEME'ye indirilir ve kalite puanından 12 puan düşülür.
- Önceki sürümde tarama sonucunun oluşturulmasında tanımlanmamış `btcMarket` değişkeni vardı; artık hesaplanıp kontrollü şekilde kullanılıyor.

## Test
- 30/30 Node testi başarılı.
- JavaScript sözdizimi kontrolleri temiz.
- Canlı Binance ve gerçek Android cihaz testi yapılmadı.
- APK üretilmedi; Android derleme iş akışı ayrıca çalıştırılmalıdır.
