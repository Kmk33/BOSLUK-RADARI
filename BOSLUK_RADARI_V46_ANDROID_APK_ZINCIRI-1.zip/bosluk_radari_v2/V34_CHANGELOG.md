# V34 — Tarama güvenilirliği ve filtre performansı

- Fixed retry button binding: retry actions use delegated click handling, so they continue working after radar list re-rendering.
- Timeframe filters reuse an existing scan when its metadata confirms that timeframe was scanned; no redundant Binance requests in that case.
- Switching to a timeframe not present in the cached scan still starts a scan for that timeframe.
- Failed refreshes no longer erase the last successful in-memory results; stale results remain visible with an explicit connection/update warning.
- Added a regression test for timeframe cache reuse.
- Local JavaScript tests pass; JavaScript syntax checks clean.
- No live Binance or Android device/APK validation performed.
