# V25 changelog

- Live Spot diagnostic now classifies DNS/network failures separately from API/validation failures.
- Diagnostic CLI uses a bounded timeout and zero retries so offline environments fail quickly rather than waiting through production retry policy.
- Report includes `environment_diagnosis`; DNS/network failure explicitly does not claim Binance is globally unavailable.
- Added regression test for DNS/network classification.
- 79/79 deterministic unit tests pass.
- Live test in this execution environment failed because Binance hostnames could not be resolved; no live market scan was completed.
- APK is not built; Android SDK/Gradle are not available in this environment.
