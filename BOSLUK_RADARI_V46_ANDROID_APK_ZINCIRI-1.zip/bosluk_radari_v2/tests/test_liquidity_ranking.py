import unittest
from types import SimpleNamespace
from engine.scanner import liquid_spot_universe, rank_scan_results

class FakeClient:
    def exchange_info(self):
        return {"symbols":[
            {"symbol":"BTCUSDT","status":"TRADING","quoteAsset":"USDT","isSpotTradingAllowed":True},
            {"symbol":"ETHUSDT","status":"TRADING","quoteAsset":"USDT","isSpotTradingAllowed":True},
            {"symbol":"BTCUPUSDT","status":"TRADING","quoteAsset":"USDT","isSpotTradingAllowed":True},
            {"symbol":"OLDUSDT","status":"BREAK","quoteAsset":"USDT","isSpotTradingAllowed":True},
        ]}
    def ticker_24h(self):
        return [
            {"symbol":"BTCUSDT","quoteVolume":"9000000","count":"5000","lastPrice":"90000"},
            {"symbol":"ETHUSDT","quoteVolume":"3000000","count":"3000","lastPrice":"3000"},
            {"symbol":"BTCUPUSDT","quoteVolume":"99000000","count":"9000","lastPrice":"1"},
            {"symbol":"OLDUSDT","quoteVolume":"50000000","count":"9000","lastPrice":"1"},
        ]

class LiquidityRankingTests(unittest.TestCase):
    def test_liquid_universe_filters_non_spot_and_low_volume(self):
        rows=liquid_spot_universe(FakeClient(),min_quote_volume=2_000_000,min_trades=1000,top_n=5)
        self.assertEqual([r["symbol"] for r in rows],["BTCUSDT","ETHUSDT"])
    def test_universe_validates_filters(self):
        with self.assertRaises(ValueError): liquid_spot_universe(FakeClient(),top_n=0)
    def test_rank_excludes_any_downside_risk(self):
        safe=SimpleNamespace(downside_risk=False,breakout=True,score=80)
        risky=SimpleNamespace(downside_risk=True,breakout=True,score=99)
        rows=rank_scan_results([
            {"symbol":"SAFE","timeframes":{"1_saat":safe},"combined":{"score":80,"target_gap_pct":50},"patterns":{}},
            {"symbol":"RISK","timeframes":{"1_saat":risky},"combined":{"score":99,"target_gap_pct":200},"patterns":{}},
        ])
        self.assertEqual([x["symbol"] for x in rows],["SAFE"])
        self.assertEqual(rows[0]["rank"],1)
    def test_wide_gap_does_not_override_risk_gate(self):
        risky=SimpleNamespace(downside_risk=True,breakout=True,score=99)
        self.assertEqual(rank_scan_results([{"symbol":"X","timeframes":{"1_saat":risky},
            "combined":{"score":100,"target_gap_pct":500},"patterns":[]}]),[])

if __name__=="__main__": unittest.main()
