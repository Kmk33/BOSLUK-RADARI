import unittest
from unittest.mock import Mock
from engine.binance import BinanceSpot
from engine.walkforward import chronological_splits

def row(t):
    return [t,"1","2","0.5","1.5","10",t+59999,"15","3","6","9","0"]

class HistoricalTests(unittest.TestCase):
    def test_parse_closed_flag(self):
        got=BinanceSpot._parse_klines([row(1000)],now_ms=70000)
        self.assertTrue(got[0]["closed"])
        self.assertEqual(got[0]["taker_buy_base"],6.0)
    def test_historical_paginates_and_deduplicates(self):
        client=BinanceSpot(sleep=lambda _:None)
        client._get=Mock(side_effect=[[row(1000),row(2000)],[row(2000),row(3000)],[]])
        got=client.historical_klines("btcusdt","1m",1000,3000,limit=2,pause=0)
        self.assertEqual([x["open_time"] for x in got],[1000,2000,3000])
        self.assertEqual(client._get.call_count,2)
    def test_bad_interval_rejected(self):
        with self.assertRaises(ValueError): BinanceSpot().historical_klines("BTCUSDT","2m",0)
    def test_chronological_splits(self):
        data=list(range(100))
        splits=list(chronological_splits(data,.6,.2,.2))
        self.assertEqual(splits[0][0][-1],59)
        self.assertEqual(splits[0][1][0],60)
        self.assertLess(splits[0][0][-1],splits[0][1][0])

if __name__=="__main__": unittest.main()
