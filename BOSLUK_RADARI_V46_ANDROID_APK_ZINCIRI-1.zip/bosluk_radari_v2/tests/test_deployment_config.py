import unittest
from engine.api import validate_deployment_config

class DeploymentConfigTests(unittest.TestCase):
    def test_development_mode_remains_permissive(self):
        self.assertFalse(validate_deployment_config({"RADAR_ENV":"development"})["production"])

    def test_production_requires_long_token(self):
        with self.assertRaisesRegex(ValueError,"32 characters"):
            validate_deployment_config({"RADAR_ENV":"production","RADAR_API_TOKEN":"short",
                "RADAR_ALLOWED_ORIGINS":"https://app.example.com"})

    def test_production_rejects_wildcard_and_http_origins(self):
        base={"RADAR_ENV":"production","RADAR_API_TOKEN":"x"*40}
        for origin in ("*","http://app.example.com"):
            with self.assertRaises(ValueError):
                validate_deployment_config({**base,"RADAR_ALLOWED_ORIGINS":origin})

    def test_production_accepts_explicit_https_origin(self):
        cfg=validate_deployment_config({"RADAR_ENV":"production","RADAR_API_TOKEN":"x"*40,
            "RADAR_ALLOWED_ORIGINS":"https://app.example.com"})
        self.assertTrue(cfg["production"])

if __name__=="__main__": unittest.main()
