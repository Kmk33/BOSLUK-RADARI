import unittest
from engine.analysis import Candle
from engine.retest import detect_breakout_retest


def make_series(with_retest=True):
    rows=[]
    for i in range(70):
        op=92.0
        hi=94.0
        lo=90.0
        cl=92.0
        vol=100.0
        if i==40:
            hi=100.0
            cl=95.0
        if i==60:
            op=100.5; hi=102.0; lo=100.2; cl=101.5; vol=250.0
        if i==61 and with_retest:
            op=100.2; hi=101.5; lo=99.8; cl=100.8; vol=130.0
        rows.append(Candle(i*3600000,op,hi,lo,cl,vol,closed=True))
    return rows


class RetestTests(unittest.TestCase):
    def test_close_breakout_then_bullish_retest_confirms(self):
        result=detect_breakout_retest(make_series())
        self.assertTrue(result["confirmed"])
        self.assertEqual(result["status"],"RETEST_ONAYLI")
        self.assertAlmostEqual(result["level"],100.0)
        self.assertEqual(result["breakout_index"],60)
        self.assertEqual(result["retest_index"],61)

    def test_breakout_without_retest_is_not_confirmed(self):
        result=detect_breakout_retest(make_series(False))
        self.assertFalse(result["confirmed"])

    def test_wick_only_breakout_does_not_confirm(self):
        rows=make_series(False)
        rows[60].close=99.5
        result=detect_breakout_retest(rows)
        self.assertFalse(result["confirmed"])

    def test_unclosed_retest_bar_is_ignored(self):
        rows=make_series()
        rows[61].closed=False
        result=detect_breakout_retest(rows)
        self.assertFalse(result["confirmed"])

    def test_invalid_parameters_rejected(self):
        with self.assertRaises(ValueError):
            detect_breakout_retest(make_series(),tolerance_pct=0)

if __name__=="__main__": unittest.main()
