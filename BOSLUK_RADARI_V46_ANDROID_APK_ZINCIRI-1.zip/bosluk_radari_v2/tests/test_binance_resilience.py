import unittest
from unittest.mock import Mock
from engine.binance import BinanceSpot

class FakeResponse:
    def __init__(self, status=200, payload=None, headers=None):
        self.status_code=status
        self._payload=payload if payload is not None else {}
        self.headers=headers or {}
    def raise_for_status(self):
        if self.status_code >= 400:
            import requests
            raise requests.HTTPError(f"HTTP {self.status_code}", response=self)
    def json(self):
        return self._payload

class BinanceResilienceTests(unittest.TestCase):
    def test_exchange_info_cached_and_copy_isolated(self):
        session=Mock()
        session.get.return_value=FakeResponse(payload={"symbols":[{"symbol":"BTCUSDT"}]})
        client=BinanceSpot(session=session, sleep=lambda _:None)
        first=client.exchange_info()
        first["symbols"].clear()
        second=client.exchange_info()
        self.assertEqual(len(second["symbols"]),1)
        self.assertEqual(session.get.call_count,1)

    def test_ticker_24h_cached(self):
        session=Mock()
        session.get.return_value=FakeResponse(payload=[{"symbol":"BTCUSDT"}])
        client=BinanceSpot(session=session, sleep=lambda _:None)
        client.ticker_24h()
        client.ticker_24h()
        self.assertEqual(session.get.call_count,1)

    def test_transient_server_error_retried(self):
        session=Mock()
        session.get.side_effect=[
            FakeResponse(status=503),
            FakeResponse(payload={"ok":True})
        ]
        client=BinanceSpot(session=session, sleep=lambda _:None, retries=1)
        self.assertEqual(client._get("/test"),{"ok":True})
        self.assertEqual(session.get.call_count,2)

    def test_rate_limit_is_not_retried_or_bypassed(self):
        session=Mock()
        session.get.return_value=FakeResponse(status=429,headers={"Retry-After":"7"})
        client=BinanceSpot(session=session, sleep=lambda _:None, retries=3)
        with self.assertRaisesRegex(RuntimeError,"rate limited"):
            client._get("/test")
        self.assertEqual(session.get.call_count,1)

if __name__=="__main__": unittest.main()
