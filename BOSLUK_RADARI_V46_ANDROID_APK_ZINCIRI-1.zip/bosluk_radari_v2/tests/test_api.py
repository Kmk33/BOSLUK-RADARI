import unittest
import time
import os
import threading
from http.server import ThreadingHTTPServer
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from engine.api import RadarHandler
from unittest.mock import patch
from engine.api import json_safe, build_radar_payload, cached_radar, _cache, start_scan_job, get_scan_job

class ApiTests(unittest.TestCase):
    def test_json_safe_converts_dataclass_and_nonfinite(self):
        from dataclasses import dataclass
        @dataclass
        class Sample:
            value: float
        self.assertEqual(json_safe({"a":Sample(float("nan"))}),{"a":{"value":None}})

    def test_invalid_timeframe_rejected_before_network(self):
        with self.assertRaises(ValueError):
            build_radar_payload(object(),timeframe="2_saat")

    def test_top_n_is_bounded(self):
        with self.assertRaises(ValueError):
            build_radar_payload(object(),timeframe="1_saat",top_n=151)

    def test_payload_has_scope_and_read_only_flag(self):
        fake={"universe_count":3,"scanned_count":3,"errors":[],"candidates":[]}
        with patch("engine.api.scan_liquid_market",return_value=fake):
            payload=build_radar_payload(object(),timeframe="1_saat",top_n=3)
        self.assertEqual(payload["market_scope"],"BINANCE_SPOT_USDT")
        self.assertFalse(payload["orders_enabled"])
        self.assertEqual(payload["timeframe_filter"],"1_saat")
        self.assertIn("generated_at_utc",payload)


    def test_scan_job_runs_in_background_and_returns_result(self):
        fake={"universe_count":2,"scanned_count":2,"errors":[],"candidates":[],
              "timeframe_filter":"1_saat","market_scope":"BINANCE_SPOT_USDT",
              "orders_enabled":False}
        with patch("engine.api.build_radar_payload",return_value=fake):
            started=start_scan_job(object(),timeframe="1_saat",top_n=2)
            self.assertEqual(started["status"],"queued")
            result=None
            for _ in range(100):
                result=get_scan_job(started["job_id"])
                if result and result["status"] in ("completed","failed"):
                    break
                time.sleep(0.01)
        self.assertIsNotNone(result)
        self.assertEqual(result["status"],"completed")
        self.assertEqual(result["result"]["universe_count"],2)

    def test_start_job_rejects_bad_timeframe(self):
        with self.assertRaises(ValueError):
            start_scan_job(object(),timeframe="bad")


    def test_http_token_protects_scan_endpoints_but_not_health(self):
        old=os.environ.get("RADAR_API_TOKEN")
        os.environ["RADAR_API_TOKEN"]="test-secret"
        server=ThreadingHTTPServer(("127.0.0.1",0),RadarHandler)
        server.binance_client=object()
        thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
        base=f"http://127.0.0.1:{server.server_port}"
        try:
            with urlopen(base+"/health") as response:
                self.assertEqual(response.status,200)
            with self.assertRaises(HTTPError) as err:
                urlopen(base+"/api/radar?timeframe=1_saat")
            self.assertEqual(err.exception.code,401)
            req=Request(base+"/api/radar?timeframe=1_saat",headers={"X-API-Token":"test-secret"})
            try:
                urlopen(req)
            except HTTPError as err:
                self.assertEqual(err.code,503) # Auth passed; dummy client fails on market fetch.
        finally:
            server.shutdown(); server.server_close()
            if old is None: os.environ.pop("RADAR_API_TOKEN",None)
            else: os.environ["RADAR_API_TOKEN"]=old

    def test_cors_is_not_wildcard(self):
        old=os.environ.get("RADAR_ALLOWED_ORIGINS")
        os.environ["RADAR_ALLOWED_ORIGINS"]="https://localhost"
        server=ThreadingHTTPServer(("127.0.0.1",0),RadarHandler)
        server.binance_client=object()
        thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
        base=f"http://127.0.0.1:{server.server_port}"
        try:
            req=Request(base+"/health",headers={"Origin":"https://evil.example"})
            with urlopen(req) as response:
                self.assertIsNone(response.headers.get("Access-Control-Allow-Origin"))
            req=Request(base+"/health",headers={"Origin":"https://localhost"})
            with urlopen(req) as response:
                self.assertEqual(response.headers.get("Access-Control-Allow-Origin"),"https://localhost")
        finally:
            server.shutdown(); server.server_close()
            if old is None: os.environ.pop("RADAR_ALLOWED_ORIGINS",None)
            else: os.environ["RADAR_ALLOWED_ORIGINS"]=old

    def test_cache_serves_recent_payload(self):
        _cache.clear()
        fake={"universe_count":1,"scanned_count":1,"errors":[],"candidates":[]}
        with patch("engine.api.scan_liquid_market",return_value=fake) as scan:
            first=cached_radar(object(),"1_saat",1,0,0)
            second=cached_radar(object(),"1_saat",1,0,0)
        self.assertFalse(first["cache_hit"])
        self.assertTrue(second["cache_hit"])
        self.assertEqual(scan.call_count,1)

if __name__=="__main__": unittest.main()
