import unittest
from engine.analysis import Candle
from engine.backtest import evaluate_breakouts, summarize

class TestBacktest(unittest.TestCase):
    def fixture(self, future_high=170, future_low=99):
        cs=[]
        # 50 calm candles establish prior range and volume baseline.
        for i in range(50):
            cs.append(Candle(i,99,100,98,99,100,10000,50,True))
        # closed breakout bar above the prior 40-bar high with RVOL 3
        cs.append(Candle(50,100,105,99,104,300,30000,200,True))
        # future path; test target/stop logic
        for j in range(1,8):
            hi=future_high if j==3 else 110
            lo=future_low if j==3 else 103
            cs.append(Candle(50+j,104,hi,lo,106,150,15000,80,True))
        cs += [Candle(100+j,106,107,105,106,100,10000,50,True) for j in range(25)]
        return cs
    def test_target_hit(self):
        r=evaluate_breakouts(self.fixture(future_high=170,future_low=103),lookback=40,horizon=5,target_pct=.5,stop_pct=.08)
        self.assertTrue(r)
        self.assertEqual(r[0].outcome,"TARGET")
    def test_stop_first_when_both_hit_same_bar(self):
        r=evaluate_breakouts(self.fixture(future_high=170,future_low=90),lookback=40,horizon=5,target_pct=.5,stop_pct=.08)
        self.assertEqual(r[0].outcome,"STOP_FIRST_SAME_BAR")
    def test_no_future_bars_no_result(self):
        self.assertEqual(evaluate_breakouts(self.fixture()[:51],lookback=40,horizon=30),[])
    def test_summary_empty(self):
        self.assertEqual(summarize([])["signals"],0)
if __name__=="__main__": unittest.main()
