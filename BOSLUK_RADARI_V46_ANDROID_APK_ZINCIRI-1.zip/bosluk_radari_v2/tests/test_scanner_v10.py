import unittest
from types import SimpleNamespace
from unittest.mock import patch
from engine.scanner import scan_symbol_timeframes

class MultiTimeframeScannerTests(unittest.TestCase):
    def test_reference_price_prefers_fresh_hourly_and_keeps_profiles(self):
        rows = {
            "1_saat": SimpleNamespace(price=100.0, resistance=120.0, breakout=False, downside_risk=False, ema20=101.0, ema50=100.0, score=50, upside_pct=20.0),
            "1_ay": SimpleNamespace(price=80.0, resistance=150.0, breakout=False, downside_risk=False, ema20=101.0, ema50=100.0, score=50, upside_pct=20.0),
        }
        def fake_scan(client, symbol, tf):
            return {"analysis": rows[tf], "patterns": [],
                    "volume_profile": {"poc": 99 if tf == "1_saat" else 81},
                    "overhead_supply": {"valid": True, "zones": []}}
        with patch("engine.scanner.scan_one", side_effect=fake_scan):
            result = scan_symbol_timeframes(object(), "TESTUSDT", ["1_saat", "1_ay"])
        self.assertEqual(result["combined"]["reference_price"], 100.0)
        self.assertEqual(result["volume_profiles"]["1_saat"]["poc"], 99)
        self.assertEqual(result["overhead_supply"]["1_ay"]["valid"], True)
        self.assertEqual(result["combined"]["signal_state"], "İZLEME")
        self.assertEqual(result["combined"]["targets"][0]["resistance"], 120.0)

    def test_downside_risk_overrides_bullish_pattern_state(self):
        risky = SimpleNamespace(price=1.0, resistance=2.0, breakout=False, downside_risk=True, ema20=1.1, ema50=1.0, score=50, upside_pct=20.0)
        def fake_scan(client, symbol, tf):
            return {"analysis": risky, "patterns": [{"bias": "bullish"}],
                    "volume_profile": {}, "overhead_supply": {}}
        with patch("engine.scanner.scan_one", side_effect=fake_scan):
            result = scan_symbol_timeframes(object(), "TESTUSDT", ["1_saat"])
        self.assertEqual(result["combined"]["signal_state"], "RİSK / GEÇERSİZ")

if __name__ == "__main__":
    unittest.main()
