import unittest
from engine.analysis import Candle
from engine.walkforward import walk_forward_breakouts

class WalkForwardBoundaryTests(unittest.TestCase):
    def test_outcomes_never_cross_test_fold_boundary(self):
        # Construct deterministic rising-volume breakout opportunities throughout.
        candles=[]
        price=100.0
        for i in range(180):
            if i % 9 == 0:
                price *= 1.025
            else:
                price *= 1.001
            candles.append(Candle(i,price*.995,price*1.01,price*.99,price,
                                  1000 if i%9==0 else 100,closed=True))
        reports=walk_forward_breakouts(candles,lookback=5,horizon=8,
            target_pct=.02,stop_pct=.5,fee_pct=0,
            train_fraction=.5,test_fraction=.25,step_fraction=.25)
        for report in reports:
            self.assertEqual(report["signals"],report["oos_evaluable_signals"])
            self.assertGreaterEqual(report["excluded_boundary_signals"],0)
            self.assertLessEqual(report["signals"],max(0,report["test_bars"]-8-1))

if __name__=="__main__": unittest.main()
