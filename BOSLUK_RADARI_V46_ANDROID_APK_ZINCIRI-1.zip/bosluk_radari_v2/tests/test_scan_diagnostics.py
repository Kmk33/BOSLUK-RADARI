import unittest
from unittest.mock import patch
from engine import scanner

class ScanDiagnosticsTests(unittest.TestCase):
    @patch("engine.scanner.scan_symbol_timeframes")
    @patch("engine.scanner.liquid_spot_universe")
    def test_timing_and_request_estimate_reported(self, universe, scan_symbol):
        universe.return_value=[
            {"symbol":"AAAUSDT","quote_volume_24h":2e6,"trades_24h":900,"last_price":1},
            {"symbol":"BBBUSDT","quote_volume_24h":1e6,"trades_24h":700,"last_price":2},
        ]
        scan_symbol.side_effect=[
            {"symbol":"AAAUSDT","timeframes":{},"combined":{},"patterns":{}},
            RuntimeError("temporary data error")
        ]
        progress=[]
        result=scanner.scan_liquid_market(
            object(),top_n=2,timeframes=["1_saat","4_saat"],
            progress_callback=progress.append)
        d=result["diagnostics"]
        self.assertEqual(result["scanned_count"],1)
        self.assertEqual(len(result["errors"]),1)
        self.assertEqual(result["errors"][0]["error_type"],"RuntimeError")
        self.assertEqual(d["estimated_klines_requests"],4)
        self.assertEqual(d["successful_symbols"],1)
        self.assertEqual(d["failed_symbols"],1)
        self.assertEqual(progress[-1]["completed"],2)
        self.assertIn("estimated_remaining_seconds",progress[-1])

    @patch("engine.scanner.liquid_spot_universe")
    def test_empty_universe_has_zero_average(self, universe):
        universe.return_value=[]
        result=scanner.scan_liquid_market(object(),timeframes=["1_saat"])
        self.assertEqual(result["diagnostics"]["average_seconds_per_symbol"],0)
        self.assertEqual(result["diagnostics"]["estimated_klines_requests"],0)

if __name__=="__main__": unittest.main()
