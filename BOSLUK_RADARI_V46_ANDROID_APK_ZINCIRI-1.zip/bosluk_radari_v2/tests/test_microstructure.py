import unittest
from engine.microstructure import analyze_order_book, analyze_aggressor_flow
from engine.binance import BinanceSpot
from unittest.mock import Mock

class MicrostructureTests(unittest.TestCase):
    def test_order_book_spread_and_imbalance(self):
        book={"bids":[["99","10"],["98.9","5"]],"asks":[["101","5"],["101.1","5"]]}
        x=analyze_order_book(book,depth_levels=2,band_bps=300)
        self.assertTrue(x["valid"])
        self.assertGreater(x["spread_pct"],0)
        self.assertGreater(x["book_imbalance"],0)
    def test_crossed_book_rejected(self):
        self.assertFalse(analyze_order_book({"bids":[["101","1"]],"asks":[["100","1"]]})["valid"])
    def test_empty_book_rejected(self):
        self.assertFalse(analyze_order_book({"bids":[],"asks":[]})["valid"])
    def test_aggressor_flow_respects_m_flag(self):
        trades=[{"p":"10","q":"2","m":False},{"p":"10","q":"1","m":True}]
        x=analyze_aggressor_flow(trades)
        self.assertEqual(x["taker_buy_base"],2)
        self.assertEqual(x["taker_sell_base"],1)
        self.assertAlmostEqual(x["taker_buy_share"],2/3)
    def test_agg_trades_validation_and_params(self):
        c=BinanceSpot(); c._get=Mock(return_value=[])
        c.agg_trades("btcusdt",limit=10,start_time=1,end_time=2)
        self.assertEqual(c._get.call_args.args[0],"/api/v3/aggTrades")
        self.assertEqual(c._get.call_args.args[1],{"symbol":"BTCUSDT","limit":10,"startTime":1,"endTime":2})
        with self.assertRaises(ValueError): c.agg_trades("BTCUSDT",start_time=3,end_time=2)

if __name__=="__main__": unittest.main()
