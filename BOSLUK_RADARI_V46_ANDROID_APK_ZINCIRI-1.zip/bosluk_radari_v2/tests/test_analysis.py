import unittest, math
from engine.analysis import Candle, ema, rsi, analyze

def series(n=260, base=100):
    out=[]
    for i in range(n):
        c=base+i*0.05
        out.append(Candle(i*3600000,c-0.02,c+0.1,c-0.1,c,1000,100000,600,True))
    return out

class TestIndicators(unittest.TestCase):
    def test_ema_seed_and_length(self):
        x=ema([1,2,3,4,5],3)
        self.assertTrue(math.isnan(x[0])); self.assertEqual(x[2],2.0); self.assertEqual(len(x),5)
    def test_rsi_rising(self):
        self.assertEqual(rsi(list(range(1,30))),100.0)
    def test_short_history_rejected(self):
        self.assertIsNone(analyze("ABCUSDT","4s",series(100)))
    def test_analysis_returns_closed_data(self):
        cs=series()
        cs.append(Candle(999,113,200,112,190,999999,99999999,999999,False))
        a=analyze("ABCUSDT","4s",cs)
        self.assertIsNotNone(a)
        self.assertLess(a.price,120)
    def test_support_is_below_current_price(self):
        a=analyze("ABCUSDT","4s",series())
        self.assertIsNotNone(a)
        self.assertTrue(a.support is None or a.support < a.price)
    def test_downside_gate(self):
        cs=series()
        # Strong bearish tail; still closed.
        for i in range(70):
            p=113-i*1.5
            cs.append(Candle(999+i,p+1,p+1,p-1,p,2000,200000,200,True))
        a=analyze("ABCUSDT","4s",cs)
        self.assertIsNotNone(a)
        self.assertTrue(a.downside_risk)
        self.assertEqual(a.score,0)
if __name__=="__main__": unittest.main()
