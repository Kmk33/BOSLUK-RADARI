import unittest
from unittest.mock import Mock, patch
from tools.live_spot_check import run_check

class LiveSpotCheckTests(unittest.TestCase):
    def test_smoke_report_passes_with_mocked_spot_data(self):
        client=Mock()
        client.exchange_info.return_value={"symbols":[{"symbol":"AAAUSDT"}]}
        client.ticker_24h.return_value=[{"symbol":"AAAUSDT"}]
        fake_universe=[{"symbol":"AAAUSDT","quote_volume_24h":2_000_000,
                        "trades_24h":1000,"last_price":1.0}]
        fake_scan={"universe_count":1,"scanned_count":1,"errors":[],
                   "candidates":[],"diagnostics":{"total_seconds":0.1}}
        with patch("tools.live_spot_check.liquid_spot_universe",return_value=fake_universe), patch("tools.live_spot_check.scan_liquid_market",return_value=fake_scan):
            report=run_check(client,scan_top_n=1)
        self.assertTrue(report["ok"])
        self.assertTrue(report["checks"]["exchange_info"]["ok"])
        self.assertTrue(report["checks"]["ticker_24h"]["ok"])
        self.assertTrue(report["checks"]["sample_1h_scan"]["ok"])
        self.assertEqual(report["sample_scan"]["scanned_count"],1)

    def test_scan_skipped_when_no_eligible_symbols(self):
        client=Mock()
        client.exchange_info.return_value={"symbols":[]}
        client.ticker_24h.return_value=[]
        with patch("tools.live_spot_check.liquid_spot_universe",return_value=[]):
            report=run_check(client,scan_top_n=1)
        self.assertFalse(report["ok"])
        self.assertTrue(report["checks"]["sample_1h_scan"]["skipped"])

    def test_failed_ticker_is_reported_not_hidden(self):
        client=Mock()
        client.exchange_info.return_value={"symbols":[]}
        client.ticker_24h.side_effect=RuntimeError("offline")
        with patch("tools.live_spot_check.liquid_spot_universe",return_value=[]):
            report=run_check(client,scan_top_n=1)
        self.assertFalse(report["checks"]["ticker_24h"]["ok"])
        self.assertEqual(report["checks"]["ticker_24h"]["error"],"offline")
        self.assertEqual(report["checks"]["ticker_24h"]["failure_class"],"API_OR_VALIDATION_ERROR")
        self.assertEqual(report["environment_diagnosis"],"API_CHECK_FAILED")

    def test_dns_failure_is_classified_as_environment_network_issue(self):
        client=Mock()
        client.exchange_info.side_effect=RuntimeError("NameResolutionError: Failed to resolve host")
        client.ticker_24h.side_effect=RuntimeError("NameResolutionError: Failed to resolve host")
        client.liquid_spot_universe.side_effect=RuntimeError("offline")
        with patch("tools.live_spot_check.liquid_spot_universe",side_effect=RuntimeError("Failed to resolve host")):
            report=run_check(client,scan_top_n=1)
        self.assertEqual(report["environment_diagnosis"],"NETWORK_UNAVAILABLE_OR_DNS_BLOCKED")
        self.assertEqual(report["checks"]["exchange_info"]["failure_class"],"DNS_OR_NETWORK_BLOCK")

if __name__=="__main__": unittest.main()
