import unittest
from engine.analysis import Candle
from engine.setup_quality import historical_prefix_quality

class HistoricalQualityTests(unittest.TestCase):
    def test_quality_is_rebuilt_from_prefix_only(self):
        candles=[]
        price=100.0
        for i in range(260):
            price *= 1.001
            candles.append(Candle(i,price*.999,price*1.005,price*.995,price,
                                  100+i%7,closed=True))
        first=historical_prefix_quality(candles[:240],timeframe="1h")
        extended=historical_prefix_quality(candles[:240]+candles[240:],timeframe="1h")
        self.assertEqual(first["score"],historical_prefix_quality(candles[:240],timeframe="1h")["score"])
        self.assertIn("score",first)
        self.assertGreaterEqual(first["score"],0)
        self.assertLessEqual(first["score"],100)
        self.assertNotIn("VERİ YETERSİZ",first["grade"])

    def test_insufficient_history_is_not_scored_as_setup(self):
        result=historical_prefix_quality([Candle(i,1,1.1,.9,1,10) for i in range(100)])
        self.assertEqual(result["grade"],"VERİ YETERSİZ")
        self.assertFalse(result["qualified"])

if __name__=="__main__": unittest.main()
