import unittest
from engine.analysis import Candle
from engine.walkforward import walk_forward_breakouts

class QualityBandTests(unittest.TestCase):
    def test_callback_sees_only_signal_prefix_and_bands_are_reported(self):
        candles=[]
        price=100.0
        for i in range(240):
            price *= 1.02 if i % 11 == 0 else 1.001
            candles.append(Candle(i,price*.995,price*1.01,price*.99,price,
                1000 if i%11==0 else 100,closed=True))
        seen=[]
        def causal_score(prefix):
            seen.append(prefix[-1].open_time)
            self.assertEqual(prefix[-1].open_time, len(prefix)-1)
            return 85 if len(prefix)%2 else 60
        reports=walk_forward_breakouts(candles,lookback=5,horizon=6,
            target_pct=.02,stop_pct=.5,fee_pct=0,
            train_fraction=.5,test_fraction=.25,step_fraction=.25,
            quality_score_fn=causal_score)
        self.assertTrue(seen)
        for report in reports:
            bands=report["quality_bands"]
            self.assertTrue(set(bands).issubset({"80-100","55-79","30-54","0-29","UNSCORED"}))
            self.assertEqual(sum(x["signals"] for x in bands.values()),report["signals"])

if __name__=="__main__": unittest.main()
