import unittest
from types import SimpleNamespace
from engine.setup_quality import score_setup_quality


def analysis(tf="1_saat", risk=False, breakout=False, trend=False, rvol=1.0, buy=0.5):
    return SimpleNamespace(
        timeframe=tf, downside_risk=risk, breakout=breakout,
        price=110 if trend else 90, ema20=105, ema50=100,
        ema90=95, ema200=90, rvol=rvol, buy_pressure=buy
    )

class SetupQualityTests(unittest.TestCase):
    def test_correlated_ema_signals_are_one_bucket(self):
        a=analysis(trend=True)
        result=score_setup_quality({"1_saat":a,"4_saat":a,"1_gun":a})
        self.assertEqual(result["evidence_buckets"]["trend_alignment"],25.0)
        self.assertLessEqual(result["score"],100)

    def test_volume_indicators_do_not_stack(self):
        a=analysis(rvol=2.0,buy=0.7)
        result=score_setup_quality({"1_saat":a})
        self.assertEqual(result["evidence_buckets"]["volume_confirmation"],20.0)

    def test_downside_risk_blocks_qualification(self):
        a=analysis(risk=True,breakout=True,trend=True,rvol=2,buy=.7)
        result=score_setup_quality({"1_saat":a},
            {"1_saat":[{"bias":"bullish"}]},
            {"1_saat":{"confirmed":True}})
        self.assertTrue(result["risk_blocked"])
        self.assertFalse(result["qualified"])
        self.assertEqual(result["grade"],"RİSK NEDENİYLE ELENDİ")

    def test_confirmed_retest_is_separate_evidence(self):
        a=analysis(breakout=True,trend=True,rvol=2,buy=.7)
        result=score_setup_quality({"1_saat":a},{},
            {"1_saat":{"confirmed":True}})
        self.assertEqual(result["evidence_buckets"]["confirmed_retest"],20.0)

    def test_no_data_is_not_qualified(self):
        result=score_setup_quality({})
        self.assertFalse(result["qualified"])
        self.assertEqual(result["grade"],"VERİ YETERSİZ")

if __name__=="__main__": unittest.main()
