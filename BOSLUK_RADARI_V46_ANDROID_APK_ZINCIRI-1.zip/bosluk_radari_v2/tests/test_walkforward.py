import unittest
from engine.walkforward import aggregate_walk_forward

class AggregateTests(unittest.TestCase):
    def test_weighted_aggregation(self):
        rows=[
            {"signals":10,"target_rate_pct":50,"stop_rate_pct":30,"unresolved":2},
            {"signals":30,"target_rate_pct":20,"stop_rate_pct":60,"unresolved":3},
        ]
        result=aggregate_walk_forward(rows)
        self.assertEqual(result["signals"],40)
        self.assertAlmostEqual(result["target_rate_pct"],27.5)
        self.assertAlmostEqual(result["stop_rate_pct"],52.5)
        self.assertEqual(result["unresolved"],5)
    def test_empty_aggregation(self):
        result=aggregate_walk_forward([])
        self.assertEqual(result["signals"],0)
        self.assertIsNone(result["target_rate_pct"])

if __name__=="__main__": unittest.main()
