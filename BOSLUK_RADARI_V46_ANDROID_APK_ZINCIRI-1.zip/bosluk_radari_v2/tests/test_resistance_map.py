import unittest
from engine.resistance_map import build_resistance_map

class ResistanceMapTests(unittest.TestCase):
    def test_first_obstacle_blocks_far_milestones(self):
        result=build_resistance_map(1.0,[1.2,1.205,2.0],None)
        self.assertIsNotNone(result["first_obstacle"])
        self.assertAlmostEqual(result["gap_to_first_obstacle_pct"],20.0)
        self.assertFalse(result["theoretical_milestones"][0]["reachable_without_known_obstacle"])
        self.assertEqual(result["first_obstacle"]["sources"],["PIVOT_CLUSTER"])

    def test_supply_zones_are_included_and_merged(self):
        supply={"valid":True,"zones":[
            {"low":1.4,"high":1.5,"volume_share_pct":3.0},
            {"low":1.48,"high":1.6,"volume_share_pct":4.0}]}
        result=build_resistance_map(1.0,[1.45],supply)
        self.assertEqual(len(result["obstacles"]),1)
        self.assertAlmostEqual(result["obstacles"][0]["high"],1.6)
        self.assertIn("OHLCV_APPROX_SUPPLY",result["obstacles"][0]["sources"])

    def test_no_obstacle_reports_theoretical_distance(self):
        result=build_resistance_map(1.0,[],None)
        self.assertIsNone(result["gap_to_first_obstacle_pct"])
        self.assertTrue(all(x["reachable_without_known_obstacle"] for x in result["theoretical_milestones"]))

    def test_below_price_levels_are_ignored(self):
        result=build_resistance_map(1.0,[0.8,0.9,1.1],None)
        self.assertEqual(len(result["obstacles"]),1)

    def test_invalid_price_rejected(self):
        with self.assertRaises(ValueError):
            build_resistance_map(0,[1],None)

if __name__=="__main__": unittest.main()
