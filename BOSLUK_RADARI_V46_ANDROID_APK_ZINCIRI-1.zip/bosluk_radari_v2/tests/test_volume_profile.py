import unittest
from engine.analysis import Candle
from engine.volume_profile import build_volume_profile, overhead_supply_zones

class VolumeProfileTests(unittest.TestCase):
    def candles(self):
        out=[]
        # Repeated high-volume trading area above current price.
        for i in range(80):
            if i<40:
                lo,hi,vol=90,95,100
            else:
                lo,hi,vol=110,115,500
            out.append(Candle(i,lo,hi,lo,hi,vol,vol*hi,vol/2,True))
        return out
    def test_profile_valid_and_volume_conserved(self):
        cs=self.candles()
        p=build_volume_profile(cs,bins=50)
        self.assertTrue(p["valid"])
        self.assertAlmostEqual(p["total_volume"],sum(c.volume for c in cs))
        self.assertGreaterEqual(p["poc"]["mid"],110)
    def test_overhead_supply_above_price(self):
        x=overhead_supply_zones(self.candles(),100,bins=50,min_volume_share_pct=.5)
        self.assertTrue(x["valid"])
        self.assertTrue(x["zones"])
        self.assertTrue(all(z["low"]>=100 and z["distance_pct"]>=0 for z in x["zones"]))
    def test_invalid_range(self):
        cs=[Candle(i,10,10,10,10,0,0,0,True) for i in range(10)]
        self.assertFalse(build_volume_profile(cs,bins=10)["valid"])
    def test_open_candles_excluded(self):
        cs=self.candles()
        cs.append(Candle(999,100,10000,1,5000,1e9,1e9,1e9,False))
        p=build_volume_profile(cs,bins=50)
        self.assertEqual(p["lookback_bars"],80)

if __name__=="__main__": unittest.main()
