import unittest
from types import SimpleNamespace
from engine.analysis import Candle
from engine.patterns import detect_patterns
from engine.multitimeframe import target_ladder, combine_timeframes

class TestPatternAndTargets(unittest.TestCase):
    def test_short_pattern_history_is_empty(self):
        self.assertEqual(detect_patterns([]), [])
    def test_target_ladder_filters_below_price_and_sorts(self):
        got=target_ladder(1.0,[0.9,2.0,1.5,3.0,2.0])
        self.assertEqual([x["resistance"] for x in got],[1.5,2.0,3.0])
        self.assertAlmostEqual(got[1]["upside_pct"],100.0)
    def test_no_timeframes(self):
        self.assertEqual(combine_timeframes({})["bias"],"VERİ YETERSİZ")
    def test_risk_dominates_confluence(self):
        obj=SimpleNamespace(breakout=True,downside_risk=True,score=90,ema20=2,ema50=1,price=3,upside_pct=80)
        result=combine_timeframes({"4s":obj,"1g":obj})
        self.assertEqual(result["bias"],"RİSKLİ")
    def test_bearish_pattern_not_bullish(self):
        cs=[]
        for i in range(70):
            close=100-i*0.3
            cs.append(Candle(i,close+0.1,close+0.3,close-0.3,close,100,10000,40,True))
        patterns=detect_patterns(cs)
        self.assertTrue(any(p["bias"]=="bearish" for p in patterns))
if __name__=="__main__": unittest.main()
