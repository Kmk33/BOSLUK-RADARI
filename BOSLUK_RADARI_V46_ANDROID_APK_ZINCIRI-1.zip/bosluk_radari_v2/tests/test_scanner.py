import unittest
from types import SimpleNamespace
from engine.multitimeframe import combine_timeframes
from engine.scanner import resolve_interval, TIMEFRAMES, scan_one

class FakeClient:
    def __init__(self): self.calls=[]
    def klines(self,symbol,interval,limit):
        self.calls.append((symbol,interval,limit))
        return []

class ScannerTests(unittest.TestCase):
    def test_canonical_timeframes_are_unambiguous(self):
        self.assertEqual(TIMEFRAMES["1_saat"],"1h")
        self.assertEqual(TIMEFRAMES["1_hafta"],"1w")
        self.assertEqual(resolve_interval("1_ay"),"1M")
    def test_legacy_aliases_preserved(self):
        self.assertEqual(resolve_interval("1h"),"1w")
        self.assertEqual(resolve_interval("1s"),"1h")
    def test_invalid_timeframe_rejected(self):
        with self.assertRaises(ValueError): resolve_interval("2m")
    def test_canonical_timeframes_combine_without_empty_order(self):
        a=SimpleNamespace(breakout=True,ema20=12,ema50=11,price=13,downside_risk=False,score=80,upside_pct=60)
        result=combine_timeframes({"1_saat":a,"4_saat":a,"1_gun":a})
        self.assertEqual(result["confluence"],3)
        self.assertEqual(result["bias"],"ÇOKLU ZAMAN DİLİMİ KIRILIMI")
    def test_scan_uses_resolved_interval(self):
        c=FakeClient()
        result=scan_one(c,"BTCUSDT","1_saat")
        self.assertEqual(c.calls,[("BTCUSDT","1h",500)])
        self.assertIsNone(result["analysis"])

if __name__=="__main__": unittest.main()
