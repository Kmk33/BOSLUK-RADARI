# BOŞLUK RADARI - Değişiklik Günlüğü\n
## V42 — Kırılım sonrası devam kalitesi
- Geçmişte kapanış + hacim şartıyla oluşan kırılımların sonraki 12 kapanmış mumdaki MFE/MAE ve geri çekilme oranı hesaplanır.
- +1%, +2%, +5% hedef görülme oranları ve hedef/başarısız/çözümsüz olay sayıları raporlanır.
- Direnç seviyesi yalnızca sinyal mumundan önceki mumlardan hesaplanır; sonuç penceresi sinyalden sonraki mumlarda başlar.
- Aynı mumda stop ve hedef görülürse iyimser varsayım yapılmaz; STOP_FIRST olarak işaretlenir.
- Gidiş-dönüş komisyon ve kayma varsayımı net MFE'ye yansıtılır. Varsayılanlar %0,1 komisyon ve %0,05 kaymadır (tek yön).
- Bu tarihsel rapor canlı sinyal üretmez; örnek sayısı azsa oranlar istatistiksel olarak zayıftır.

## V43 — Formasyonların geçmiş başarı karşılaştırması
- Formasyon geçmiş testine net sonuç, MFE ve MAE ölçümleri eklendi.
- Her zaman diliminde formasyon bazında olay sayısı, hedefe ulaşma oranı ve ortalama net sonuç gösterilir.
- Tarayıcı her sembol/zaman dilimi için geçmiş formasyon raporunu üretir; detay ekranında en iyi ortalama net sonuca göre ilk altı formasyon listelenir.
- Varsayılan tarihsel test: sonraki 20 kapanmış mum, +%5 hedef, -%3 stop ve gidiş-dönüş komisyon varsayımı.
- Sinyal yalnızca o tarihe kadarki kapanmış mumlardan bulunur; sonuç sinyalden sonraki mumlarda ölçülür. Bu rapor tahmin değildir.

## V44 — BTC piyasa rejimine göre formasyon analizi
- Geçmiş formasyon olayları BTC'nin aynı zaman dilimindeki tarihsel rejimiyle eşleştirilir: BULL, BEAR, SIDEWAYS veya UNKNOWN.
- Rejim, her sinyal tarihinde yalnızca o tarihe kadar kapanmış BTC mumları kullanılarak hesaplanır; EMA50/EMA200 ve 20 mumluk yön birlikte değerlendirilir.
- BTC geçmişi 200 kapanmış mumdan azsa UNKNOWN atanır; veri eksikliği yükseliş/düşüş gibi yorumlanmaz.
- Detay ekranında her rejimde en çok üç formasyonun olay sayısı, hedef oranı ve ortalama net sonucu ayrı gösterilir.
- BTC 1h, 4h, 1d, 1w ve 1M geçmiş mumları tarama sırasında alınır; emir veya işlem açılmaz.

## V45 — Tarama güvenilirliği ve performans teşhisi
- Binance mum yanıtları OHLC tutarlılığı, sayısal alanlar, zaman sıralaması ve tekrar eden mumlar açısından doğrulanır.
- Bozuk/tekrarlı mumlar temizlenir; geçerli veri yetersizse sahte analiz üretilmez.
- BTC geçmişi yalnızca seçilen zaman dilimleri ve BTC piyasa filtresi için gereken 1h/4h/1d dilimlerinde indirilir; gereksiz tekrar azaltılır.
- Tarama hataları RATE_LIMIT, TIMEOUT, NETWORK, HTTP, DATA_QUALITY ve diğer kategorilerde sınıflandırılır.
- Tarama özeti başarılı, hatalı ve yetersiz geçmişli işleri; süreyi ve hata türlerini gösterir.
- Ekranda tarama teşhis özeti görünür; kısmi hata ve BTC veri eksikliği saklanmaz.
- Tarama işçisi sayısı telefon performansı ve API yükü için 2 olarak korunmuştur; arka planda sürekli tarama eklenmemiştir.
