# BOŞLUK RADARI — Read-only API V0.12

## Başlatma
Python 3.10+ ve `requirements.txt` bağımlılıkları kurulu olmalı.

```bash
pip install -r requirements.txt
python tools/run_api.py
```

Varsayılan adres: `http://127.0.0.1:8765`

Telefonun aynı yerel ağdan geliştirme bilgisayarına erişmesi gerekiyorsa:
```bash
RADAR_HOST=0.0.0.0 RADAR_PORT=8765 python tools/run_api.py
```
Bu ayar yalnızca geliştirme ağı içindir. Genel internete güvenlik katmanı olmadan açmayın.

## Uç noktalar
- `GET /health` — servis sağlık bilgisi.
- `GET /api/radar?timeframe=all` — beş zaman diliminde tarama.
- Tek zaman dilimi örneği: `GET /api/radar?timeframe=1_saat`
- İsteğe bağlı `top_n` (1–150), `min_quote_volume`, `min_trades` parametreleri.
- Varsayılan tarama evreni en likit 30 USDT Spot sembolüdür; `RADAR_TOP_N` ile ayarlanır.
- Sonuçlar aynı parametrelerle 30 saniye bellekte tutulur.

## Sınırlamalar
- Tarama senkron çalışır; 30 sembol × 5 zaman dilimi çok sayıda Binance isteği oluşturabilir ve ilk yanıt uzun sürebilir.
- Binance rate limit / ağ hatasında API `503` döndürür; sahte boş aday listesi üretmez.
- Şu an kimlik doğrulama yoktur. Yalnızca güvenilir yerel geliştirme ortamında kullanın.
- Bu API, Android uygulamasıyla aynı cihazda otomatik çalışacak şekilde paketlenmiş değildir. Mobil cihazın API'ye erişeceği dağıtım/topoloji ayrıca kurulmalıdır.
- Canlı Binance ağ doğrulaması bu geliştirme oturumunda yapılmamıştır.
- Sadece public Spot market-data çağrıları vardır; emir, hesap veya para çekme endpoint'i yoktur.


## Arka plan taraması (V13)
Mobil UI uzun tarama isteğini artık `POST /api/scan/start` ile kuyruğa alır; yanıt bir `job_id` verir. Durum ve ilerleme `GET /api/scan/status/{job_id}` ile sorgulanır. Tarama tamamlanınca aynı yanıt içinde gerçek `result` nesnesi döner.
- İki eşzamanlı tarama işi sınırı vardır.
- İşler tamamlandıktan sonra 15 dakika tutulur.
- Sembol ilerlemesi ve hata sayısı raporlanır.
- Eski `GET /api/radar` uç noktası da geriye dönük kullanım için kalır.


## Güvenlik yapılandırması (V14)
- `RADAR_ALLOWED_ORIGINS` virgülle ayrılmış izinli origin listesidir. Varsayılan: `https://localhost,http://localhost:5173`.
- `RADAR_API_TOKEN` ayarlanırsa `/api/radar`, `/api/scan/start` ve `/api/scan/status/...` istekleri `X-API-Token` başlığı gerektirir.
- Mobil derlemede aynı token `VITE_RADAR_API_TOKEN` ile UI'ya eklenebilir. Dikkat: mobil uygulama içine gömülen token gizli tutulamaz; gerçek dağıtımda kullanıcı/cihaz bazlı kimlik doğrulama ve HTTPS reverse proxy kullanın.
- `/health` genel sağlık kontrolü olarak token istemez.
- CORS artık varsayılan olarak wildcard değildir. İzinli origin dışındaki tarayıcı kaynaklarına CORS izni verilmez.
