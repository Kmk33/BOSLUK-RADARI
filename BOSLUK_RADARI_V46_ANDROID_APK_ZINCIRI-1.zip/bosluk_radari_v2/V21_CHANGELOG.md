# V21 changelog

- Added independent setup-quality evidence buckets: trend alignment, volume confirmation, close-confirmed breakout, bullish structure, confirmed retest.
- Correlated EMA conditions are capped within one trend bucket; RVOL and taker-buy pressure are capped within one volume bucket.
- A downside-risk flag on any analyzed timeframe blocks bullish qualification.
- Quality is informational and separate from the existing ranking score; no score/risk thresholds were relaxed.
- Added tests for de-duplication, risk veto, retest evidence, and insufficient data.
- Not a probability, return forecast, or trading signal.
