# V31 — Coin detail view and scanner regression fixes

- Added a tap-to-open coin detail panel to the mobile UI.
- Detail panel includes a compact closed-candle close trace, timeframe selector, RSI/Stoch RSI/RVOL, MACD histogram, ATR, support, EMA/SMA values, resistance clusters, theoretical gap blockers, pattern labels, retest state and timeframe quality scores.
- Scanner timeframe aggregation was extracted into a pure helper; fixed a previously undefined quality-score variable in the aggregation path.
- Added regression tests for timeframe aggregation, breakout state and downside-risk veto.
- Added 20-second kline caching and ensured fetch timeout timers are cleaned up.
- JavaScript test suite: 17/17 passed; syntax checks clean.
- No Android APK or live Binance/device validation is claimed.
