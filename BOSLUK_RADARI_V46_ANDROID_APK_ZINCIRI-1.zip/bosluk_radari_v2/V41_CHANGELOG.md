# V41 — Sahte kırılım ve kapanış teyidi filtresi

- Yeni `classifyBreakoutAttempt` fonksiyonu direnç üstüne yalnızca fitil atan, fakat direnç üzerinde kapanmayan mumları FITIL TUZAĞI / DİRENÇ REDDİ olarak sınıflandırır.
- Kapanışla kırılım için en az %0.2 seviye üstü kapanış, son 20 kapanmış mumun ortalamasına göre RVOL >= 1.5 ve mum aralığının üst %35'inde kapanış şartı aranır.
- Kırılım sonrası kapanış yeniden seviyenin %0.3 altına düşerse kırılım geçersiz sayılır.
- Bu kalite sınıflandırması her zaman diliminde tarama çıktısına eklenir; yalnızca teyitli kırılımlar breakout olarak sayılır.
- Sahte/bozulmuş kırılım, birleşik radar durumunda SAHTE KIRILIM / RED olur; puanı düşürülür ve boğa hazırlığı olarak sıralanmaz.
- Coin detayında kırılım kalite durumu, RVOL ve kapanış konumu gösterilir.
- 37/37 Node testi başarılı; JS sözdizimi kontrolleri temiz.
- Canlı Binance, Vite production build ve Android cihaz testi yapılmadı; APK üretilmedi.
