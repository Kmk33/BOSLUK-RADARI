# Araştırma kaynakları
- Binance Spot API resmî belgeleri: https://github.com/binance/binance-spot-api-docs
- Binance WebSocket Streams (24 saat bağlantı ömrü, ping/pong, stream limitleri): https://github.com/binance/binance-spot-api-docs/blob/master/web-socket-streams.md
- Binance Market Data Only (API key gerektirmeyen public endpoints): https://github.com/binance/binance-spot-api-docs/blob/master/faqs/market_data_only.md
- TA-Lib göstergeleri: https://ta-lib.org/
- TA-Lib candlestick outputs: https://ta-lib.org/api/candlestick-outputs/
- Kripto teknik işlem kuralları üzerine çalışma: https://www.sciencedirect.com/science/article/pii/S1544612319300315

Not: Mum formasyonlarının yönü, önceki trend bağlamı olmadan tek başına işlem sinyali sayılmamalıdır. Backtestte gelecek veriyi sinyal üretiminden ayırmak zorunludur.
