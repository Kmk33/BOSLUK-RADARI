# V32 — Local scan history and breakout/retest correction

- Added a local scan-history panel with the latest 30 successful scans, counts and leading symbols.
- Last-scan storage migrated to a versioned key; history is kept separately and can be cleared with the local-store API.
- Fixed same-millisecond history timestamp collisions.
- Corrected retest input: retest detector now receives the actual breakout pivot level, not the nearest overhead resistance (which could not be retested while price remained below it).
- Added a deterministic retest-after-breakout regression test.
- JavaScript test suite: 18/18 passed; syntax checks clean.
- Live Binance and Android APK/device testing remain outstanding.
