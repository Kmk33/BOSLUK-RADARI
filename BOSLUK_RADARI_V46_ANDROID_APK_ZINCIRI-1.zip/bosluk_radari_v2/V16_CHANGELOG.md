# V16 changelog

- Binance Spot client now caches exchangeInfo for up to one hour per client instance.
- 24-hour ticker snapshot is cached for 15 seconds per client instance.
- Cached JSON is deep-copied before returning so callers cannot corrupt shared cache.
- Transient network/server errors receive bounded exponential retries.
- Binance HTTP 418/429 rate-limit responses are surfaced immediately; they are not retried or hidden by endpoint fallback.
- Added deterministic tests for caching, cache isolation, transient retry, and rate-limit behavior.
- No live Binance scan or APK build is claimed.
