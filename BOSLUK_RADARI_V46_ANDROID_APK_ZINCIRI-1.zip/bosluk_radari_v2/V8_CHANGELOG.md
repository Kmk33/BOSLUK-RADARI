# V8 — Emir defteri ve agresör işlem akışı

- Binance Spot `depth` verisi için spread, ilk N seviye notional büyüklüğü, genel ve fiyat bandı içi emir defteri dengesizliği hesaplanıyor.
- `aggTrades` endpoint'i eklendi.
- `m` alanına göre taker alış/satış miktarı ve kotasyon hacmi ayrıştırılıyor.
- Taker alış payı ve net taker kotasyon akışı raporlanıyor.
- Bu veri gerçek tarihsel CVD olarak adlandırılmıyor; kısa dönem agresör akışı proxy'si olarak etiketleniyor.
- Emir defteri ve aggTrades farklı anlık görüntüler olabileceği için senkronizasyon uyarısı eklendi.
- Spread > %0,50 veya eksik mikro yapı verisi uyarı bayrağı oluşturuyor; mikro yapı tek başına bullish puan eklemiyor.
- Beş yeni test eklendi.
