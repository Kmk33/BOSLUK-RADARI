# V9 — Yaklaşık hacim profili ve üst arz bölgeleri

- Mum hacmini fiyat aralıklarına dağıtan OHLCV tabanlı yaklaşık volume profile eklendi.
- POC (en yüksek hacim düğümü) ve %70 hacim alanı hesaplanıyor.
- Güncel fiyatın üzerindeki hacimli fiyat kümeleri üst arz bölgeleri olarak çıkarılıyor.
- Her arz bölgesi için alt/üst uzaklık yüzdesi raporlanıyor.
- Tarama zaman dilimi çıktısına volume profile ve overhead supply alanları eklendi.
- Açık mumlar hariç tutuluyor.
- Önemli sınırlama: Mum içindeki hacmin fiyat aralığına eşit dağıtılması varsayımı kullanılır; gerçek işlem bazlı/tick-level volume profile değildir.
- Dört yeni test eklendi.
