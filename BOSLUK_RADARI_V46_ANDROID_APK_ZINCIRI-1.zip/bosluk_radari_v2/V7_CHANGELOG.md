# V7 — Likidite ön elemesi ve risk öncelikli aday sıralaması

- Binance Spot USDT sembolleri 24 saatlik USDT kotasyon hacmi ve işlem sayısına göre ön filtreleniyor.
- Varsayılan eşikler: 1.000.000 USDT 24s kotasyon hacmi, 500 işlem, en likit ilk 150 sembol.
- Kaldıraçlı token benzeri UP/DOWN/BULL/BEAR sembolleri Spot evreninden hariç tutuluyor.
- Çoklu zaman dilimi sonuçları risk öncelikli sıralanıyor; herhangi bir analiz periyodunda downside_risk bulunan sembol aday listesinden çıkarılıyor.
- Direnç boşluğu sıralama katkısı olarak sınırlandırılıyor; tek başına riski geçersiz kılamıyor.
- API/analiz hataları sessizce sinyale çevrilmiyor; tarama raporunun errors bölümünde tutuluyor.
- Dört yeni test eklendi.
