# V38 — Pattern validation harness and APK pipeline hardening

- Added chronological prefix-only historical pattern evaluator. Each signal uses only candles available through that signal bar; outcomes begin on following candles.
- Same-bar stop/target collisions are conservatively counted stop-first. Risk-tagged patterns are excluded.
- Produces per-pattern signal, target, stop and unresolved counts; overlap is allowed and disclosed.
- Added tests for insufficient data handling and look-ahead-free method metadata.
- Android workflow now verifies the built web bundle and checks that no legacy RADAR_API_BASE/local API dependency is present before building the standalone APK.
- Added APK file existence verification before artifact upload.
- 28 local JS tests pass; syntax checks clean.
- No historical performance result is claimed because no real historical dataset was run in this environment. APK workflow has not been executed.
