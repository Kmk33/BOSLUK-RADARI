# V26 changelog

- Added a GitHub Actions Android debug APK build workflow.
- Workflow installs Node 20 dependencies, uses JDK 21, builds Vite assets, adds/syncs Capacitor Android, assembles debug APK and uploads it as a 14-day artifact.
- Workflow requires a real HTTPS `RADAR_API_BASE` repository variable; it fails early if missing or non-HTTPS.
- Added Turkish local/CI Android build guide and security notes.
- This is build automation, not an APK: Android SDK/Gradle are unavailable in the current execution environment.
