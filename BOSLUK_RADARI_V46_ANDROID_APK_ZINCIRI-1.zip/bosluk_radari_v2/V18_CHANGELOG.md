# V18 changelog

- Added `tools/live_spot_check.py`, a read-only Binance Spot connectivity smoke test.
- Checks exchange metadata, 24h ticker, eligible liquid Spot USDT universe, and a bounded 1h sample scan (default max 3 symbols; configurable 1–10).
- Emits machine-readable JSON with per-check duration, failures, scan throughput diagnostics, and overall status.
- Exit code 0 means the bounded smoke test completed; exit code 2 means one or more required checks failed.
- Added mocked tests for successful checks, empty eligible universe, and visible ticker failure.
- The smoke-test command itself has not been run against Binance in this environment; no live connectivity claim is made.
